#pragma once

#include <cstdint>

#ifndef PGL_GLD_BOARD_PROFILE_GLD2
#define PGL_GLD_BOARD_PROFILE_GLD2 0
#endif

#if PGL_GLD_BOARD_PROFILE_GLD2

#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
#include "BoardPinsGLD3.h"
#else
#include "BoardPinsGLD2.h"
#endif

// The production runtime consumes pgl::gld::board. Keep each schematic pin
// map separate; selecting GLD3 must not enable the fan on GLD2 builds.
namespace pgl::gld::board {
#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
namespace activeBoard = gld3;
#else
namespace activeBoard = gld2;
#endif
constexpr int PIN_SPI_SCK = activeBoard::PIN_SPI_SCK;
constexpr int PIN_SPI_MOSI = activeBoard::PIN_SPI_MOSI;
constexpr int PIN_SPI_MISO = activeBoard::PIN_SPI_MISO;
constexpr int PIN_ADS1256_CS = activeBoard::PIN_ADS1256_CS;
constexpr int PIN_ADS1256_DRDY = activeBoard::PIN_ADS1256_DRDY;
constexpr int PIN_ADS1256_RESET = activeBoard::PIN_ADS1256_RESET;
constexpr int PIN_ADS1256_PDOWN = activeBoard::PIN_ADS1256_PDOWN;
constexpr int PIN_ADS1256_SYNC = PIN_ADS1256_PDOWN;
constexpr int PIN_LORA_CS = activeBoard::PIN_LORA_CS;
constexpr int PIN_LORA_RST = activeBoard::PIN_LORA_RST;
constexpr int PIN_LORA_BUSY = activeBoard::PIN_LORA_BUSY;
constexpr int PIN_LORA_DIO1 = activeBoard::PIN_LORA_DIO1;
constexpr int PIN_LORA_RXEN = activeBoard::PIN_LORA_RXEN;
constexpr int PIN_LORA_TXEN = activeBoard::PIN_LORA_TXEN;
constexpr int PIN_I2C_SDA = activeBoard::PIN_I2C_SDA;
constexpr int PIN_I2C_SCL = activeBoard::PIN_I2C_SCL;
constexpr int PIN_STATUS_LED = activeBoard::PIN_STATUS_LED;
constexpr int PIN_ALARM_LAMP = activeBoard::PIN_ALARM;
constexpr int PIN_ALARM_ENABLE_BOOST = activeBoard::PIN_ALARM_ENABLE_BOOST;
constexpr int PIN_BUZZER = -1;
constexpr int PIN_DC_FAN = activeBoard::PIN_DC_FAN;
constexpr bool HAS_DC_FAN = activeBoard::HAS_DC_FAN;
constexpr int PIN_TPL5110_DONE = activeBoard::PIN_TPL5010_DONE;
constexpr int PIN_POWER_LATCH_CLR = activeBoard::PIN_POWER_LATCH_CLR;
constexpr int PIN_BATTERY_VOLTAGE = activeBoard::PIN_BATTERY_VOLTAGE;
constexpr int PIN_24V_POWER_GOOD = activeBoard::PIN_24V_POWER_GOOD;
constexpr int PIN_POWER_SOURCE_STATUS = activeBoard::PIN_POWER_SOURCE_STATUS;
constexpr int PIN_USER_BUTTON = activeBoard::PIN_USER_BUTTON;
constexpr int PIN_RS485_DIR = activeBoard::PIN_RS485_DIR;
constexpr int PIN_RS485_RX = activeBoard::PIN_RS485_RX;
constexpr int PIN_RS485_TX = activeBoard::PIN_RS485_TX;
constexpr bool HAS_RS485 = activeBoard::HAS_RS485;
constexpr uint8_t SENSOR_COUNT = activeBoard::SENSOR_COUNT;
constexpr const char* const* SENSOR_NAMES = activeBoard::SENSOR_NAMES;
constexpr const char* const* SENSOR_HEADERS = activeBoard::SENSOR_HEADERS;
constexpr uint8_t TCA9548A_ADDR = activeBoard::TCA9548A_ADDR;
constexpr uint8_t MCP4725_ADDR = activeBoard::MCP4725_ADDR;
constexpr uint8_t PCF8574_ADDR = activeBoard::PCF8574_ADDR;
constexpr uint8_t PCF8574_ALL_LOAD_SWITCHES_ON = activeBoard::PCF8574_ALL_LOAD_SWITCHES_ON;
constexpr uint8_t PCF8574_ALL_LOAD_SWITCHES_OFF = activeBoard::PCF8574_ALL_LOAD_SWITCHES_OFF;
constexpr bool HAS_PCF8574 = true;
constexpr uint16_t GLD_DAC_CODE_MIN = activeBoard::GLD_DAC_CODE_MIN;
constexpr uint16_t GLD_DAC_CODE_MAX = activeBoard::GLD_DAC_CODE_MAX;
constexpr const uint8_t* SENSOR_TO_MUX_CH = activeBoard::SENSOR_TO_MUX_CH;
constexpr const uint8_t* SENSOR_TO_POWER_EN = activeBoard::SENSOR_TO_POWER_EN;
constexpr const uint8_t* POWER_EN_TO_MUX_CH = activeBoard::POWER_EN_TO_MUX_CH;
constexpr const uint8_t* SENSOR_TO_ADS_CH = activeBoard::SENSOR_TO_ADS_CH;
}  // namespace pgl::gld::board

#else

#ifndef PGL_GLD_BOARD_PROFILE_WROOM_U1_N16R8
#define PGL_GLD_BOARD_PROFILE_WROOM_U1_N16R8 0
#endif

#if PGL_GLD_BOARD_PROFILE_WROOM_U1_N16R8
#ifndef PGL_GLD_PIN_LORA_CS
#define PGL_GLD_PIN_LORA_CS 7
#endif
#ifndef PGL_GLD_PIN_LORA_RST
#define PGL_GLD_PIN_LORA_RST 2
#endif
#ifndef PGL_GLD_PIN_LORA_BUSY
#define PGL_GLD_PIN_LORA_BUSY 15
#endif
#ifndef PGL_GLD_PIN_LORA_DIO1
#define PGL_GLD_PIN_LORA_DIO1 1
#endif
#ifndef PGL_GLD_PIN_LORA_RXEN
#define PGL_GLD_PIN_LORA_RXEN 5
#endif
#ifndef PGL_GLD_PIN_LORA_TXEN
#define PGL_GLD_PIN_LORA_TXEN 6
#endif
#ifndef PGL_GLD_PIN_ALARM_LAMP
#define PGL_GLD_PIN_ALARM_LAMP 41
#endif
#ifndef PGL_GLD_PIN_BUZZER
#define PGL_GLD_PIN_BUZZER 40
#endif
#ifndef PGL_GLD_PIN_STATUS_LED
#define PGL_GLD_PIN_STATUS_LED 39
#endif
#endif

namespace pgl::gld::board {

#ifndef PGL_GLD_PIN_SPI_SCK
#define PGL_GLD_PIN_SPI_SCK 12
#endif
#ifndef PGL_GLD_PIN_SPI_MOSI
#define PGL_GLD_PIN_SPI_MOSI 11
#endif
#ifndef PGL_GLD_PIN_SPI_MISO
#define PGL_GLD_PIN_SPI_MISO 13
#endif

#ifndef PGL_GLD_PIN_ADS1256_CS
#define PGL_GLD_PIN_ADS1256_CS 47
#endif
#ifndef PGL_GLD_PIN_ADS1256_DRDY
#define PGL_GLD_PIN_ADS1256_DRDY 10
#endif
#ifndef PGL_GLD_PIN_ADS1256_SYNC
#define PGL_GLD_PIN_ADS1256_SYNC 18
#endif

#ifndef PGL_GLD_PIN_LORA_CS
#define PGL_GLD_PIN_LORA_CS 15
#endif
#ifndef PGL_GLD_PIN_LORA_RST
#define PGL_GLD_PIN_LORA_RST 39
#endif
#ifndef PGL_GLD_PIN_LORA_BUSY
#define PGL_GLD_PIN_LORA_BUSY 7
#endif
#ifndef PGL_GLD_PIN_LORA_DIO1
#define PGL_GLD_PIN_LORA_DIO1 40
#endif
#ifndef PGL_GLD_PIN_LORA_RXEN
#define PGL_GLD_PIN_LORA_RXEN 5
#endif
#ifndef PGL_GLD_PIN_LORA_TXEN
#define PGL_GLD_PIN_LORA_TXEN 6
#endif

#ifndef PGL_GLD_PIN_I2C_SDA
#define PGL_GLD_PIN_I2C_SDA 8
#endif
#ifndef PGL_GLD_PIN_I2C_SCL
#define PGL_GLD_PIN_I2C_SCL 9
#endif

#ifndef PGL_GLD_PIN_STATUS_LED
#define PGL_GLD_PIN_STATUS_LED 41
#endif
#ifndef PGL_GLD_PIN_ALARM_LAMP
#define PGL_GLD_PIN_ALARM_LAMP 1
#endif
#ifndef PGL_GLD_PIN_BUZZER
#define PGL_GLD_PIN_BUZZER 2
#endif
#ifndef PGL_GLD_PIN_DC_FAN
#define PGL_GLD_PIN_DC_FAN 42
#endif

#ifndef PGL_GLD_PIN_TPL5110_DONE
#define PGL_GLD_PIN_TPL5110_DONE 14
#endif
// Active-low CLR input of the SN74AUP1G74 power-latch flip-flop. Pulsing this
// HIGH->LOW->HIGH clears the latch and cuts ESP32 power (shared with the
// "clear latched alarm error" button function - see design.md §3.18).
#ifndef PGL_GLD_PIN_POWER_LATCH_CLR
#define PGL_GLD_PIN_POWER_LATCH_CLR 38
#endif
#ifndef PGL_GLD_PIN_BATTERY_VOLTAGE
#define PGL_GLD_PIN_BATTERY_VOLTAGE 4
#endif
#ifndef PGL_GLD_PIN_24V_POWER_GOOD
#define PGL_GLD_PIN_24V_POWER_GOOD 45
#endif
#ifndef PGL_GLD_PIN_USER_BUTTON
#define PGL_GLD_PIN_USER_BUTTON 16
#endif

constexpr int PIN_SPI_SCK = PGL_GLD_PIN_SPI_SCK;
constexpr int PIN_SPI_MOSI = PGL_GLD_PIN_SPI_MOSI;
constexpr int PIN_SPI_MISO = PGL_GLD_PIN_SPI_MISO;

constexpr int PIN_ADS1256_CS = PGL_GLD_PIN_ADS1256_CS;
constexpr int PIN_ADS1256_DRDY = PGL_GLD_PIN_ADS1256_DRDY;
constexpr int PIN_ADS1256_SYNC = PGL_GLD_PIN_ADS1256_SYNC;
constexpr int PIN_ADS1256_RESET = -1;
constexpr int PIN_ADS1256_PDOWN = PIN_ADS1256_SYNC;

constexpr int PIN_LORA_CS = PGL_GLD_PIN_LORA_CS;
constexpr int PIN_LORA_RST = PGL_GLD_PIN_LORA_RST;
constexpr int PIN_LORA_BUSY = PGL_GLD_PIN_LORA_BUSY;
constexpr int PIN_LORA_DIO1 = PGL_GLD_PIN_LORA_DIO1;
constexpr int PIN_LORA_RXEN = PGL_GLD_PIN_LORA_RXEN;
constexpr int PIN_LORA_TXEN = PGL_GLD_PIN_LORA_TXEN;

constexpr int PIN_I2C_SDA = PGL_GLD_PIN_I2C_SDA;
constexpr int PIN_I2C_SCL = PGL_GLD_PIN_I2C_SCL;

constexpr int PIN_STATUS_LED = PGL_GLD_PIN_STATUS_LED;
constexpr int PIN_ALARM_LAMP = PGL_GLD_PIN_ALARM_LAMP;
constexpr int PIN_ALARM_ENABLE_BOOST = -1;
constexpr int PIN_BUZZER = PGL_GLD_PIN_BUZZER;
constexpr int PIN_DC_FAN = PGL_GLD_PIN_DC_FAN;
constexpr bool HAS_DC_FAN = PIN_DC_FAN >= 0;

constexpr int PIN_TPL5110_DONE = PGL_GLD_PIN_TPL5110_DONE;
constexpr int PIN_POWER_LATCH_CLR = PGL_GLD_PIN_POWER_LATCH_CLR;
constexpr int PIN_BATTERY_VOLTAGE = PGL_GLD_PIN_BATTERY_VOLTAGE;
constexpr int PIN_24V_POWER_GOOD = PGL_GLD_PIN_24V_POWER_GOOD;
constexpr int PIN_POWER_SOURCE_STATUS = -1;
constexpr int PIN_USER_BUTTON = PGL_GLD_PIN_USER_BUTTON;
constexpr int PIN_RS485_DIR = -1;
constexpr int PIN_RS485_RX = -1;
constexpr int PIN_RS485_TX = -1;
constexpr bool HAS_RS485 = false;

constexpr uint8_t SENSOR_COUNT = 8;
constexpr const char* SENSOR_NAMES[SENSOR_COUNT] = {
    "MQ8", "MQ135", "MQ3", "MQ5", "MQ4", "MQ7", "MQ6", "MQ2",
};
// Legacy GLD has no documented H1..H8 connector naming.  The GLD2-only
// isolated-MCP diagnostic is compiled into the shared main, so retain a
// harmless placeholder table for that unreachable legacy branch.
constexpr const char* SENSOR_HEADERS[SENSOR_COUNT] = {
    "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a", "n/a",
};

constexpr uint8_t TCA9548A_ADDR = 0x71;
constexpr uint8_t MCP4725_ADDR = 0x60;
constexpr uint8_t PCF8574_ADDR = 0;
constexpr uint8_t PCF8574_ALL_LOAD_SWITCHES_ON = 0;
constexpr uint8_t PCF8574_ALL_LOAD_SWITCHES_OFF = 0;
constexpr bool HAS_PCF8574 = false;
constexpr uint16_t GLD_DAC_CODE_MIN = 0;
constexpr uint16_t GLD_DAC_CODE_MAX = 4095;
constexpr uint8_t SENSOR_TO_MUX_CH[SENSOR_COUNT] = {7, 6, 5, 0, 1, 2, 3, 4};
constexpr uint8_t SENSOR_TO_POWER_EN[SENSOR_COUNT] = {0, 6, 7, 3, 4, 5, 2, 1};
constexpr uint8_t SENSOR_TO_ADS_CH[SENSOR_COUNT] = {0, 1, 2, 3, 4, 5, 6, 7};

}  // namespace pgl::gld::board

#endif  // PGL_GLD_BOARD_PROFILE_GLD2
