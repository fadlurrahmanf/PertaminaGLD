#include <Arduino.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <PubSubClient.h>
#include <RadioLib.h>
#include <SPI.h>
#include <WiFi.h>
#include <esp_system.h>

#include <cstdarg>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "BoardPins.h"
#include "FirmwareVersion.h"
#include "GldAds1256Reader.h"
#include "GldAlarmControl.h"
#include "GldCommandParser.h"
#include "GldDacMux.h"
#include "GldDatasetValidator.h"
#include "GldFrameBuilder.h"
#include "GldModeManager.h"
#include "GldModbusRtu.h"
#include "GldMovingAverage.h"
#include "GldModelBinding.h"
#include "GldNullingProfile.h"
#include "GldNullingService.h"
#include "GldQcProfile.h"
#include "GldQcService.h"
#include "GldPower.h"
#include "GldPcf8574.h"
#include "GldThresholdClassifier.h"
#include "GldConfig.h"
#include "FirmwareConfig.h"
#if GLD_ALLOW_SELFTEST_AES_FALLBACK
#if !defined(PGL_GLD_FIELDTEST_SELFTEST_BUILD)
#error "Public AES self-test fallback is allowed only in an explicit nonproduction field-test build"
#endif
#include "GldSelfTestConfig.h"
#endif
#include "ProtocolConstants.h"
#include "ModelMetadata.h"
#include "NeuralNetwork.h"

namespace {

static_assert(static_cast<uint8_t>(pgl::gld::GldAds1256Status::Ok) ==
                  pgl::gld::GLD_DATASET_STATUS_OK,
              "Dataset validator status contract must track ADS1256 Ok");

// ---------------------------------------------------------------------------
// Resolved from GldConfig.h
// ---------------------------------------------------------------------------
constexpr const char* DEFAULT_WIFI_SSID      = GLD_WIFI_SSID;
constexpr const char* DEFAULT_WIFI_PASSWORD  = GLD_WIFI_PASSWORD;
constexpr const char* DEFAULT_MQTT_HOST      = GLD_MQTT_HOST;
constexpr uint16_t    DEFAULT_MQTT_PORT      = GLD_MQTT_PORT;
constexpr const char* DEFAULT_MQTT_USER      = GLD_MQTT_USER;
constexpr const char* DEFAULT_MQTT_PASS      = GLD_MQTT_PASS;
constexpr const char* DEFAULT_DEVICE_ID_STR  = GLD_DEVICE_ID_STR;
constexpr uint16_t    DEFAULT_NODE_ID        = GLD_NODE_ID;
constexpr const char* DEFAULT_TOPIC_ROOT     = PGL_SERVER_DATASET_TOPIC_ROOT;

// ---------------------------------------------------------------------------
// LoRa config (STAR) — harus cocok dengan CH, tidak diubah per-node
// ---------------------------------------------------------------------------
constexpr float    DEFAULT_STAR_FREQ_MHZ    = GLD_STAR_FREQ_MHZ;
constexpr float    DEFAULT_STAR_BW_KHZ      = GLD_STAR_BW_KHZ;
constexpr uint8_t  DEFAULT_STAR_SF          = GLD_STAR_SF;
constexpr uint8_t  DEFAULT_STAR_CR          = GLD_STAR_CR;
constexpr uint8_t  DEFAULT_STAR_SYNC_WORD   = GLD_STAR_SYNC_WORD;
constexpr int8_t   DEFAULT_STAR_TX_POWER    = GLD_STAR_TX_POWER_DBM;
constexpr uint16_t DEFAULT_STAR_PREAMBLE    = GLD_STAR_PREAMBLE;
constexpr float    DEFAULT_LORA_TCXO_V      = GLD_STAR_TCXO_VOLTAGE;
constexpr float    DEFAULT_LORA_XTAL_V      = GLD_STAR_XTAL_VOLTAGE;
constexpr uint32_t LORA_RX_WINDOW_MS = GLD_LORA_RX_WINDOW_MS;
constexpr float    STAR_RUNTIME_MIN_FREQ_MHZ = 920.0f;
constexpr float    STAR_RUNTIME_MAX_FREQ_MHZ = 923.0f;

// ---------------------------------------------------------------------------
// Timing from GldConfig.h
// ---------------------------------------------------------------------------
constexpr uint32_t SCAN_INTERVAL_MS   = GLD_SCAN_INTERVAL_MS;
constexpr uint32_t DATASET_MIN_SAMPLE_INTERVAL_MS = GLD_DATASET_MIN_SAMPLE_INTERVAL_MS;
constexpr uint32_t TX_INTERVAL_MS     = GLD_TX_INTERVAL_MS;
constexpr uint32_t WIFI_TIMEOUT_MS    = GLD_WIFI_TIMEOUT_MS;
constexpr uint32_t MQTT_RETRY_MS      = GLD_MQTT_RETRY_MS;
constexpr uint32_t STATUS_INTERVAL_MS = GLD_STATUS_INTERVAL_MS;
constexpr uint16_t MQTT_BUFFER_SIZE   = GLD_MQTT_BUFFER_SIZE;
constexpr uint8_t  MIN_PRIMED_COUNT   = pgl::gld::GLD_SENSOR_MOVING_AVERAGE_WINDOW;
constexpr uint8_t  BOOT_SENSOR_SNAPSHOT_COUNT = 5;
constexpr uint32_t BOOT_DAC_SETTLE_MS = 5;
constexpr uint32_t BOOT_SENSOR_MODULE_POWER_SETTLE_MS = 500;
constexpr uint16_t BOOT_DAC_SENSOR_POWER_SETTLE_MS = 500;
constexpr uint16_t NORMAL_DAC_SENSOR_POWER_SETTLE_MS = 50;
constexpr uint16_t BOOT_I2C_TIMEOUT_MS = 50;
// GLD2 carries an SHT40 directly on the root I2C bus.  It is not behind the
// TCA9548A, so always deselect the TCA before addressing it.
constexpr uint8_t SHT40_I2C_ADDR = 0x44;
constexpr uint8_t SHT40_MEASURE_HIGH_PRECISION_CMD = 0xFD;
constexpr uint32_t SHT40_CONVERSION_MS = 10;
constexpr uint32_t SHT40_SAMPLE_INTERVAL_MS = 100;
constexpr uint32_t TCA_PRESENCE_PROBE_INTERVAL_MS = 500;
constexpr uint32_t NON_BATTERY_DAC_VERIFY_INTERVAL_MS = 5000;
constexpr uint8_t  BOOT_MCP_TEST_EDGE_COUNT = 10;
constexpr uint16_t BOOT_MCP_TEST_LOW_START = pgl::gld::board::GLD_DAC_CODE_MIN;
constexpr uint16_t BOOT_MCP_TEST_LOW_END =
    BOOT_MCP_TEST_LOW_START + BOOT_MCP_TEST_EDGE_COUNT - 1U;
constexpr uint16_t BOOT_MCP_TEST_HIGH_END = pgl::gld::board::GLD_DAC_CODE_MAX;
constexpr uint16_t BOOT_MCP_TEST_HIGH_START =
    BOOT_MCP_TEST_HIGH_END - BOOT_MCP_TEST_EDGE_COUNT + 1U;
constexpr uint16_t DIAG_SWEEP_DAC_CODE_LOW = pgl::gld::board::GLD_DAC_CODE_MIN;
constexpr uint16_t DIAG_SWEEP_DAC_CODE_HIGH = 4000;
constexpr uint8_t  DIAG_SWEEP_SAMPLE_COUNT = 5;
constexpr uint32_t DIAG_SWEEP_SETTLE_MS = 250;
constexpr uint8_t  DATASET_QUEUE_CAPACITY = 16;
constexpr size_t   DATASET_PAYLOAD_BYTES = 896;
constexpr uint8_t  DATASET_QUEUE_FLUSH_PER_LOOP = 2;
constexpr uint32_t ADS_RECOVERY_RETRY_MS = 5000;
constexpr uint8_t  ADS_READ_FAIL_RECOVERY_THRESHOLD = 3;
constexpr uint32_t BOOT_RECOVERY_DELAY_MS = 60000;
constexpr uint8_t  BOOT_RECOVERY_MAX_RESTARTS = 1;
constexpr uint32_t ADS1256_SPI_HZ = 1920000;
constexpr uint8_t ADS1256_RREG_CMD = 0x10;
constexpr uint8_t ADS1256_REG_STATUS = 0x00;
constexpr uint8_t ADS1256_REG_MUX = 0x01;
constexpr uint8_t ADS1256_REG_ADCON = 0x02;
constexpr uint8_t ADS1256_REG_DRATE = 0x03;
constexpr uint32_t NULLING_AUTO_RESTART_DELAY_MS = 800;
constexpr uint32_t BATTERY_FAULT_SERIAL_HOLD_MS = 10000;
constexpr uint32_t BATTERY_SENSOR_WARMUP_MS = GLD_BATTERY_SENSOR_WARMUP_MS;
constexpr uint8_t BATTERY_VALID_SAMPLE_BATCHES = GLD_BATTERY_VALID_SAMPLE_BATCHES;
constexpr uint8_t BATTERY_ALARM_TX_ATTEMPTS = GLD_BATTERY_ALARM_TX_ATTEMPTS;
constexpr uint32_t BATTERY_ALARM_RETRY_DELAY_MS = GLD_BATTERY_ALARM_RETRY_DELAY_MS;
constexpr uint32_t BATTERY_SESSION_DEADLINE_MS = GLD_BATTERY_SESSION_DEADLINE_MS;
constexpr uint32_t CFG_BUTTON_DEBOUNCE_MS = GLD_CFG_BUTTON_DEBOUNCE_MS;
constexpr uint32_t POWER_RECONCILE_INTERVAL_MS = 1000;
constexpr uint8_t POWER_RECONCILE_STABLE_SAMPLES = 3;

#if defined(PGL_GLD_TFBG_CONTINUOUS_BATTERY)
constexpr bool TFBG_CONTINUOUS_BATTERY = true;
#else
constexpr bool TFBG_CONTINUOUS_BATTERY = false;
#endif

#if defined(PGL_GLD_FIELDTEST_4CLASS)
// This is a non-production transport/coverage test.  It deliberately bypasses
// the ML model and emits a fixed safe telemetry result, while still requiring
// healthy ADS and LoRa hardware.  Alarm persistence, outputs, and alarm radio
// frames stay disabled.
constexpr bool FIELDTEST_MODEL_UNVERIFIED = true;
#else
constexpr bool FIELDTEST_MODEL_UNVERIFIED = false;
#endif

#if !defined(PGL_GLD_SIMULATED_ALARM_GAS_CLASS)
#define PGL_GLD_SIMULATED_ALARM_GAS_CLASS 2
#endif

#if !defined(PGL_GLD_SIMULATED_ALARM_CONFIDENCE)
#define PGL_GLD_SIMULATED_ALARM_CONFIDENCE 100
#endif

#if defined(PGL_GLD_SIMULATED_ALARM_MODEL) && defined(PGL_GLD_FIELDTEST_4CLASS)
#error "PGL_GLD_SIMULATED_ALARM_MODEL must not be combined with fieldtest alarm suppression"
#endif

#if defined(PGL_GLD_SIMULATED_CLEAR_MODEL) && defined(PGL_GLD_FIELDTEST_4CLASS)
#error "PGL_GLD_SIMULATED_CLEAR_MODEL must not be combined with fieldtest alarm suppression"
#endif

#if defined(PGL_GLD_SIMULATED_ALARM_MODEL) || defined(PGL_GLD_SIMULATED_CLEAR_MODEL)
constexpr bool SIMULATED_MODEL_OUTPUT = true;
#else
constexpr bool SIMULATED_MODEL_OUTPUT = false;
#endif

#if defined(PGL_GLD_SENSORLESS_BENCH)
constexpr bool SENSORLESS_BENCH = true;
#else
constexpr bool SENSORLESS_BENCH = false;
#endif

#ifndef PGL_GLD_SENSORLESS_REPEAT_INTERVAL_MS
#define PGL_GLD_SENSORLESS_REPEAT_INTERVAL_MS 0
#endif
constexpr uint32_t SENSORLESS_REPEAT_INTERVAL_MS = PGL_GLD_SENSORLESS_REPEAT_INTERVAL_MS;
constexpr bool SENSORLESS_REPEAT_BENCH =
    SENSORLESS_BENCH && SIMULATED_MODEL_OUTPUT && SENSORLESS_REPEAT_INTERVAL_MS > 0;

#if defined(PGL_GLD_SENSORLESS_BENCH) && !defined(PGL_GLD_SIMULATED_ALARM_MODEL) && !defined(PGL_GLD_SIMULATED_CLEAR_MODEL)
#error "PGL_GLD_SENSORLESS_BENCH requires a simulated clear or alarm model output"
#endif

#if defined(PGL_GLD_ALLOW_UNAUTHENTICATED_ALARM_ACK)
constexpr bool ALLOW_UNAUTHENTICATED_ALARM_ACK = true;
#else
// Existing compact ACKs contain only CRC-protected public fields. They are
// accepted only in an explicitly non-production compatibility build; default
// firmware never clears a persisted alarm based on a forgeable RF packet.
constexpr bool ALLOW_UNAUTHENTICATED_ALARM_ACK = false;
#endif

#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
constexpr const char* BOARD_PROFILE = "GLD3 WROOM-1U-N16R8";
#elif PGL_GLD_BOARD_PROFILE_GLD2
constexpr const char* BOARD_PROFILE = "GLD2 WROOM-1U-N16R8";
#elif PGL_GLD_BOARD_PROFILE_WROOM_U1_N16R8
constexpr const char* BOARD_PROFILE = "WROOM-1U-N16R8";
#else
constexpr const char* BOARD_PROFILE = "4D-ESP32S3";
#endif

constexpr uint8_t ACTIVE_LOW_OUTPUT_ON = LOW;
constexpr uint8_t ACTIVE_LOW_OUTPUT_OFF = HIGH;

static_assert(BATTERY_VALID_SAMPLE_BATCHES >= pgl::gld::GLD_SENSOR_MOVING_AVERAGE_WINDOW,
              "Battery inference requires a fully primed moving-average window");
static_assert(BATTERY_ALARM_TX_ATTEMPTS > 0,
              "Battery alarm transmission must have at least one attempt");
#if PGL_GLD_BOARD_PROFILE_WROOM_U1_N16R8
static_assert(pgl::gld::board::PIN_USER_BUTTON == 16, "Unexpected GLD CFG pin");
static_assert(pgl::gld::board::PIN_STATUS_LED == 39, "Unexpected GLD status LED pin");
#endif
#if PGL_GLD_BOARD_PROFILE_GLD2
static_assert(pgl::gld::board::PIN_USER_BUTTON == 5, "Unexpected GLD2 CFG pin");
static_assert(pgl::gld::board::PIN_STATUS_LED == 6, "Unexpected GLD2 status LED pin");
static_assert(pgl::gld::board::PIN_ALARM_LAMP == 40, "Unexpected GLD2 ALARM pin");
static_assert(pgl::gld::board::PIN_ALARM_ENABLE_BOOST == 15, "Unexpected GLD2 alarm boost-enable pin");
static_assert(pgl::gld::board::PIN_ADS1256_RESET == 48, "Unexpected GLD2 ADS reset pin");
static_assert(pgl::gld::board::PIN_ADS1256_PDOWN == 45, "Unexpected GLD2 ADS power-down pin");
#endif

// ---------------------------------------------------------------------------
// Runtime objects
// ---------------------------------------------------------------------------
pgl::gld::GldMode    currentMode = pgl::gld::GldMode::INFERENCE;
SPIClass             gldSpi;
pgl::gld::GldAds1256Reader ads;
pgl::gld::GldMovingAverage movingAvg;
pgl::gld::GldDacMux  dac;
WiFiClient           wifiClient;
PubSubClient         mqtt(wifiClient);
Module*              loraModule = nullptr;
SX1262*              loraRadio  = nullptr;
NeuralNetwork*       network    = nullptr;
#if PGL_GLD_BOARD_PROFILE_GLD2
pgl::gld::GldModbusRtu modbusRtu;
#endif
pgl::gld::GldPcf8574 pcf8574;

// Runtime state
bool adsReady   = false;
bool dacReady   = false;
bool radioReady = false;
bool mlReady    = false;
bool nullDone   = false;
bool nullingRetryArmed = false;
bool nullingRetryAvailable = false;
bool nullingRetryFailedAvailable = false;
uint8_t nullingRetryChannelMask = 0xFFu;
pgl::gld::GldNullingServiceResult pendingNullingResult{};
bool pendingNullingResultValid = false;

uint8_t pendingNullingFailedMask() {
    if (!pendingNullingResultValid) return 0u;
    uint8_t mask = 0u;
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        if (pendingNullingResult.profile.channelOk[ch] == 0u) {
            mask |= static_cast<uint8_t>(1u << ch);
        }
    }
    return mask;
}
bool nullingProfileApplied = false;
bool lastInferenceValid = false;
bool sensorFaultActive = false;
bool modelProfileReady = false;
bool fullScaleSweepActive = false;
bool fullScaleSweepCancelRequested = false;
pgl::gld::GldModelBinding modelBinding{};
bool modelBindingLoaded = false;
uint8_t  txSeq           = 0;
uint32_t txCounter       = 0;
uint32_t lastScanMs      = 0;
uint32_t lastTxMs        = 0;
uint32_t lastMqttAttemptMs = 0;
uint32_t lastStatusMs    = 0;
uint32_t nextNullingRetryMs = 0;
bool     lastAlarm       = false;
// Product default is AUTO. Both the MANUAL test mode and its ON/OFF command
// are session-only, so every reboot restores AUTO with the manual command OFF.
// Inference alarm state continues to update in either mode.
pgl::gld::GldAlarmControlMode alarmControlMode =
    pgl::gld::GldAlarmControlMode::Auto;
bool manualAlarmCommanded = false;
bool physicalAlarmCommanded = false;
uint8_t  nullingProfileId = 0;
uint8_t  nullingAttemptCount = 0;
pgl::gld::GldNullingConfig nullingConfig{};

bool modelProfileMatchesActiveNulling();
bool readStpSource24V();

struct DatasetQueuedPayload {
    char payload[DATASET_PAYLOAD_BYTES]{};
    size_t len = 0;
    uint32_t seq = 0;
};

DatasetQueuedPayload datasetQueue[DATASET_QUEUE_CAPACITY];
uint8_t datasetQueueHead = 0;
uint8_t datasetQueueCount = 0;
uint32_t datasetQueueEnqueued = 0;
uint32_t datasetQueueDropped = 0;
uint32_t datasetPublishFailCount = 0;
uint32_t datasetQueueRetryCount = 0;
uint32_t datasetQueueRetryFailCount = 0;
uint32_t datasetRejectedSamples = 0;
pgl::gld::GldDatasetRejectReason lastDatasetRejectReason =
    pgl::gld::GldDatasetRejectReason::None;
int8_t lastDatasetRejectChannel = -1;
uint8_t lastDatasetRejectOkFiniteCount = 0;
uint8_t lastDatasetRejectStatus = 0xFF;
uint8_t lastDatasetRejectGain = 0;
bool lastDatasetRejectSaturated = false;

uint32_t wifiReconnectCount = 0;
uint32_t wifiReconnectFailCount = 0;
uint32_t mqttReconnectCount = 0;
uint32_t mqttConnectFailCount = 0;
int lastMqttState = 0;
uint32_t adsRecoveryCount = 0;
uint32_t adsRecoveryFailCount = 0;
uint32_t lastAdsRecoveryAttemptMs = 0;
uint8_t adsReadFailStreak = 0;
char lastRecoveryReason[48] = "none";
uint32_t lastRecoveryMs = 0;
bool bootRecoveryArmed = false;
bool bootRecoveryRestartAllowed = false;
bool bootRecoveryNonAdsFailure = false;
uint32_t bootRecoveryDueMs = 0;
char bootRecoveryReason[64] = "none";
RTC_DATA_ATTR uint8_t bootRecoveryRestartCount = 0;

// GLD_GAS_ANOMALY + confidence 0 is the "not classifying" sentinel (no ML
// result available yet / ML unavailable), so a dead classifier never looks
// like a genuine "clear air, 100%" reading. See runScan().
pgl::gld::GldClassifyResult lastResult{pgl::protocol::GLD_GAS_ANOMALY, 0};
bool     debugEnabled    = true;
int16_t  lastLoraBeginState = 0;
int16_t  lastLoraTxState = 0;
bool     lastLoraTxOk = false;
int      lastBootAdsDrdyLevel = -1;
int      lastBootAdsDrdyPulldownLevel = -1;
int      lastBootAdsDrdyPullupLevel = -1;
int      lastBootAdsMisoPulldownLevel = -1;
int      lastBootAdsMisoPullupLevel = -1;
int      lastBootAdsCsLevel = -1;
int      lastBootAdsSyncLevel = -1;
uint8_t  lastBootAdsStatus = 0;
uint8_t  lastBootAdsMux = 0;
uint8_t  lastBootAdsAdcon = 0;
uint8_t  lastBootAdsDrate = 0;
const char* lastBootAdsReason = "not_checked";
bool     lastBootTcaOk = false;
uint8_t  lastBootMcpOkCount = 0;
bool     lastBootMcpOk[pgl::gld::board::SENSOR_COUNT]{};
uint8_t  lastBootMcpAddrMask[pgl::gld::board::SENSOR_COUNT]{};
bool     lastBootMcpControlTested = false;
uint8_t  lastBootMcpControlOkCount = 0;
bool     lastBootMcpControlOk[pgl::gld::board::SENSOR_COUNT]{};
bool     batteryPowerMode = false;
bool     external24VPowerMode = false;
uint16_t lastKnownBatteryMv = 0;
bool     lastKnownExternalPower = false;
bool     modbusReady = false;
bool     pcfReady = false;
bool     pcfAllLoadSwitchesOn = false;
bool     sht40Detected = false;
bool     sht40Valid = false;
float    sht40TemperatureC = NAN;
float    sht40RelativeHumidity = NAN;
uint32_t lastSht40SampleMs = 0;
bool     tca9548aDetected = false;
uint32_t lastTca9548aProbeMs = 0;
bool     batteryCyclePoweredOff = false;
bool     batteryFaultPowerOffArmed = false;
bool     powerTransitionShutdownPending = false;
bool     batteryPersistenceFaultHold = false;
bool     batteryPendingSaveRequired = false;
uint32_t batteryPersistenceRetryDueMs = 0;
uint32_t batteryFaultPowerOffDueMs = 0;
uint32_t lastWdtKeepaliveMs = 0;
uint32_t lastPowerReconcileMs = 0;
bool powerModeCandidateBattery = false;
uint8_t powerModeCandidateCount = 0;

enum class BatterySessionState : uint8_t {
    Inactive = 0,
    Warmup,
    Sampling,
    Transmit,
    CompleteHeld,
    PowerOffIssued,
};

BatterySessionState batterySessionState = BatterySessionState::Inactive;
uint32_t batterySessionStartedMs = 0;
uint32_t batteryStateStartedMs = 0;
uint32_t batteryLastSampleAttemptMs = 0;
uint32_t batteryLastWarmupPrimeMs = 0;
uint32_t batteryNextTxAttemptMs = 0;
uint8_t batteryValidSampleBatches = 0;
uint8_t batteryAlarmTxAttempts = 0;
bool batteryAlarmAckReceived = false;
char batteryCompletionReason[48] = "session_done";
pgl::gld::GldPendingAlarm batteryPendingAlarm{};

struct GldTxSnapshot {
    bool valid = false;
    bool alarm = false;
    uint8_t sequence = 0;
    uint8_t frameLen = 0;
    uint8_t frame[pgl::gld::GLD_PENDING_ALARM_FRAME_CAPACITY]{};
};

GldTxSnapshot batteryTxSnapshot{};
pgl::gld::GldClassifyResult batteryFreshResult{pgl::protocol::GLD_GAS_ANOMALY, 0};
bool batteryFreshInferenceValid = false;
bool batteryFreshAlarm = false;
bool batterySendingPersistedAlarm = false;
bool batteryFreshAlarmQueued = false;

bool serviceHoldActive = false;
bool cfgButtonRawHigh = true;
bool cfgButtonStableHigh = true;
bool cfgButtonPressArmed = false;
uint32_t cfgButtonRawChangedMs = 0;

const char* batterySessionStateName(BatterySessionState state) {
    switch (state) {
        case BatterySessionState::Inactive: return "inactive";
        case BatterySessionState::Warmup: return "warmup";
        case BatterySessionState::Sampling: return "sampling";
        case BatterySessionState::Transmit: return "transmit";
        case BatterySessionState::CompleteHeld: return "complete_held";
        case BatterySessionState::PowerOffIssued: return "power_off_issued";
    }
    return "unknown";
}
float    latestSensorVoltage[pgl::gld::board::SENSOR_COUNT]{};
uint8_t  latestSensorGain[pgl::gld::board::SENSOR_COUNT]{};
uint8_t  latestSensorStatus[pgl::gld::board::SENSOR_COUNT]{};
bool     latestTelemetryValid = false;
uint16_t runtimeMcpReadback[pgl::gld::board::SENSOR_COUNT]{};
uint16_t runtimeMcpExpected[pgl::gld::board::SENSOR_COUNT]{};
bool     runtimeMcpReadbackVerified[pgl::gld::board::SENSOR_COUNT]{};
uint32_t runtimeMcpVerifiedAtMs[pgl::gld::board::SENSOR_COUNT]{};
uint32_t lastNonBatteryDacVerifyMs = 0;
uint8_t  nextNonBatteryDacVerifyChannel = 0;
#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
// Tracks volatile operator adjustments made by this boot. Any diagnostic that
// power-cycles sensor rails must fail closed while one is active because an
// MCP4725 reloads EEPROM on power-up and the exact volatile value would be lost.
uint8_t  sessionMcpOverrideMask = 0;
#endif

bool runtimeDacVerificationReady();
void recordRuntimeDacVerification(uint8_t channel, uint16_t expected, uint16_t readback,
                                  bool readOk, const char* source, bool logPass);

// Marks the NVS-stored board deployment config as deliberately set via
// SET_APP_CONFIG_JSON, matching design.md's BoardDeploymentConfig ctrlword gate.
// 0x00 (default) means "never configured; running on compiled-in defaults".
constexpr uint8_t GLD_CTRL_WORD_VALUE = 0xA3;

struct RuntimeConfig {
    uint8_t ctrlword = 0x00;
    char deviceId[17]{};
    uint16_t nodeId = DEFAULT_NODE_ID;
    uint16_t chId = static_cast<uint16_t>(GLD_CH_ID);
    char wifiSsid[33]{};
    char wifiPassword[65]{};
    char mqttHost[65]{};
    uint16_t mqttPort = DEFAULT_MQTT_PORT;
    char mqttUser[33]{};
    char mqttPass[65]{};
    char topicRoot[65]{};
    uint8_t aesKeyId = 0;
    uint8_t aesKey[16]{};
    bool aesKeyPresent = false;
    uint16_t lastDownlinkCommandId = 0;
    float loraFreqMHz = DEFAULT_STAR_FREQ_MHZ;
    float loraBwKHz = DEFAULT_STAR_BW_KHZ;
    uint8_t loraSf = DEFAULT_STAR_SF;
    uint8_t loraCr = DEFAULT_STAR_CR;
    uint8_t loraSyncWord = DEFAULT_STAR_SYNC_WORD;
    int8_t loraTxPowerDbm = DEFAULT_STAR_TX_POWER;
    uint16_t loraPreamble = DEFAULT_STAR_PREAMBLE;
    float loraTcxoVoltage = DEFAULT_LORA_TCXO_V;
    float loraXtalVoltage = DEFAULT_LORA_XTAL_V;
};

RuntimeConfig runtimeConfig{};

enum class RuntimeAesKeySource : uint8_t {
    None = 0,
    Nvs,
    SelfTest,
};

RuntimeAesKeySource runtimeAesKeySource = RuntimeAesKeySource::None;

const char* runtimeAesKeySourceName() {
    switch (runtimeAesKeySource) {
        case RuntimeAesKeySource::None: return "none";
        case RuntimeAesKeySource::Nvs: return "nvs";
        case RuntimeAesKeySource::SelfTest: return "selftest";
    }
    return "unknown";
}

bool beginLoraRadio();

bool runtimeConfigValid() {
    return runtimeConfig.ctrlword == GLD_CTRL_WORD_VALUE &&
           strlen(runtimeConfig.wifiSsid) > 0 &&
           strlen(runtimeConfig.mqttHost) > 0;
}
char mqttClientId[40]{};
char topicCmd[128]{};
char topicDataset[128]{};
char topicData[128]{};
char topicStatus[128]{};
char topicSummary[128]{};
char topicAck[128]{};

// Dataset session state
enum class DatasetState : uint8_t { Idle, Running };
enum class SampleStep   : uint8_t { None, FanOn, FanSettle, Scan };
DatasetState datasetState   = DatasetState::Idle;
SampleStep   sampleStep     = SampleStep::None;
char         currentLabel[32]{};
uint32_t     datasetSeq     = 0;
uint32_t     sessionStartMs = 0;
uint32_t     stepStartMs    = 0;
uint32_t     targetSamples  = 0;
uint32_t     sampleIntervalMs = DATASET_MIN_SAMPLE_INTERVAL_MS;
uint32_t     maxDurationMs  = 0;
bool         useFanIntake   = pgl::gld::board::HAS_DC_FAN;
uint32_t     fanOnMs        = 1000;
uint32_t     postFanSettleMs = 0;

// LoRa Class A RX flag
volatile bool loraRxFlag = false;

// ---------------------------------------------------------------------------
// Logging
// ---------------------------------------------------------------------------

void rawPrintln(const char* text) {
    Serial.println(text);
#if defined(ARDUINO_ARCH_ESP32)
    Serial0.println(text);
#endif
}

void rawPrint(const char* text) {
    Serial.print(text);
#if defined(ARDUINO_ARCH_ESP32)
    Serial0.print(text);
#endif
}

template <typename TDoc>
void rawJsonLine(const char* prefix, const TDoc& doc) {
    Serial.print(prefix);
    Serial.print(' ');
    serializeJson(doc, Serial);
    Serial.println();
#if defined(ARDUINO_ARCH_ESP32)
    Serial0.print(prefix);
    Serial0.print(' ');
    serializeJson(doc, Serial0);
    Serial0.println();
#endif
}

void logPrintf(const char* fmt, ...) {
    if (!debugEnabled) return;
    char buf[256];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    Serial.print(buf);
#if defined(ARDUINO_ARCH_ESP32)
    Serial0.print(buf);
#endif
}

void logPrintln(const char* text) {
    if (!debugEnabled) return;
    Serial.println(text);
#if defined(ARDUINO_ARCH_ESP32)
    Serial0.println(text);
#endif
}

void copyBounded(char* target, size_t targetSize, const char* source) {
    if (targetSize == 0) return;
    if (source == nullptr) source = "";
    strncpy(target, source, targetSize - 1);
    target[targetSize - 1] = '\0';
}

uint16_t nodeIdFromDeviceId(const char* deviceId, uint16_t fallback) {
    if (deviceId == nullptr || strlen(deviceId) != 4) return fallback;
    char* end = nullptr;
    const unsigned long parsed = strtoul(deviceId, &end, 16);
    if (end == deviceId || *end != '\0' || parsed == 0 || parsed > 0xFFFFUL) return fallback;
    return static_cast<uint16_t>(parsed);
}

int hexNibble(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

bool parseAesKeyHex(const char* text, uint8_t out[16]) {
    if (text == nullptr || out == nullptr) return false;
    size_t outLen = 0;
    int highNibble = -1;
    for (const char* p = text; *p != '\0'; ++p) {
        if ((*p == '0') && (p[1] == 'x' || p[1] == 'X') && highNibble < 0 && outLen == 0) {
            ++p;
            continue;
        }
        const int nibble = hexNibble(*p);
        if (nibble < 0) {
            if (*p == ':' || *p == '-' || *p == '_' || isspace(static_cast<unsigned char>(*p))) {
                continue;
            }
            return false;
        }
        if (highNibble < 0) {
            highNibble = nibble;
        } else {
            if (outLen >= 16) return false;
            out[outLen++] = static_cast<uint8_t>((highNibble << 4) | nibble);
            highNibble = -1;
        }
    }
    return highNibble < 0 && outLen == 16;
}

void setRejectReason(char* target, size_t targetSize, const char* reason) {
    if (target == nullptr || targetSize == 0) return;
    snprintf(target, targetSize, "%s", reason != nullptr ? reason : "invalid config");
}

bool approxEqual(float a, float b, float tolerance = 0.02f) {
    return fabsf(a - b) <= tolerance;
}

bool normalizeLoraBandwidth(float& bwKHz) {
    constexpr float allowed[] = {7.8f, 10.4f, 15.6f, 20.8f, 31.25f,
                                 41.7f, 62.5f, 125.0f, 250.0f, 500.0f};
    for (float allowedBw : allowed) {
        if (approxEqual(bwKHz, allowedBw, 0.08f)) {
            bwKHz = allowedBw;
            return true;
        }
    }
    return false;
}

bool isAllowedTcxoVoltage(float voltage) {
    constexpr float allowed[] = {0.0f, 1.6f, 1.7f, 1.8f, 2.2f, 2.4f, 2.7f, 3.0f, 3.3f};
    for (float allowedVoltage : allowed) {
        if (approxEqual(voltage, allowedVoltage, 0.01f)) return true;
    }
    return false;
}

bool validateRuntimeLoraConfig(RuntimeConfig& config, char* reason = nullptr, size_t reasonSize = 0) {
    if (!std::isfinite(config.loraFreqMHz) ||
        config.loraFreqMHz < STAR_RUNTIME_MIN_FREQ_MHZ ||
        config.loraFreqMHz > STAR_RUNTIME_MAX_FREQ_MHZ) {
        setRejectReason(reason, reasonSize, "freqMHz must be 920.0..923.0 for STAR");
        return false;
    }
    if (!std::isfinite(config.loraBwKHz) || !normalizeLoraBandwidth(config.loraBwKHz)) {
        setRejectReason(reason, reasonSize, "bwKHz must be 7.8,10.4,15.6,20.8,31.25,41.7,62.5,125,250,500");
        return false;
    }
    if (config.loraSf < 5 || config.loraSf > 12) {
        setRejectReason(reason, reasonSize, "sf must be 5..12");
        return false;
    }
    if (config.loraCr < 5 || config.loraCr > 8) {
        setRejectReason(reason, reasonSize, "cr must be 5..8");
        return false;
    }
    if (config.loraTxPowerDbm < -9 || config.loraTxPowerDbm > 22) {
        setRejectReason(reason, reasonSize, "txPowerDbm must be -9..22");
        return false;
    }
    if (config.loraPreamble < 6) {
        setRejectReason(reason, reasonSize, "preamble must be >= 6");
        return false;
    }
    if (!std::isfinite(config.loraTcxoVoltage) || !isAllowedTcxoVoltage(config.loraTcxoVoltage)) {
        setRejectReason(reason, reasonSize, "tcxoVoltage must be 0,1.6,1.7,1.8,2.2,2.4,2.7,3.0,3.3");
        return false;
    }
    if (!std::isfinite(config.loraXtalVoltage) || !isAllowedTcxoVoltage(config.loraXtalVoltage)) {
        setRejectReason(reason, reasonSize, "xtalVoltage must be 0,1.6,1.7,1.8,2.2,2.4,2.7,3.0,3.3");
        return false;
    }
    return true;
}

void resetRuntimeLoraDefaults() {
    runtimeConfig.loraFreqMHz = DEFAULT_STAR_FREQ_MHZ;
    runtimeConfig.loraBwKHz = DEFAULT_STAR_BW_KHZ;
    runtimeConfig.loraSf = DEFAULT_STAR_SF;
    runtimeConfig.loraCr = DEFAULT_STAR_CR;
    runtimeConfig.loraSyncWord = DEFAULT_STAR_SYNC_WORD;
    runtimeConfig.loraTxPowerDbm = DEFAULT_STAR_TX_POWER;
    runtimeConfig.loraPreamble = DEFAULT_STAR_PREAMBLE;
    runtimeConfig.loraTcxoVoltage = DEFAULT_LORA_TCXO_V;
    runtimeConfig.loraXtalVoltage = DEFAULT_LORA_XTAL_V;
}

void clearRuntimeAesKey() {
    runtimeConfig.aesKeyId = 0;
    memset(runtimeConfig.aesKey, 0, sizeof(runtimeConfig.aesKey));
    runtimeConfig.aesKeyPresent = false;
    runtimeAesKeySource = RuntimeAesKeySource::None;
}

void applySelfTestAesFallbackIfAllowed() {
#if GLD_ALLOW_SELFTEST_AES_FALLBACK
    runtimeConfig.aesKeyId = pgl::gld::selftest::KEY_ID;
    memcpy(runtimeConfig.aesKey, pgl::gld::selftest::AES_KEY, sizeof(runtimeConfig.aesKey));
    runtimeConfig.aesKeyPresent = true;
    runtimeAesKeySource = RuntimeAesKeySource::SelfTest;
    logPrintln("GLD_SECURITY_LOAD=SELFTEST_FALLBACK");
#else
    logPrintln("GLD_SECURITY_LOAD=UNPROVISIONED");
#endif
}

void buildRuntimeTopics() {
    snprintf(mqttClientId, sizeof(mqttClientId), "gld-unified-%s", runtimeConfig.deviceId);
    snprintf(topicCmd, sizeof(topicCmd), "%s/%s/cmd", runtimeConfig.topicRoot, runtimeConfig.deviceId);
    snprintf(topicDataset, sizeof(topicDataset), "%s/%s/dataset", runtimeConfig.topicRoot, runtimeConfig.deviceId);
    snprintf(topicData, sizeof(topicData), "%s/%s/dataset/data", runtimeConfig.topicRoot, runtimeConfig.deviceId);
    snprintf(topicStatus, sizeof(topicStatus), "%s/%s/dataset/status", runtimeConfig.topicRoot, runtimeConfig.deviceId);
    snprintf(topicSummary, sizeof(topicSummary), "%s/%s/dataset/summary", runtimeConfig.topicRoot, runtimeConfig.deviceId);
    snprintf(topicAck, sizeof(topicAck), "%s/%s/cmd/ack", runtimeConfig.topicRoot, runtimeConfig.deviceId);
}

void resetRuntimeConfigDefaults() {
    copyBounded(runtimeConfig.deviceId, sizeof(runtimeConfig.deviceId), DEFAULT_DEVICE_ID_STR);
    runtimeConfig.nodeId = DEFAULT_NODE_ID;
    runtimeConfig.chId = static_cast<uint16_t>(GLD_CH_ID);
    copyBounded(runtimeConfig.wifiSsid, sizeof(runtimeConfig.wifiSsid), DEFAULT_WIFI_SSID);
    copyBounded(runtimeConfig.wifiPassword, sizeof(runtimeConfig.wifiPassword), DEFAULT_WIFI_PASSWORD);
    copyBounded(runtimeConfig.mqttHost, sizeof(runtimeConfig.mqttHost), DEFAULT_MQTT_HOST);
    runtimeConfig.mqttPort = DEFAULT_MQTT_PORT;
    copyBounded(runtimeConfig.mqttUser, sizeof(runtimeConfig.mqttUser), DEFAULT_MQTT_USER);
    copyBounded(runtimeConfig.mqttPass, sizeof(runtimeConfig.mqttPass), DEFAULT_MQTT_PASS);
    copyBounded(runtimeConfig.topicRoot, sizeof(runtimeConfig.topicRoot), DEFAULT_TOPIC_ROOT);
    clearRuntimeAesKey();
    runtimeConfig.lastDownlinkCommandId = 0;
    // Alarm commissioning state is deliberately independent of NVS.
    alarmControlMode = pgl::gld::GldAlarmControlMode::Auto;
    manualAlarmCommanded = false;
    resetRuntimeLoraDefaults();
    buildRuntimeTopics();
}

void loadRuntimeConfig() {
    resetRuntimeConfigDefaults();
    Preferences prefs;
    if (!prefs.begin("gld_app", true)) {
        logPrintln("GLD_APP_CONFIG_LOAD=DEFAULT reason=nvs_unavailable");
        applySelfTestAesFallbackIfAllowed();
        return;
    }
    String value = prefs.getString("deviceId", runtimeConfig.deviceId);
    copyBounded(runtimeConfig.deviceId, sizeof(runtimeConfig.deviceId), value.c_str());
    runtimeConfig.nodeId = nodeIdFromDeviceId(runtimeConfig.deviceId, DEFAULT_NODE_ID);
    runtimeConfig.chId = prefs.getUShort("chId", runtimeConfig.chId);
    value = prefs.getString("wifiSsid", runtimeConfig.wifiSsid);
    copyBounded(runtimeConfig.wifiSsid, sizeof(runtimeConfig.wifiSsid), value.c_str());
    value = prefs.getString("wifiPass", runtimeConfig.wifiPassword);
    copyBounded(runtimeConfig.wifiPassword, sizeof(runtimeConfig.wifiPassword), value.c_str());
    value = prefs.getString("mqttHost", runtimeConfig.mqttHost);
    copyBounded(runtimeConfig.mqttHost, sizeof(runtimeConfig.mqttHost), value.c_str());
    runtimeConfig.mqttPort = prefs.getUShort("mqttPort", runtimeConfig.mqttPort);
    value = prefs.getString("mqttUser", runtimeConfig.mqttUser);
    copyBounded(runtimeConfig.mqttUser, sizeof(runtimeConfig.mqttUser), value.c_str());
    value = prefs.getString("mqttPass", runtimeConfig.mqttPass);
    copyBounded(runtimeConfig.mqttPass, sizeof(runtimeConfig.mqttPass), value.c_str());
    value = prefs.getString("topicRoot", runtimeConfig.topicRoot);
    copyBounded(runtimeConfig.topicRoot, sizeof(runtimeConfig.topicRoot), value.c_str());
    runtimeConfig.loraFreqMHz = prefs.getFloat("loraFreq", runtimeConfig.loraFreqMHz);
    runtimeConfig.loraBwKHz = prefs.getFloat("loraBw", runtimeConfig.loraBwKHz);
    runtimeConfig.loraSf = static_cast<uint8_t>(prefs.getUChar("loraSf", runtimeConfig.loraSf));
    runtimeConfig.loraCr = static_cast<uint8_t>(prefs.getUChar("loraCr", runtimeConfig.loraCr));
    runtimeConfig.loraSyncWord = static_cast<uint8_t>(prefs.getUChar("loraSync", runtimeConfig.loraSyncWord));
    runtimeConfig.loraTxPowerDbm = static_cast<int8_t>(prefs.getShort("loraPwr", runtimeConfig.loraTxPowerDbm));
    runtimeConfig.loraPreamble = prefs.getUShort("loraPre", runtimeConfig.loraPreamble);
    runtimeConfig.loraTcxoVoltage = prefs.getFloat("loraTcxo", runtimeConfig.loraTcxoVoltage);
    runtimeConfig.loraXtalVoltage = prefs.getFloat("loraXtal", runtimeConfig.loraXtalVoltage);
    runtimeConfig.ctrlword = static_cast<uint8_t>(prefs.getUChar("ctrlword", runtimeConfig.ctrlword));
    const String storedSchema = prefs.getString("schema", "");
    if (storedSchema.length() > 0 &&
        storedSchema != pgl::firmware::CONFIG_SCHEMA_VERSION) {
        runtimeConfig.ctrlword = 0;
        logPrintf("GLD_APP_CONFIG_SCHEMA_MISMATCH stored=%s expected=%s\n",
                  storedSchema.c_str(), pgl::firmware::CONFIG_SCHEMA_VERSION);
    }
    runtimeConfig.aesKeyId = static_cast<uint8_t>(prefs.getUChar("aesKeyId", 0));
    runtimeConfig.aesKeyPresent = prefs.getBool("aesKeySet", false) &&
                                  runtimeConfig.aesKeyId != 0 &&
                                  prefs.getBytesLength("aesKey") == sizeof(runtimeConfig.aesKey);
    if (runtimeConfig.aesKeyPresent) {
        if (prefs.getBytes("aesKey", runtimeConfig.aesKey, sizeof(runtimeConfig.aesKey)) !=
            sizeof(runtimeConfig.aesKey)) {
            clearRuntimeAesKey();
        } else {
            runtimeAesKeySource = RuntimeAesKeySource::Nvs;
        }
    } else {
        clearRuntimeAesKey();
    }
    runtimeConfig.lastDownlinkCommandId = prefs.getUShort("lastCmdId", 0);
    prefs.end();
    if (runtimeConfig.ctrlword != GLD_CTRL_WORD_VALUE) {
        clearRuntimeAesKey();
        runtimeConfig.lastDownlinkCommandId = 0;
    }
    if (!runtimeConfig.aesKeyPresent) {
        applySelfTestAesFallbackIfAllowed();
    }
    char loraReason[120]{};
    if (!validateRuntimeLoraConfig(runtimeConfig, loraReason, sizeof(loraReason))) {
        resetRuntimeLoraDefaults();
        logPrintf("GLD_LORA_CONFIG_LOAD=DEFAULT reason=%s\n", loraReason);
    }
    buildRuntimeTopics();
    logPrintf("GLD_APP_CONFIG_LOAD=%s deviceId=%s nodeId=0x%04X chId=0x%04X ssid=%s mqttHost=%s mqttPort=%u topicRoot=%s aesKey=%u aesKeySource=%s keyId=%u lastCmdId=%u lora=%.3f/%.2f/SF%u/CR%u sync=0x%02X power=%d preamble=%u alarmMode=%s alarmModeSessionOnly=1\n",
              runtimeConfigValid() ? "OK" : "DEFAULT_UNCONFIGURED",
              runtimeConfig.deviceId,
              runtimeConfig.nodeId,
              runtimeConfig.chId,
              runtimeConfig.wifiSsid,
              runtimeConfig.mqttHost,
              runtimeConfig.mqttPort,
              runtimeConfig.topicRoot,
              runtimeConfig.aesKeyPresent ? 1 : 0,
              runtimeAesKeySourceName(),
              runtimeConfig.aesKeyId,
              runtimeConfig.lastDownlinkCommandId,
              runtimeConfig.loraFreqMHz,
              runtimeConfig.loraBwKHz,
              runtimeConfig.loraSf,
              runtimeConfig.loraCr,
              runtimeConfig.loraSyncWord,
              runtimeConfig.loraTxPowerDbm,
              runtimeConfig.loraPreamble,
              pgl::gld::gldAlarmControlModeName(alarmControlMode));
}

bool saveRuntimeConfig() {
    Preferences prefs;
    if (!prefs.begin("gld_app", false)) return false;
    auto putStringChecked = [&prefs](const char* key, const char* value) {
        prefs.putString(key, value != nullptr ? value : "");
        return prefs.getString(key, "__pgl_missing__") == String(value != nullptr ? value : "");
    };
    auto removeIfPresent = [&prefs](const char* key) {
        return !prefs.isKey(key) || prefs.remove(key);
    };

    // Invalidate first and publish the commit marker last. A brownout or any
    // failed write therefore leaves the config visibly invalid instead of
    // exposing a mixed old/new record behind a valid ctrlword.
    bool ok = prefs.putUChar("ctrlword", 0) == sizeof(uint8_t);
    runtimeConfig.ctrlword = 0;
    ok = putStringChecked("schema", pgl::firmware::CONFIG_SCHEMA_VERSION) && ok;
    ok = putStringChecked("deviceId", runtimeConfig.deviceId) && ok;
    ok = prefs.putUShort("nodeId", runtimeConfig.nodeId) == sizeof(uint16_t) && ok;
    ok = prefs.putUShort("chId", runtimeConfig.chId) == sizeof(uint16_t) && ok;
    ok = putStringChecked("wifiSsid", runtimeConfig.wifiSsid) && ok;
    ok = putStringChecked("wifiPass", runtimeConfig.wifiPassword) && ok;
    ok = putStringChecked("mqttHost", runtimeConfig.mqttHost) && ok;
    ok = prefs.putUShort("mqttPort", runtimeConfig.mqttPort) == sizeof(uint16_t) && ok;
    ok = putStringChecked("mqttUser", runtimeConfig.mqttUser) && ok;
    ok = putStringChecked("mqttPass", runtimeConfig.mqttPass) && ok;
    ok = putStringChecked("topicRoot", runtimeConfig.topicRoot) && ok;
    ok = prefs.putFloat("loraFreq", runtimeConfig.loraFreqMHz) == sizeof(float) && ok;
    ok = prefs.putFloat("loraBw", runtimeConfig.loraBwKHz) == sizeof(float) && ok;
    ok = prefs.putUChar("loraSf", runtimeConfig.loraSf) == sizeof(uint8_t) && ok;
    ok = prefs.putUChar("loraCr", runtimeConfig.loraCr) == sizeof(uint8_t) && ok;
    ok = prefs.putUChar("loraSync", runtimeConfig.loraSyncWord) == sizeof(uint8_t) && ok;
    ok = prefs.putShort("loraPwr", runtimeConfig.loraTxPowerDbm) == sizeof(int16_t) && ok;
    ok = prefs.putUShort("loraPre", runtimeConfig.loraPreamble) == sizeof(uint16_t) && ok;
    ok = prefs.putFloat("loraTcxo", runtimeConfig.loraTcxoVoltage) == sizeof(float) && ok;
    ok = prefs.putFloat("loraXtal", runtimeConfig.loraXtalVoltage) == sizeof(float) && ok;
    if (runtimeConfig.aesKeyPresent && runtimeConfig.aesKeyId != 0) {
        ok = prefs.putBool("aesKeySet", true) == sizeof(uint8_t) && ok;
        ok = prefs.putUChar("aesKeyId", runtimeConfig.aesKeyId) == sizeof(uint8_t) && ok;
        ok = prefs.putBytes("aesKey", runtimeConfig.aesKey, sizeof(runtimeConfig.aesKey)) ==
                 sizeof(runtimeConfig.aesKey) && ok;
    } else {
        ok = prefs.putBool("aesKeySet", false) == sizeof(uint8_t) && ok;
        ok = removeIfPresent("aesKeyId") && ok;
        ok = removeIfPresent("aesKey") && ok;
    }
    ok = prefs.putUShort("lastCmdId", runtimeConfig.lastDownlinkCommandId) == sizeof(uint16_t) && ok;
    if (ok) {
        ok = prefs.putUChar("ctrlword", GLD_CTRL_WORD_VALUE) == sizeof(uint8_t);
    }
    prefs.end();
    runtimeConfig.ctrlword = ok ? GLD_CTRL_WORD_VALUE : 0;
    return ok;
}

bool saveDownlinkReplayState() {
    Preferences prefs;
    if (!prefs.begin("gld_app", false)) return false;
    const bool stored = prefs.putUShort("lastCmdId", runtimeConfig.lastDownlinkCommandId) ==
                        sizeof(uint16_t);
    prefs.end();
    return stored;
}

bool validDeviceId(const char* deviceId) {
    if (deviceId == nullptr || strlen(deviceId) != 4) return false;
    for (uint8_t i = 0; i < 4; ++i) {
        const char c = deviceId[i];
        const bool ok = (c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f');
        if (!ok) return false;
    }
    return pgl::config::isProvisionableGldId(nodeIdFromDeviceId(deviceId, 0));
}

// New CH provisioning uses the dedicated 0010-0FFF range.  Existing NVS
// values are deliberately not rewritten on boot; this guard applies only to
// an explicit SET_CH_ADDRESS_JSON command.
bool validChId(uint16_t chId) {
    if (!pgl::config::isProvisionableChId(chId)) return false;
    if (chId == runtimeConfig.nodeId) return false;
    return true;
}

template <typename TDoc>
JsonVariant findConfigField(TDoc& doc, const char* key1,
                            const char* key2 = nullptr,
                            const char* key3 = nullptr) {
    JsonVariant value = doc[key1];
    if (!value.isNull()) return value;
    if (key2 != nullptr) {
        value = doc[key2];
        if (!value.isNull()) return value;
    }
    if (key3 != nullptr) {
        value = doc[key3];
        if (!value.isNull()) return value;
    }
    JsonVariant lora = doc["lora"];
    if (lora.isNull()) return JsonVariant();
    value = lora[key1];
    if (!value.isNull()) return value;
    if (key2 != nullptr) {
        value = lora[key2];
        if (!value.isNull()) return value;
    }
    if (key3 != nullptr) {
        value = lora[key3];
        if (!value.isNull()) return value;
    }
    return JsonVariant();
}

bool parseFloatJson(JsonVariant value, float& out) {
    if (value.isNull()) return false;
    const char* text = value.as<const char*>();
    if (text != nullptr) {
        char* end = nullptr;
        const float parsed = strtof(text, &end);
        while (end != nullptr && isspace(static_cast<unsigned char>(*end))) ++end;
        if (end == text || (end != nullptr && *end != '\0') || !std::isfinite(parsed)) return false;
        out = parsed;
        return true;
    }
    const float parsed = value.as<float>();
    if (!std::isfinite(parsed)) return false;
    out = parsed;
    return true;
}

bool parseLongJson(JsonVariant value, long& out) {
    if (value.isNull()) return false;
    const char* text = value.as<const char*>();
    if (text != nullptr) {
        char* end = nullptr;
        const long parsed = strtol(text, &end, 0);
        while (end != nullptr && isspace(static_cast<unsigned char>(*end))) ++end;
        if (end == text || (end != nullptr && *end != '\0')) return false;
        out = parsed;
        return true;
    }
    out = value.as<long>();
    return true;
}

bool readFloatConfigField(JsonDocument& doc, const char* key1, const char* key2,
                          const char* key3, float& target, bool& sawField,
                          char* reason, size_t reasonSize) {
    JsonVariant value = findConfigField(doc, key1, key2, key3);
    if (value.isNull()) return true;
    sawField = true;
    float parsed = target;
    if (!parseFloatJson(value, parsed)) {
        char msg[96];
        snprintf(msg, sizeof(msg), "%s must be numeric", key1);
        setRejectReason(reason, reasonSize, msg);
        return false;
    }
    target = parsed;
    return true;
}

bool readLongConfigField(JsonDocument& doc, const char* key1, const char* key2,
                         const char* key3, long& target, bool& sawField,
                         char* reason, size_t reasonSize) {
    JsonVariant value = findConfigField(doc, key1, key2, key3);
    if (value.isNull()) return true;
    sawField = true;
    long parsed = target;
    if (!parseLongJson(value, parsed)) {
        char msg[96];
        snprintf(msg, sizeof(msg), "%s must be an integer", key1);
        setRejectReason(reason, reasonSize, msg);
        return false;
    }
    target = parsed;
    return true;
}

bool hasRuntimeLoraPatch(JsonDocument& doc) {
    if (!doc["lora"].isNull()) return true;
    return !findConfigField(doc, "freqMHz", "loraFreqMHz", "frequencyMHz").isNull() ||
           !findConfigField(doc, "bwKHz", "loraBwKHz", "bandwidthKHz").isNull() ||
           !findConfigField(doc, "sf", "loraSf", "spreadingFactor").isNull() ||
           !findConfigField(doc, "cr", "loraCr", "codingRate").isNull() ||
           !findConfigField(doc, "syncWord", "loraSyncWord", nullptr).isNull() ||
           !findConfigField(doc, "txPowerDbm", "txPower", "powerDbm").isNull() ||
           !findConfigField(doc, "preamble", "preambleLength", "loraPreamble").isNull() ||
           !findConfigField(doc, "tcxoVoltage", "tcxoV", "loraTcxoVoltage").isNull() ||
           !findConfigField(doc, "xtalVoltage", "xtalTcxoVoltage", "loraXtalVoltage").isNull();
}

bool applyRuntimeLoraPatch(JsonDocument& doc, char* reason, size_t reasonSize) {
    RuntimeConfig updated = runtimeConfig;
    bool sawField = false;
    if (!readFloatConfigField(doc, "freqMHz", "loraFreqMHz", "frequencyMHz",
                              updated.loraFreqMHz, sawField, reason, reasonSize)) return false;
    if (!readFloatConfigField(doc, "bwKHz", "loraBwKHz", "bandwidthKHz",
                              updated.loraBwKHz, sawField, reason, reasonSize)) return false;
    if (!readFloatConfigField(doc, "tcxoVoltage", "tcxoV", "loraTcxoVoltage",
                              updated.loraTcxoVoltage, sawField, reason, reasonSize)) return false;
    if (!readFloatConfigField(doc, "xtalVoltage", "xtalTcxoVoltage", "loraXtalVoltage",
                              updated.loraXtalVoltage, sawField, reason, reasonSize)) return false;

    long sf = updated.loraSf;
    long cr = updated.loraCr;
    long syncWord = updated.loraSyncWord;
    long txPower = updated.loraTxPowerDbm;
    long preamble = updated.loraPreamble;
    if (!readLongConfigField(doc, "sf", "loraSf", "spreadingFactor",
                             sf, sawField, reason, reasonSize)) return false;
    if (!readLongConfigField(doc, "cr", "loraCr", "codingRate",
                             cr, sawField, reason, reasonSize)) return false;
    if (!readLongConfigField(doc, "syncWord", "loraSyncWord", nullptr,
                             syncWord, sawField, reason, reasonSize)) return false;
    if (!readLongConfigField(doc, "txPowerDbm", "txPower", "powerDbm",
                             txPower, sawField, reason, reasonSize)) return false;
    if (!readLongConfigField(doc, "preamble", "preambleLength", "loraPreamble",
                             preamble, sawField, reason, reasonSize)) return false;
    if (!sawField) {
        setRejectReason(reason, reasonSize, "no LoRa fields provided");
        return false;
    }
    if (sf < 0 || sf > 255 || cr < 0 || cr > 255 || syncWord < 0 || syncWord > 255 ||
        txPower < -128 || txPower > 127 || preamble < 0 || preamble > 65535) {
        setRejectReason(reason, reasonSize, "LoRa integer field is out of storage range");
        return false;
    }
    updated.loraSf = static_cast<uint8_t>(sf);
    updated.loraCr = static_cast<uint8_t>(cr);
    updated.loraSyncWord = static_cast<uint8_t>(syncWord);
    updated.loraTxPowerDbm = static_cast<int8_t>(txPower);
    updated.loraPreamble = static_cast<uint16_t>(preamble);
    if (!validateRuntimeLoraConfig(updated, reason, reasonSize)) return false;
    runtimeConfig.loraFreqMHz = updated.loraFreqMHz;
    runtimeConfig.loraBwKHz = updated.loraBwKHz;
    runtimeConfig.loraSf = updated.loraSf;
    runtimeConfig.loraCr = updated.loraCr;
    runtimeConfig.loraSyncWord = updated.loraSyncWord;
    runtimeConfig.loraTxPowerDbm = updated.loraTxPowerDbm;
    runtimeConfig.loraPreamble = updated.loraPreamble;
    runtimeConfig.loraTcxoVoltage = updated.loraTcxoVoltage;
    runtimeConfig.loraXtalVoltage = updated.loraXtalVoltage;
    return true;
}

void formatHex4(uint16_t value, char* out, size_t outSize) {
    snprintf(out, outSize, "%04X", value);
}

void nullingLogLine(const char* text) {
    logPrintln(text);
}

const char* datasetStateName() {
    return datasetState == DatasetState::Running ? "running" : "idle";
}

const char* sampleStepName() {
    switch (sampleStep) {
        case SampleStep::FanOn: return "fan_on";
        case SampleStep::FanSettle: return "fan_settle";
        case SampleStep::Scan: return "scan";
        case SampleStep::None:
        default:
            return "idle";
    }
}

void setRecoveryReason(const char* reason) {
    copyBounded(lastRecoveryReason, sizeof(lastRecoveryReason), reason != nullptr ? reason : "unknown");
    lastRecoveryMs = millis();
}

bool bootRecoveryDelayActive() {
    return bootRecoveryArmed &&
           static_cast<int32_t>(millis() - bootRecoveryDueMs) < 0;
}

uint8_t datasetQueueTail() {
    return static_cast<uint8_t>((datasetQueueHead + datasetQueueCount) % DATASET_QUEUE_CAPACITY);
}

bool enqueueDatasetPayload(const char* payload, size_t len, uint32_t seq) {
    if (payload == nullptr || len == 0) return false;
    if (datasetQueueCount >= DATASET_QUEUE_CAPACITY) {
        logPrintf("DATASET_QUEUE_FULL seq=%lu pending=%u capacity=%u action=stop_dataset\n",
                  static_cast<unsigned long>(seq),
                  static_cast<unsigned>(datasetQueueCount),
                  static_cast<unsigned>(DATASET_QUEUE_CAPACITY));
        return false;
    }

    DatasetQueuedPayload& slot = datasetQueue[datasetQueueTail()];
    const size_t maxCopy = sizeof(slot.payload) - 1U;
    const size_t copyLen = len < maxCopy ? len : maxCopy;
    memcpy(slot.payload, payload, copyLen);
    slot.payload[copyLen] = '\0';
    slot.len = copyLen;
    slot.seq = seq;
    ++datasetQueueCount;
    ++datasetQueueEnqueued;
    logPrintf("DATASET_QUEUE_ENQUEUE seq=%lu pending=%u len=%u\n",
              static_cast<unsigned long>(seq),
              static_cast<unsigned>(datasetQueueCount),
              static_cast<unsigned>(copyLen));
    return true;
}

bool publishDatasetPayload(const char* payload, uint32_t seq, bool retry) {
    const bool ok = mqtt.connected() && mqtt.publish(topicData, payload, false);
    if (retry) {
        if (ok) {
            ++datasetQueueRetryCount;
            logPrintf("DATASET_QUEUE_RETRY seq=%lu ok=1 pending=%u\n",
                      static_cast<unsigned long>(seq),
                      static_cast<unsigned>(datasetQueueCount > 0 ? datasetQueueCount - 1U : 0U));
        } else {
            ++datasetQueueRetryFailCount;
            logPrintf("DATASET_QUEUE_RETRY seq=%lu ok=0 pending=%u\n",
                      static_cast<unsigned long>(seq),
                      static_cast<unsigned>(datasetQueueCount));
        }
    } else if (!ok) {
        ++datasetPublishFailCount;
    }
    return ok;
}

void flushDatasetQueue() {
    if (datasetQueueCount == 0 || !mqtt.connected()) return;
    for (uint8_t i = 0; i < DATASET_QUEUE_FLUSH_PER_LOOP && datasetQueueCount > 0; ++i) {
        DatasetQueuedPayload& slot = datasetQueue[datasetQueueHead];
        if (!publishDatasetPayload(slot.payload, slot.seq, true)) {
            break;
        }
        datasetQueueHead = static_cast<uint8_t>((datasetQueueHead + 1U) % DATASET_QUEUE_CAPACITY);
        --datasetQueueCount;
    }
}

void noteAdsReadHealth(uint8_t okCount, const char* context) {
    if (okCount > 0) {
        adsReadFailStreak = 0;
        return;
    }
    if (adsReadFailStreak < 255) ++adsReadFailStreak;
    logPrintf("ADS_READ_HEALTH context=%s okCount=0 streak=%u\n",
              context != nullptr ? context : "unknown",
              static_cast<unsigned>(adsReadFailStreak));
    if (adsReadFailStreak >= ADS_READ_FAIL_RECOVERY_THRESHOLD) {
        adsReady = false;
        setRecoveryReason("ads_all_channels_failed");
        logPrintf("ADS_RECOVERY_ARM reason=all_channels_failed context=%s\n",
                  context != nullptr ? context : "unknown");
    }
}

void maintainAdsRecovery(const char* reason) {
    if (adsReady) return;
    if (bootRecoveryDelayActive()) return;
    const uint32_t now = millis();
    if (lastAdsRecoveryAttemptMs != 0 && now - lastAdsRecoveryAttemptMs < ADS_RECOVERY_RETRY_MS) {
        return;
    }
    lastAdsRecoveryAttemptMs = now;
    setRecoveryReason(reason != nullptr ? reason : "ads_not_ready");
    logPrintf("ADS_RECOVERY_ATTEMPT reason=%s\n", lastRecoveryReason);
    const bool ok = ads.begin(gldSpi);
    adsReady = ok;
    if (ok) {
        ++adsRecoveryCount;
        adsReadFailStreak = 0;
        movingAvg.reset();
        logPrintf("ADS_RECOVERY_RESULT=OK count=%lu\n",
                  static_cast<unsigned long>(adsRecoveryCount));
    } else {
        ++adsRecoveryFailCount;
        logPrintf("ADS_RECOVERY_RESULT=FAIL failCount=%lu\n",
                  static_cast<unsigned long>(adsRecoveryFailCount));
    }
}

void emitCommandAck(const char* cmd, const char* status,
                    const char* message, bool rebootExpected) {
    StaticJsonDocument<256> doc;
    char chIdHex[5];
    formatHex4(runtimeConfig.chId, chIdHex, sizeof(chIdHex));
    doc["deviceId"] = runtimeConfig.deviceId;
    doc["nodeId"] = runtimeConfig.nodeId;
    doc["chId"] = chIdHex;
    doc["cmd"] = cmd;
    doc["status"] = status;
    doc["message"] = message;
    doc["rebootExpected"] = rebootExpected;
    doc["mode"] = pgl::gld::gldModeName(currentMode);
    doc["uptimeMs"] = static_cast<uint32_t>(millis());
    rawJsonLine("GLD_CMD_ACK_JSON", doc);
}

void addCapabilities(JsonObject caps) {
    caps["appPing"] = true;
    caps["getInfo"] = true;
    caps["getStatus"] = true;
    caps["lightweightTelemetry"] = "GET_TELEMETRY";
    caps["serialAckJson"] = true;
    caps["runningTelemetry"] = true;
    caps["modeSwitchReboots"] = true;
    caps["datasetControlPath"] = "mqtt";
    caps["nullingConfig"] = "SET_NULLING_CONFIG_JSON thresholdV,minFinalV";
    caps["sessionMcp"] = "SET_SESSION_MCP_JSON channel,code (volatile inference-only)";
    caps["sensorModulePower"] = "SET_SENSOR_POWER_JSON channel,enabled or all,enabled (GLD2 PCF8574/TPS22919 only; volatile)";
    caps["alarmControlMode"] = "SET_ALARM_MODE_JSON mode=auto|manual (all GLD boards; volatile; boot default auto)";
    caps["manualAlarm"] = "SET_MANUAL_ALARM_JSON enabled (all GLD boards in manual mode; volatile physical-output test)";
    caps["modelNullingBinding"] = "BIND_MODEL_TO_ACTIVE_NULLING_PROFILE";
    caps["qcTracking"] = "SET_QC_RESULT_JSON channel,pass,timestamp / GET_QC_STATUS";
    caps["nullingSingleChannel"] = "RUN_NULLING_SINGLE_JSON channel";
    caps["fullScaleSweep"] = "RUN_FULLSCALE_SWEEP_JSON channel";
    caps["qcReset"] = "RESET_QC_RESULT_JSON channel / RESET_QC_ALL";
    caps["serialAppConfig"] = true;
    caps["serialDeviceId"] = true;
    caps["serialChAddress"] = "SET_CH_ADDRESS_JSON chId";
    caps["serialLoraConfig"] = "SET_LORA_CONFIG_JSON freqMHz,bwKHz,sf,cr,syncWord,txPowerDbm,preamble,tcxoVoltage,xtalVoltage";
    caps["liveLoraReinit"] = true;
    caps["runBootCheck"] = true;
    caps["i2cScan"] = "RUN_I2C_SCAN (manual only)";
    caps["tcaChannelScan"] = "RUN_TCA_CHANNEL_SCAN (manual only)";
    caps["adsMcpSweep"] = "RUN_ADS_MCP_SWEEP";
    caps["sleepNow"] = "SLEEP_NOW";
    caps["batteryServiceHold"] = "CFG press-release toggle / SERVICE_HOLD_OFF";
    caps["securityProvisioning"] = "SET_APP_CONFIG_JSON aesKeyHex";
    caps["authenticatedDownlink"] = true;
}

uint8_t sht40Crc8(const uint8_t* data, size_t length) {
    uint8_t crc = 0xFF;
    for (size_t index = 0; index < length; ++index) {
        crc ^= data[index];
        for (uint8_t bit = 0; bit < 8; ++bit) {
            crc = (crc & 0x80U) != 0U
                ? static_cast<uint8_t>((crc << 1U) ^ 0x31U)
                : static_cast<uint8_t>(crc << 1U);
        }
    }
    return crc;
}

// This sends only an I2C address phase to the root-bus TCA9548A; it does not
// select, deselect, or otherwise alter any mux channel. It therefore remains
// safe to call from the service ticks used by blocking Nulling work.
void serviceTca9548aPresenceProbe() {
#if PGL_GLD_BOARD_PROFILE_GLD2
    const uint32_t now = millis();
    if (lastTca9548aProbeMs != 0 && now - lastTca9548aProbeMs < TCA_PRESENCE_PROBE_INTERVAL_MS) return;
    Wire.beginTransmission(pgl::gld::board::TCA9548A_ADDR);
    tca9548aDetected = Wire.endTransmission() == 0;
    lastTca9548aProbeMs = now;
#endif
}

void serviceSht40() {
#if PGL_GLD_BOARD_PROFILE_GLD2
    const uint32_t now = millis();
    if (lastSht40SampleMs != 0 && now - lastSht40SampleMs < SHT40_SAMPLE_INTERVAL_MS) return;
    lastSht40SampleMs = now;

    // A selected TCA channel could contain another device at 0x44. Deselect
    // it first so this command is sent only to the root-bus SHT40.
    Wire.beginTransmission(pgl::gld::board::TCA9548A_ADDR);
    Wire.write(static_cast<uint8_t>(0));
    tca9548aDetected = Wire.endTransmission() == 0;
    lastTca9548aProbeMs = now;

    Wire.beginTransmission(SHT40_I2C_ADDR);
    Wire.write(SHT40_MEASURE_HIGH_PRECISION_CMD);
    if (Wire.endTransmission() != 0) {
        sht40Detected = false;
        sht40Valid = false;
        return;
    }
    sht40Detected = true;

    delay(SHT40_CONVERSION_MS);
    const uint8_t received = Wire.requestFrom(static_cast<int>(SHT40_I2C_ADDR), 6);
    if (received != 6) {
        while (Wire.available()) Wire.read();
        sht40Valid = false;
        return;
    }

    uint8_t payload[6]{};
    for (uint8_t index = 0; index < sizeof(payload); ++index) payload[index] = Wire.read();
    if (sht40Crc8(payload, 2) != payload[2] || sht40Crc8(payload + 3, 2) != payload[5]) {
        sht40Valid = false;
        return;
    }

    const uint16_t rawTemperature = static_cast<uint16_t>((payload[0] << 8U) | payload[1]);
    const uint16_t rawHumidity = static_cast<uint16_t>((payload[3] << 8U) | payload[4]);
    sht40TemperatureC = -45.0f + 175.0f * (static_cast<float>(rawTemperature) / 65535.0f);
    const float relativeHumidity = -6.0f + 125.0f * (static_cast<float>(rawHumidity) / 65535.0f);
    sht40RelativeHumidity = constrain(relativeHumidity, 0.0f, 100.0f);
    sht40Valid = std::isfinite(sht40TemperatureC) && std::isfinite(sht40RelativeHumidity);
#endif
}

void addEnvironmentJson(JsonObject parent) {
    JsonObject environment = parent.createNestedObject("environment");
#if PGL_GLD_BOARD_PROFILE_GLD2
    environment["available"] = true;
    environment["detected"] = sht40Detected;
    environment["valid"] = sht40Valid;
    environment["sensor"] = "SHT40";
    environment["address"] = "0x44";
    environment["sampleMs"] = lastSht40SampleMs;
    environment["sampleAgeMs"] = lastSht40SampleMs == 0 ? -1 : static_cast<uint32_t>(millis() - lastSht40SampleMs);
    JsonObject tca = environment.createNestedObject("tca9548a");
    tca["address"] = "0x71";
    tca["detected"] = tca9548aDetected;
    tca["sampleMs"] = lastTca9548aProbeMs;
    tca["sampleAgeMs"] = lastTca9548aProbeMs == 0 ? -1 : static_cast<uint32_t>(millis() - lastTca9548aProbeMs);
    if (sht40Valid) {
        environment["temperatureC"] = sht40TemperatureC;
        environment["relativeHumidityPct"] = sht40RelativeHumidity;
    }
#else
    environment["available"] = false;
    environment["valid"] = false;
    JsonObject tca = environment.createNestedObject("tca9548a");
    tca["detected"] = false;
#endif
}

void addTelemetry(JsonObject telemetry) {
    telemetry["valid"] = latestTelemetryValid;
    telemetry["sampleMs"] = lastScanMs;
    telemetry["gasClass"] = lastResult.gasClass;
    telemetry["gasName"] = pgl::gld::gldGasClassName(lastResult.gasClass);
    telemetry["confidence"] = lastResult.confidence;
    // `alarm` remains the inference/product alarm; a manual hardware test
    // must never be misreported as a detected gas alarm.
    telemetry["alarm"] = lastAlarm;
    telemetry["inferenceAlarm"] = lastAlarm;
    telemetry["alarmControlMode"] =
        pgl::gld::gldAlarmControlModeName(alarmControlMode);
    telemetry["manualAlarmCommanded"] = manualAlarmCommanded;
    telemetry["physicalAlarmCommanded"] = physicalAlarmCommanded;

    JsonArray voltage = telemetry.createNestedArray("sensorVoltage");
    JsonArray gain = telemetry.createNestedArray("sensorGain");
    JsonArray status = telemetry.createNestedArray("sensorStatus");
    JsonArray order = telemetry.createNestedArray("featureOrder");
    JsonArray dacCode = telemetry.createNestedArray("dacCodeApplied");
    JsonArray dacVerified = telemetry.createNestedArray("dacVerified");
    JsonArray dacVerifiedAtMs = telemetry.createNestedArray("dacVerifiedAtMs");
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        voltage.add(latestSensorVoltage[ch]);
        gain.add(latestSensorGain[ch]);
        status.add(latestSensorStatus[ch]);
        order.add(pgl::gld::board::SENSOR_NAMES[ch]);
        dacCode.add(runtimeMcpExpected[ch]);
        dacVerified.add(runtimeMcpReadbackVerified[ch]);
        dacVerifiedAtMs.add(runtimeMcpVerifiedAtMs[ch]);
    }
}

// GLD2's PCF8574 drives TPS22919 EN0..EN7. The PCF8574 is output-only in
// this application, so this reports the last PCF command, not a measured
// voltage at each H1..H8 module connector.
void addSensorPowerJson(JsonObject parent) {
    JsonObject sensorPower = parent.createNestedObject("sensorPower");
    sensorPower["available"] = pgl::gld::board::HAS_PCF8574;
    sensorPower["ready"] = pcfReady;
    sensorPower["commanded"] = true;
    if (!pgl::gld::board::HAS_PCF8574) return;

    const uint8_t outputs = pcf8574.outputs();
    sensorPower["outputMask"] = outputs;
    JsonArray channels = sensorPower.createNestedArray("channels");
    JsonArray enChannels = sensorPower.createNestedArray("enChannels");
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        const uint8_t en = pgl::gld::board::SENSOR_TO_POWER_EN[ch];
        channels.add((outputs & static_cast<uint8_t>(1u << en)) != 0);
        enChannels.add(en);
    }
}

// This is deliberately separate from GET_STATUS: the operator requests it on
// every Running poll, while GET_STATUS remains the complete configuration and
// diagnostic snapshot used after connect and operator actions.
void emitTelemetryJson() {
    // Telemetry includes eight-element voltage/gain/status/DAC arrays plus
    // GLD2 sensorPower.channels and enChannels. Keep sufficient node metadata
    // headroom so the final MQ6/MQ2 entries cannot be silently omitted.
    static StaticJsonDocument<4096> doc;
    doc.clear();
    doc["deviceId"] = runtimeConfig.deviceId;
    doc["mode"] = pgl::gld::gldModeName(currentMode);
    doc["uptimeMs"] = static_cast<uint32_t>(millis());
    doc["alarmLatched"] = pgl::gld::readGldAlarmLatched();

    JsonObject model = doc.createNestedObject("model");
    model["inferenceValid"] = lastInferenceValid;
    model["sensorFault"] = sensorFaultActive;

    JsonObject telemetry = doc.createNestedObject("telemetry");
    addTelemetry(telemetry);
    addEnvironmentJson(doc.as<JsonObject>());
    addSensorPowerJson(doc.as<JsonObject>());
    if (doc.overflowed()) {
        logPrintln("GLD_TELEMETRY_JSON_OVERFLOW capacity=4096");
    }
    rawJsonLine("GLD_TELEMETRY_JSON", doc);
}

void emitInfoJson() {
    static StaticJsonDocument<1536> doc;
    doc.clear();
    char chIdHex[5];
    formatHex4(runtimeConfig.chId, chIdHex, sizeof(chIdHex));
    doc["deviceId"] = runtimeConfig.deviceId;
    doc["nodeId"] = runtimeConfig.nodeId;
    doc["targetChId"] = chIdHex;
    doc["firmwareName"] = pgl::firmware::GLD_FIRMWARE_NAME;
    doc["firmwareVersion"] = pgl::firmware::GLD_FIRMWARE_VERSION;
    doc["protocolVersion"] = pgl::firmware::PROTOCOL_VERSION;
    doc["boardProfile"] = BOARD_PROFILE;
    doc["mode"] = pgl::gld::gldModeName(currentMode);
    doc["batteryServiceHold"] = serviceHoldActive;
    doc["baud"] = 115200;
    doc["sensorCount"] = pgl::gld::board::SENSOR_COUNT;
    JsonObject modbus = doc.createNestedObject("modbus");
    modbus["available"] = pgl::gld::board::HAS_RS485;
    modbus["ready"] = modbusReady;
#if PGL_GLD_BOARD_PROFILE_GLD2
    modbus["role"] = "slave";
    modbus["unitId"] = pgl::gld::GldModbusRtu::kDefaultUnitId;
    modbus["baud"] = pgl::gld::GldModbusRtu::kDefaultBaud;
    modbus["format"] = "8N1";
    modbus["readOnly"] = true;
#endif
    JsonObject pcf = doc.createNestedObject("pcf8574");
    pcf["available"] = pgl::gld::board::HAS_PCF8574;
    pcf["ready"] = pcfReady;
    pcf["allLoadSwitchesOn"] = pgl::gld::board::HAS_PCF8574 &&
        pcfAllLoadSwitchesOn;
    if (pgl::gld::board::HAS_PCF8574) {
        pcf["address"] = pgl::gld::board::PCF8574_ADDR;
        pcf["outputs"] = pcf8574.outputs();
    }
    addSensorPowerJson(doc.as<JsonObject>());
    doc["mqttTopicRoot"] = runtimeConfig.topicRoot;
    JsonObject starLora = doc.createNestedObject("starLora");
    starLora["freqMHz"] = runtimeConfig.loraFreqMHz;
    starLora["bwKHz"] = runtimeConfig.loraBwKHz;
    starLora["sf"] = runtimeConfig.loraSf;
    starLora["cr"] = runtimeConfig.loraCr;
    starLora["syncWord"] = runtimeConfig.loraSyncWord;
    starLora["txPowerDbm"] = runtimeConfig.loraTxPowerDbm;
    starLora["preamble"] = runtimeConfig.loraPreamble;
    starLora["tcxoVoltage"] = runtimeConfig.loraTcxoVoltage;
    starLora["xtalVoltage"] = runtimeConfig.loraXtalVoltage;
    starLora["runtime"] = true;
    doc["radioReady"] = radioReady;
    JsonObject appConfig = doc.createNestedObject("appConfig");
    appConfig["wifiSsid"] = runtimeConfig.wifiSsid;
    appConfig["mqttHost"] = runtimeConfig.mqttHost;
    appConfig["mqttPort"] = runtimeConfig.mqttPort;
    appConfig["mqttUser"] = runtimeConfig.mqttUser;
    appConfig["topicRoot"] = runtimeConfig.topicRoot;
    appConfig["configValid"] = runtimeConfigValid();
    JsonObject security = doc.createNestedObject("security");
    security["aesKeyProvisioned"] =
        runtimeAesKeySource == RuntimeAesKeySource::Nvs;
    security["aesKeyPresent"] = runtimeConfig.aesKeyPresent;
    security["aesKeySource"] = runtimeAesKeySourceName();
    security["keyId"] = runtimeConfig.aesKeyId;
    security["selfTestFallbackAllowed"] = GLD_ALLOW_SELFTEST_AES_FALLBACK ? true : false;
    security["lastDownlinkCommandId"] = runtimeConfig.lastDownlinkCommandId;
    JsonObject caps = doc.createNestedObject("capabilities");
    addCapabilities(caps);
    rawJsonLine("GLD_INFO_JSON", doc);
}

void emitStatusJson() {
    const pgl::gld::GldPowerReading power = pgl::gld::readGldPower();
    // Status carries nested boot, runtime-MCP, power, telemetry, PCF, and
    // manual-alarm objects. ArduinoJson's memory use exceeds serialized bytes
    // because every key and nested node needs metadata; 8 KiB leaves measured
    // headroom rather than silently dropping trailing status fields.
    static StaticJsonDocument<8192> doc;
    doc.clear();
    char chIdHex[5];
    formatHex4(runtimeConfig.chId, chIdHex, sizeof(chIdHex));
    doc["deviceId"] = runtimeConfig.deviceId;
    doc["nodeId"] = runtimeConfig.nodeId;
    doc["targetChId"] = chIdHex;
    doc["mode"] = pgl::gld::gldModeName(currentMode);
    doc["uptimeMs"] = static_cast<uint32_t>(millis());
    doc["debugEnabled"] = debugEnabled;

    JsonObject powerObj = doc.createNestedObject("power");
    powerObj["mode"] = pgl::gld::gldPowerModeName(power.mode);
    powerObj["externalPower"] = power.externalPower;
    powerObj["batteryMv"] = power.batteryMv;
    powerObj["batteryValid"] = power.batteryValid;
    powerObj["batteryDetected"] = power.batteryDetected;
    powerObj["batterySenseStatus"] = pgl::gld::gldBatterySenseStatusName(power.batterySenseStatus);
    powerObj["batteryLow"] = power.batteryLow;
    powerObj["batteryCritical"] = power.batteryCritical;
    powerObj["sourceAmbiguous"] = power.powerSourceAmbiguous;
    powerObj["stpRaw"] = pgl::gld::board::PIN_POWER_SOURCE_STATUS >= 0
        ? digitalRead(pgl::gld::board::PIN_POWER_SOURCE_STATUS) : -1;
    powerObj["stpSource"] = pgl::gld::board::PIN_POWER_SOURCE_STATUS < 0
        ? "unavailable" : (readStpSource24V() ? "24V" : "BATTERY");
    powerObj["serviceHoldActive"] = serviceHoldActive;
    powerObj["serviceHoldEffective"] = batteryPowerMode &&
        (serviceHoldActive || batteryPersistenceFaultHold ||
         digitalRead(pgl::gld::board::PIN_USER_BUTTON) == LOW ||
         !cfgButtonRawHigh || cfgButtonPressArmed);

    JsonObject batterySession = doc.createNestedObject("batterySession");
    batterySession["state"] = batterySessionStateName(batterySessionState);
    batterySession["startedMs"] = batterySessionStartedMs;
    batterySession["stateStartedMs"] = batteryStateStartedMs;
    batterySession["validSampleBatches"] = batteryValidSampleBatches;
    batterySession["requiredSampleBatches"] = BATTERY_VALID_SAMPLE_BATCHES;
    batterySession["alarmTxAttempts"] = batteryAlarmTxAttempts;
    batterySession["alarmTxAttemptLimit"] = BATTERY_ALARM_TX_ATTEMPTS;
    batterySession["alarmAckReceived"] = batteryAlarmAckReceived;
    batterySession["pendingAlarm"] = batteryPendingAlarm.active;
    batterySession["pendingSaveRequired"] = batteryPendingSaveRequired;
    batterySession["persistenceFaultHold"] = batteryPersistenceFaultHold;
    batterySession["completionReason"] = batteryCompletionReason;

    JsonObject boot = doc.createNestedObject("bootHealth");
    boot["adsReady"] = adsReady;
    boot["adsDrdyLevel"] = lastBootAdsDrdyLevel;
    boot["adsDrdyPulldownLevel"] = lastBootAdsDrdyPulldownLevel;
    boot["adsDrdyPullupLevel"] = lastBootAdsDrdyPullupLevel;
    boot["adsMisoPulldownLevel"] = lastBootAdsMisoPulldownLevel;
    boot["adsMisoPullupLevel"] = lastBootAdsMisoPullupLevel;
    boot["adsCsLevel"] = lastBootAdsCsLevel;
    boot["adsSyncLevel"] = lastBootAdsSyncLevel;
    boot["adsStatus"] = lastBootAdsStatus;
    boot["adsMux"] = lastBootAdsMux;
    boot["adsAdcon"] = lastBootAdsAdcon;
    boot["adsDrate"] = lastBootAdsDrate;
    boot["adsReason"] = lastBootAdsReason;
    boot["tcaOk"] = lastBootTcaOk;
    boot["mcpOkCount"] = lastBootMcpOkCount;
    JsonArray mcpOk = boot.createNestedArray("mcpOk");
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        mcpOk.add(lastBootMcpOk[ch]);
    }
    JsonArray mcpAddrMask = boot.createNestedArray("mcpAddrMask");
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        mcpAddrMask.add(lastBootMcpAddrMask[ch]);
    }
    boot["mcpControlTested"] = lastBootMcpControlTested;
    boot["mcpControlOkCount"] = lastBootMcpControlOkCount;
    JsonArray mcpControlOk = boot.createNestedArray("mcpControlOk");
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        mcpControlOk.add(lastBootMcpControlOk[ch]);
    }
    boot["dacReady"] = dacReady;
    boot["radioReady"] = radioReady;
    boot["mlReady"] = mlReady;
    boot["nullingProfileApplied"] = nullingProfileApplied;
    boot["modelProfileReady"] = modelProfileReady;

    JsonArray runtimeMcpCode = doc.createNestedArray("runtimeMcpCode");
    JsonArray runtimeMcpReadbackJson = doc.createNestedArray("runtimeMcpReadback");
    JsonArray runtimeMcpVerifiedJson = doc.createNestedArray("runtimeMcpVerified");
    JsonArray runtimeMcpVerifiedAtMsJson = doc.createNestedArray("runtimeMcpVerifiedAtMs");
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        runtimeMcpCode.add(runtimeMcpExpected[ch]);
        runtimeMcpReadbackJson.add(runtimeMcpReadback[ch]);
        runtimeMcpVerifiedJson.add(runtimeMcpReadbackVerified[ch]);
        runtimeMcpVerifiedAtMsJson.add(runtimeMcpVerifiedAtMs[ch]);
    }

    JsonObject modelStatus = doc.createNestedObject("model");
    modelStatus["profileId"] = pgl::gld::model::PROFILE_ID;
    modelStatus["scalerProfileId"] = pgl::gld::model::SCALER_PROFILE_ID;
    modelStatus["productionApproved"] = pgl::gld::model::PRODUCTION_APPROVED;
    modelStatus["boundNullingProfileId"] = modelBindingLoaded ? modelBinding.nullingProfileId : 0;
    modelStatus["activeNullingProfileId"] = nullingProfileId;
    modelStatus["bindingValid"] = modelBindingLoaded;
    modelStatus["bindingModelMatches"] = modelBindingLoaded &&
        modelBinding.modelFingerprint == pgl::gld::modelBindingFingerprint(
            pgl::gld::model::PROFILE_ID, pgl::gld::model::SCALER_PROFILE_ID);
    modelStatus["dacVerificationReady"] = runtimeDacVerificationReady();
    modelStatus["profileReady"] = modelProfileReady;
    modelStatus["inferenceValid"] = lastInferenceValid;
    modelStatus["sensorFault"] = sensorFaultActive;

    JsonObject lora = doc.createNestedObject("lora");
    lora["beginState"] = lastLoraBeginState;
    lora["lastTxState"] = lastLoraTxState;
    lora["lastTxOk"] = lastLoraTxOk;
    lora["txSeq"] = txSeq;
    lora["txCounter"] = txCounter;
    lora["aesKeyProvisioned"] =
        runtimeAesKeySource == RuntimeAesKeySource::Nvs;
    lora["aesKeyPresent"] = runtimeConfig.aesKeyPresent;
    lora["aesKeySource"] = runtimeAesKeySourceName();
    lora["keyId"] = runtimeConfig.aesKeyId;
    lora["lastDownlinkCommandId"] = runtimeConfig.lastDownlinkCommandId;
    lora["freqMHz"] = runtimeConfig.loraFreqMHz;
    lora["bwKHz"] = runtimeConfig.loraBwKHz;
    lora["sf"] = runtimeConfig.loraSf;
    lora["cr"] = runtimeConfig.loraCr;
    lora["syncWord"] = runtimeConfig.loraSyncWord;
    lora["txPowerDbm"] = runtimeConfig.loraTxPowerDbm;
    lora["preamble"] = runtimeConfig.loraPreamble;
    lora["tcxoVoltage"] = runtimeConfig.loraTcxoVoltage;
    lora["xtalVoltage"] = runtimeConfig.loraXtalVoltage;

    JsonObject dataset = doc.createNestedObject("dataset");
    dataset["state"] = datasetStateName();
    dataset["step"] = sampleStepName();
    dataset["label"] = currentLabel;
    dataset["seq"] = datasetSeq;
    dataset["targetSamples"] = targetSamples;
    dataset["sampleIntervalMs"] = sampleIntervalMs;
    dataset["maxDurationMs"] = maxDurationMs;
    dataset["useFanIntake"] = useFanIntake;
    dataset["fanAvailable"] = pgl::gld::board::HAS_DC_FAN;
    dataset["fanOnMs"] = fanOnMs;
    dataset["postFanSettleMs"] = postFanSettleMs;
    dataset["nullingProfileId"] = nullingProfileId;
    dataset["queuePending"] = datasetQueueCount;
    dataset["queueCapacity"] = DATASET_QUEUE_CAPACITY;
    dataset["queueEnqueued"] = datasetQueueEnqueued;
    dataset["queueDropped"] = datasetQueueDropped;
    dataset["publishFailCount"] = datasetPublishFailCount;
    dataset["retryCount"] = datasetQueueRetryCount;
    dataset["retryFailCount"] = datasetQueueRetryFailCount;
    dataset["rejectedSamples"] = datasetRejectedSamples;
    dataset["lastRejectReason"] =
        pgl::gld::gldDatasetRejectReasonName(lastDatasetRejectReason);
    dataset["lastRejectChannel"] = static_cast<int>(lastDatasetRejectChannel);
    dataset["lastRejectOkFiniteCount"] = lastDatasetRejectOkFiniteCount;
    dataset["lastRejectStatus"] = lastDatasetRejectStatus;
    dataset["lastRejectGain"] = lastDatasetRejectGain;
    dataset["lastRejectSaturated"] = lastDatasetRejectSaturated;

    JsonObject recovery = doc.createNestedObject("recovery");
    recovery["wifiReconnectCount"] = wifiReconnectCount;
    recovery["wifiReconnectFailCount"] = wifiReconnectFailCount;
    recovery["mqttReconnectCount"] = mqttReconnectCount;
    recovery["mqttConnectFailCount"] = mqttConnectFailCount;
    recovery["lastMqttState"] = lastMqttState;
    recovery["adsRecoveryCount"] = adsRecoveryCount;
    recovery["adsRecoveryFailCount"] = adsRecoveryFailCount;
    recovery["adsReadFailStreak"] = adsReadFailStreak;
    recovery["lastReason"] = lastRecoveryReason;
    recovery["lastRecoveryMs"] = lastRecoveryMs;
    recovery["bootRecoveryArmed"] = bootRecoveryArmed;
    recovery["bootRecoveryDueMs"] = bootRecoveryDueMs;
    recovery["bootRecoveryReason"] = bootRecoveryReason;
    recovery["bootRecoveryNonAdsFailure"] = bootRecoveryNonAdsFailure;
    recovery["bootRecoveryRestartCount"] = bootRecoveryRestartCount;

    JsonObject nulling = doc.createNestedObject("nulling");
    nulling["done"] = nullDone;
    nulling["retryArmed"] = nullingRetryArmed;
    nulling["retryAvailable"] = nullingRetryAvailable;
    nulling["retryFailedAvailable"] = nullingRetryFailedAvailable;
    nulling["retryFailedMask"] = pendingNullingFailedMask();
    nulling["attemptCount"] = nullingAttemptCount;
    nulling["nextRetryMs"] = nextNullingRetryMs;
    nulling["thresholdV"] = nullingConfig.thresholdV;
    nulling["minFinalV"] = nullingConfig.minFinalV;

    JsonObject telemetry = doc.createNestedObject("telemetry");
    addTelemetry(telemetry);
    addEnvironmentJson(doc.as<JsonObject>());
    JsonObject modbus = doc.createNestedObject("modbus");
    modbus["available"] = pgl::gld::board::HAS_RS485;
    modbus["ready"] = modbusReady;
    JsonObject pcf = doc.createNestedObject("pcf8574");
    pcf["available"] = pgl::gld::board::HAS_PCF8574;
    pcf["ready"] = pcfReady;
    pcf["allLoadSwitchesOn"] = pgl::gld::board::HAS_PCF8574 &&
        pcfAllLoadSwitchesOn;
    if (pgl::gld::board::HAS_PCF8574) {
        pcf["address"] = pgl::gld::board::PCF8574_ADDR;
        pcf["outputs"] = pcf8574.outputs();
    }
    addSensorPowerJson(doc.as<JsonObject>());
    JsonObject alarmControl = doc.createNestedObject("alarmControl");
    // AUTO/MANUAL is a common Operator Hub contract.  The physical drive is
    // board-specific: GLD1 uses its active-low lamp/buzzer/LED outputs while
    // GLD2 uses EN_BOOST followed by its ALARM output.
    alarmControl["available"] = true;
    alarmControl["mode"] = pgl::gld::gldAlarmControlModeName(alarmControlMode);
    alarmControl["defaultMode"] = "auto";
    alarmControl["modePersisted"] = false;
    alarmControl["sessionOnly"] = true;
    alarmControl["resetsToAutoOnBoot"] = true;
    // Compatibility for an older console: manual controls are available only
    // while the selected mode is MANUAL.
    alarmControl["manualOnly"] =
        alarmControlMode == pgl::gld::GldAlarmControlMode::Manual;
    alarmControl["manualCommanded"] = manualAlarmCommanded;
    alarmControl["inferenceAlarm"] = lastAlarm;
    alarmControl["physicalCommanded"] = physicalAlarmCommanded;
#if PGL_GLD_BOARD_PROFILE_GLD2
    alarmControl["outputDrive"] = "steady_24v";
    alarmControl["externalDevicePattern"] = "self_pulsed_1s_on_1s_off";
#else
    alarmControl["outputDrive"] = "active_low_lamp_buzzer_led";
    alarmControl["externalDevicePattern"] = "board_outputs_follow_command";
#endif
    doc["alarmLatched"] = pgl::gld::readGldAlarmLatched();

    if (doc.overflowed()) {
        logPrintln("GLD_STATUS_JSON_OVERFLOW capacity=8192");
    }

    rawJsonLine("GLD_STATUS_JSON", doc);
}

// ---------------------------------------------------------------------------
// Mode command handler — NVS write + reboot
// ---------------------------------------------------------------------------

void serviceDelay(uint32_t durationMs);
void runBootCheckFromSerialCommand();
void runCurrentStateCheckFromSerialCommand();
void runI2cScanFromSerialCommand();
void runTcaChannelScanFromSerialCommand();
void runAdsMcpSweepFromSerialCommand();
void sleepNowFromSerialCommand();
bool serviceHoldBlocksClr();
void setServiceHoldActive(bool active, const char* source);

void onModeCmd(pgl::gld::GldMode newMode) {
    if (!pgl::gld::writeGldMode(newMode)) {
        emitCommandAck("SET_MODE", "error", "mode persistence failed; restart cancelled", false);
        logPrintf("GLD_MODE_SWITCH current=%s new=%s persisted=0 restart=0\n",
                  pgl::gld::gldModeName(currentMode),
                  pgl::gld::gldModeName(newMode));
        return;
    }
    emitCommandAck("SET_MODE", "ok", "mode switch accepted", true);
    logPrintf("GLD_MODE_SWITCH current=%s new=%s\n",
              pgl::gld::gldModeName(currentMode),
              pgl::gld::gldModeName(newMode));
    ESP.restart();
}

void onDebugCmd(bool enabled) {
    debugEnabled = enabled;
    emitCommandAck(enabled ? "DEBUG_ON" : "DEBUG_OFF", "ok",
                   enabled ? "serial debug enabled" : "serial debug disabled",
                   false);
    rawPrintln(enabled
        ? "DEBUG_ON accepted, serial debug enabled"
        : "DEBUG_OFF accepted, serial debug disabled");
}

void rebootAfterAckIfRequested(bool reboot) {
    if (!reboot) return;
    serviceDelay(250);
    ESP.restart();
}

void restartFromSerialCommand() {
    emitCommandAck("RESTART", "ok", "restarting", true);
    // Deliberately a plain delay(), not serviceDelay(): RESTART is checked
    // unconditionally in checkSerial(), even reentrant from deep inside a
    // blocking nulling/full-scale-sweep tick loop, and serviceDelay() calls
    // firmwareServiceTick() -> checkSerial() again - one more reentrant frame
    // on top of an already-deep call stack is enough to trip the loopTask
    // stack canary and panic instead of restarting cleanly. Serial.flush()
    // below already blocks until the ack bytes are fully transmitted, so no
    // service ticking is needed here anyway.
    delay(50);
    Serial.flush();
#if defined(ARDUINO_ARCH_ESP32)
    Serial0.flush();
#endif
    ESP.restart();
}

void sleepNowFromSerialCommand() {
    if (serviceHoldBlocksClr()) {
        emitCommandAck("SLEEP_NOW", "blocked", "battery service hold is active", false);
        logPrintln("GLD_SERVICE_HOLD_BLOCK_CLR reason=serial_sleep_now");
        return;
    }
    const pgl::gld::GldPowerReading power = pgl::gld::readGldPower();
    emitCommandAck("SLEEP_NOW", "ok", "clearing power latch via CLR", false);
    logPrintf("GLD_SERIAL_SLEEP_NOW power_off mode=%s externalPower=%u batteryMv=%u clr=HIGH_LOW_HIGH\n",
              pgl::gld::gldPowerModeName(power.mode),
              power.externalPower ? 1 : 0,
              power.batteryMv);
    serviceDelay(100);
    Serial.flush();
#if defined(ARDUINO_ARCH_ESP32)
    Serial0.flush();
#endif
    if (serviceHoldBlocksClr()) {
        emitCommandAck("SLEEP_NOW", "blocked", "CFG went low before CLR", false);
        logPrintln("GLD_SERVICE_HOLD_BLOCK_CLR reason=serial_sleep_now_final_guard");
        Serial.flush();
#if defined(ARDUINO_ARCH_ESP32)
        Serial0.flush();
#endif
        return;
    }
    pgl::gld::pulseGldPowerLatchClear();
}

// QC bench pin injection - lets the operator app manually exercise the
// TPL5010 DONE/CLR nets from the QC tab, independent of the automatic
// keepalive/sleep cycle. See docs/firmware/gld-tpl5010-wake-sleep-com10-report.md.
void injectTplDoneFromSerialCommand() {
    emitCommandAck("INJECT_TPL_DONE", "ok", "pulsing TPL5010 DONE pin once", false);
    logPrintf("GLD_SERIAL_INJECT_TPL_DONE pulse=HIGH_LOW\n");
    pgl::gld::pulseGldTpl5010Keepalive();
}

// CLR pulses the same active-low power-latch reset as SLEEP_NOW, so this
// injection can cut board power and drop the serial connection - flush the
// ack before pulsing, exactly like sleepNowFromSerialCommand().
void injectTplClrFromSerialCommand() {
    if (serviceHoldBlocksClr()) {
        emitCommandAck("INJECT_TPL_CLR", "blocked", "battery service hold is active", false);
        logPrintln("GLD_SERVICE_HOLD_BLOCK_CLR reason=serial_inject_tpl_clr");
        return;
    }
    const pgl::gld::GldPowerReading power = pgl::gld::readGldPower();
    emitCommandAck("INJECT_TPL_CLR", "ok", "pulsing power latch CLR once", false);
    logPrintf("GLD_SERIAL_INJECT_TPL_CLR mode=%s externalPower=%u batteryMv=%u clr=HIGH_LOW_HIGH\n",
              pgl::gld::gldPowerModeName(power.mode),
              power.externalPower ? 1 : 0,
              power.batteryMv);
    serviceDelay(100);
    Serial.flush();
#if defined(ARDUINO_ARCH_ESP32)
    Serial0.flush();
#endif
    if (serviceHoldBlocksClr()) {
        emitCommandAck("INJECT_TPL_CLR", "blocked", "CFG went low before CLR", false);
        logPrintln("GLD_SERVICE_HOLD_BLOCK_CLR reason=serial_inject_tpl_clr_final_guard");
        Serial.flush();
#if defined(ARDUINO_ARCH_ESP32)
        Serial0.flush();
#endif
        return;
    }
    pgl::gld::pulseGldPowerLatchClear();
}

void serviceHoldOffFromSerialCommand() {
    setServiceHoldActive(false, "serial");
    emitCommandAck("SERVICE_HOLD_OFF", "ok", "battery service hold disabled", false);
}

void onUnknownSerialCommand(const char* commandText) {
    rawPrint(commandText);
    rawPrintln(" command is unknown");
}

void logRuntimeLoraConfig(const char* marker, bool reboot, bool liveApplied) {
    logPrintf("%s freqMHz=%.3f bwKHz=%.2f sf=%u cr=%u sync=0x%02X power=%d preamble=%u tcxo=%.1f xtal=%.1f reboot=%u liveApplied=%u beginState=%d\n",
              marker,
              runtimeConfig.loraFreqMHz,
              runtimeConfig.loraBwKHz,
              runtimeConfig.loraSf,
              runtimeConfig.loraCr,
              runtimeConfig.loraSyncWord,
              runtimeConfig.loraTxPowerDbm,
              runtimeConfig.loraPreamble,
              runtimeConfig.loraTcxoVoltage,
              runtimeConfig.loraXtalVoltage,
              reboot ? 1 : 0,
              liveApplied ? 1 : 0,
              static_cast<int>(lastLoraBeginState));
}

bool applyLoraRuntimeNowIfNeeded(bool reboot, bool& liveApplied) {
    liveApplied = false;
    if (reboot || currentMode != pgl::gld::GldMode::INFERENCE) return true;
    liveApplied = true;
    radioReady = beginLoraRadio();
    return radioReady;
}

void onSetLoraConfigJson(const char* payload) {
    StaticJsonDocument<512> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("SET_LORA_CONFIG", "error", "invalid json", false);
        return;
    }
    const bool reboot = doc["reboot"] | false;
    char reason[160]{};
    if (!applyRuntimeLoraPatch(doc, reason, sizeof(reason))) {
        emitCommandAck("SET_LORA_CONFIG", "rejected", reason, false);
        return;
    }
    if (!saveRuntimeConfig()) {
        emitCommandAck("SET_LORA_CONFIG", "error", "failed to save lora config", false);
        return;
    }
    bool liveApplied = false;
    const bool liveOk = applyLoraRuntimeNowIfNeeded(reboot, liveApplied);
    logRuntimeLoraConfig("GLD_LORA_CONFIG_SAVE=OK", reboot, liveApplied);
    if (!liveOk) {
        emitCommandAck("SET_LORA_CONFIG", "error", "lora config saved but radio reinit failed", false);
        return;
    }
    const char* message = reboot
        ? "lora config saved; rebooting"
        : liveApplied ? "lora config saved; radio reapplied" : "lora config saved; applies on next running init";
    emitCommandAck("SET_LORA_CONFIG", "ok", message, reboot);
    rebootAfterAckIfRequested(reboot);
}

void onSetAppConfigJson(const char* payload) {
    StaticJsonDocument<1536> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("SET_APP_CONFIG", "error", "invalid json", false);
        return;
    }
    const char* ssid = doc["ssid"].as<const char*>();
    if (ssid == nullptr) ssid = doc["wifiSsid"].as<const char*>();
    if (ssid == nullptr) ssid = runtimeConfig.wifiSsid;
    const char* password = doc["password"].as<const char*>();
    if (password == nullptr) password = doc["wifiPassword"].as<const char*>();
    if (password == nullptr) password = runtimeConfig.wifiPassword;
    const char* mqttHost = doc["mqttHost"].as<const char*>();
    if (mqttHost == nullptr) mqttHost = doc["brokerHost"].as<const char*>();
    if (mqttHost == nullptr) mqttHost = runtimeConfig.mqttHost;
    const uint16_t mqttPort = doc["mqttPort"] | runtimeConfig.mqttPort;
    const char* mqttUser = doc["mqttUser"].as<const char*>();
    if (mqttUser == nullptr) mqttUser = runtimeConfig.mqttUser;
    const char* mqttPass = doc["mqttPass"].as<const char*>();
    if (mqttPass == nullptr) mqttPass = runtimeConfig.mqttPass;
    const char* topicRoot = doc["topicRoot"].as<const char*>();
    if (topicRoot == nullptr) topicRoot = runtimeConfig.topicRoot;
    const bool reboot = doc["reboot"] | true;
    const bool clearAesKey = doc["clearAesKey"] | false;
    const char* aesKeyHex = doc["aesKeyHex"].as<const char*>();
    if (aesKeyHex == nullptr) aesKeyHex = doc["gldAes128KeyHex"].as<const char*>();
    if (aesKeyHex == nullptr) aesKeyHex = doc["GLD_AES128_KEY_HEX"].as<const char*>();
    const bool aesKeyProvided = aesKeyHex != nullptr && strlen(aesKeyHex) > 0;
    uint8_t parsedAesKey[16]{};
    const uint8_t requestedKeyId = static_cast<uint8_t>(doc["keyId"] | runtimeConfig.aesKeyId);
    const bool loraPatch = hasRuntimeLoraPatch(doc);

    if (strlen(ssid) == 0 || strlen(mqttHost) == 0 || strlen(topicRoot) == 0 || mqttPort == 0) {
        emitCommandAck("SET_APP_CONFIG", "rejected", "ssid, mqttHost, mqttPort, and topicRoot are required", false);
        return;
    }
    if (aesKeyProvided) {
        if (requestedKeyId == 0) {
            emitCommandAck("SET_APP_CONFIG", "rejected", "keyId must be 1..255 when aesKeyHex is provided", false);
            return;
        }
        if (!parseAesKeyHex(aesKeyHex, parsedAesKey)) {
            emitCommandAck("SET_APP_CONFIG", "rejected", "aesKeyHex must contain exactly 16 bytes / 32 hex chars", false);
            return;
        }
    }
    if (loraPatch) {
        char reason[160]{};
        if (!applyRuntimeLoraPatch(doc, reason, sizeof(reason))) {
            emitCommandAck("SET_APP_CONFIG", "rejected", reason, false);
            return;
        }
    }

    copyBounded(runtimeConfig.wifiSsid, sizeof(runtimeConfig.wifiSsid), ssid);
    copyBounded(runtimeConfig.wifiPassword, sizeof(runtimeConfig.wifiPassword), password);
    copyBounded(runtimeConfig.mqttHost, sizeof(runtimeConfig.mqttHost), mqttHost);
    runtimeConfig.mqttPort = mqttPort;
    copyBounded(runtimeConfig.mqttUser, sizeof(runtimeConfig.mqttUser), mqttUser);
    copyBounded(runtimeConfig.mqttPass, sizeof(runtimeConfig.mqttPass), mqttPass);
    copyBounded(runtimeConfig.topicRoot, sizeof(runtimeConfig.topicRoot), topicRoot);
    if (clearAesKey) {
        clearRuntimeAesKey();
        runtimeConfig.lastDownlinkCommandId = 0;
    }
    if (aesKeyProvided) {
        runtimeConfig.aesKeyId = requestedKeyId;
        memcpy(runtimeConfig.aesKey, parsedAesKey, sizeof(runtimeConfig.aesKey));
        runtimeConfig.aesKeyPresent = true;
        runtimeAesKeySource = RuntimeAesKeySource::Nvs;
        runtimeConfig.lastDownlinkCommandId = 0;
    }
    buildRuntimeTopics();

    if (!saveRuntimeConfig()) {
        emitCommandAck("SET_APP_CONFIG", "error", "failed to save app config", false);
        return;
    }

    logPrintf("GLD_APP_CONFIG_SAVE=OK ssid=%s mqttHost=%s mqttPort=%u topicRoot=%s aesKey=%u keyId=%u reboot=%u\n",
              runtimeConfig.wifiSsid,
              runtimeConfig.mqttHost,
              runtimeConfig.mqttPort,
              runtimeConfig.topicRoot,
              runtimeConfig.aesKeyPresent ? 1 : 0,
              runtimeConfig.aesKeyId,
              reboot ? 1 : 0);
    if (loraPatch) {
        bool liveApplied = false;
        const bool liveOk = applyLoraRuntimeNowIfNeeded(reboot, liveApplied);
        logRuntimeLoraConfig("GLD_LORA_CONFIG_SAVE=OK", reboot, liveApplied);
        if (!liveOk) {
            emitCommandAck("SET_APP_CONFIG", "error", "app config saved but lora reinit failed", false);
            return;
        }
    }
    emitCommandAck("SET_APP_CONFIG", "ok", reboot ? "app config saved; rebooting" : "app config saved", reboot);
    if (!reboot) {
        mqtt.disconnect();
        WiFi.disconnect(false);
    }
    rebootAfterAckIfRequested(reboot);
}

void onSetDeviceIdJson(const char* payload) {
    StaticJsonDocument<256> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("SET_DEVICE_ID", "error", "invalid json", false);
        return;
    }
    const char* deviceId = doc["deviceId"].as<const char*>();
    if (deviceId == nullptr) deviceId = doc["id"].as<const char*>();
    if (deviceId == nullptr) deviceId = "";
    const bool reboot = doc["reboot"] | true;
    if (!validDeviceId(deviceId)) {
        emitCommandAck("SET_DEVICE_ID", "rejected", "deviceId must be a GLD ID in 1001-FEFF", false);
        return;
    }
    const uint16_t derivedNodeId = nodeIdFromDeviceId(deviceId, DEFAULT_NODE_ID);
    if (!doc["nodeId"].isNull()) {
        uint16_t explicitNodeId = 0;
        const char* nodeIdText = doc["nodeId"].as<const char*>();
        if (nodeIdText != nullptr && nodeIdText[0] != '\0') {
            explicitNodeId = nodeIdFromDeviceId(nodeIdText, 0);
        } else {
            const uint32_t nodeIdNumber = doc["nodeId"] | 0u;
            if (nodeIdNumber <= 0xFFFFU) {
                explicitNodeId = static_cast<uint16_t>(nodeIdNumber);
            }
        }
        if (explicitNodeId != derivedNodeId) {
            emitCommandAck("SET_DEVICE_ID", "rejected", "nodeId must match deviceId; omit nodeId unless it is identical", false);
            return;
        }
    }
    copyBounded(runtimeConfig.deviceId, sizeof(runtimeConfig.deviceId), deviceId);
    runtimeConfig.nodeId = derivedNodeId;
    buildRuntimeTopics();
    if (!saveRuntimeConfig()) {
        emitCommandAck("SET_DEVICE_ID", "error", "failed to save device id", false);
        return;
    }
    logPrintf("GLD_DEVICE_ID_SAVE=OK deviceId=%s nodeId=0x%04X reboot=%u\n",
              runtimeConfig.deviceId, runtimeConfig.nodeId, reboot ? 1 : 0);
    emitCommandAck("SET_DEVICE_ID", "ok", reboot ? "device id saved; rebooting" : "device id saved", reboot);
    rebootAfterAckIfRequested(reboot);
}

void onSetChAddressJson(const char* payload) {
    StaticJsonDocument<128> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("SET_CH_ADDRESS", "error", "invalid json", false);
        return;
    }
    const char* chIdStr = doc["chId"].as<const char*>();
    if (chIdStr == nullptr) chIdStr = doc["chAddress"].as<const char*>();
    if (chIdStr == nullptr) chIdStr = "";
    const bool reboot = doc["reboot"] | true;
    const uint16_t parsedChId = nodeIdFromDeviceId(chIdStr, 0);
    if (parsedChId == 0 || !validChId(parsedChId)) {
        emitCommandAck("SET_CH_ADDRESS", "rejected",
            "chId must be a CH ID in 0010-0FFF and not the GLD's own ID", false);
        return;
    }
    runtimeConfig.chId = parsedChId;
    if (!saveRuntimeConfig()) {
        emitCommandAck("SET_CH_ADDRESS", "error", "failed to save CH address", false);
        return;
    }
    logPrintf("GLD_CH_ADDRESS_SAVE=OK chId=0x%04X reboot=%u\n", runtimeConfig.chId, reboot ? 1 : 0);
    emitCommandAck("SET_CH_ADDRESS", "ok", reboot ? "CH address saved; rebooting" : "CH address saved", reboot);
    rebootAfterAckIfRequested(reboot);
}

void onSetNullingConfigJson(const char* payload) {
    StaticJsonDocument<128> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("SET_NULLING_CONFIG", "error", "invalid json", false);
        return;
    }
    const float thresholdV = doc["thresholdV"] | nullingConfig.thresholdV;
    const float minFinalV  = doc["minFinalV"] | nullingConfig.minFinalV;

    if (!(thresholdV > 0.0f) || thresholdV > pgl::gld::GLD_ADS1256_VREF_VOLTS) {
        emitCommandAck("SET_NULLING_CONFIG", "rejected", "thresholdV must be > 0 and <= VREF", false);
        return;
    }
    if (minFinalV < -pgl::gld::GLD_ADS1256_VREF_VOLTS || minFinalV > pgl::gld::GLD_ADS1256_VREF_VOLTS) {
        emitCommandAck("SET_NULLING_CONFIG", "rejected", "minFinalV must be within -VREF..VREF", false);
        return;
    }

    pgl::gld::GldNullingConfig updated{};
    updated.thresholdV = thresholdV;
    updated.minFinalV  = minFinalV;
    if (!pgl::gld::saveNullingConfig(updated)) {
        emitCommandAck("SET_NULLING_CONFIG", "error", "failed to save nulling config", false);
        return;
    }
    nullingConfig = updated;
    logPrintf("GLD_NULLING_CONFIG_SAVE=OK thresholdV=%.6f minFinalV=%.6f\n",
              nullingConfig.thresholdV, nullingConfig.minFinalV);
    emitCommandAck("SET_NULLING_CONFIG", "ok", "nulling config saved; applies on next nulling run", false);
}

// Running-card MCP trim is deliberately volatile. It writes only the MCP4725
// register, never the saved Nulling profile or model binding; boot/restart
// reapplies the saved profile and therefore clears this session adjustment.
void onSetSessionMcpJson(const char* payload) {
    StaticJsonDocument<96> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("SET_SESSION_MCP", "error", "invalid json", false);
        return;
    }
    if (!doc.containsKey("channel") || !doc.containsKey("code") ||
        !doc["channel"].is<long>() || !doc["code"].is<long>()) {
        emitCommandAck("SET_SESSION_MCP", "rejected", "channel and code integers are required", false);
        return;
    }

    const long channel = doc["channel"].as<long>();
    const long code = doc["code"].as<long>();
    if (channel < 0 || channel >= pgl::gld::board::SENSOR_COUNT) {
        emitCommandAck("SET_SESSION_MCP", "rejected", "channel must be 0..7", false);
        return;
    }
    if (code < pgl::gld::board::GLD_DAC_CODE_MIN ||
        code > pgl::gld::board::GLD_DAC_CODE_MAX) {
        emitCommandAck("SET_SESSION_MCP", "rejected", "code must be 0..4095", false);
        return;
    }
    if (currentMode != pgl::gld::GldMode::INFERENCE) {
        emitCommandAck("SET_SESSION_MCP", "rejected", "session MCP adjustment is allowed only in inference mode", false);
        return;
    }
    if (!dacReady || !dac.ready()) {
        emitCommandAck("SET_SESSION_MCP", "error", "DAC not ready", false);
        return;
    }
    const uint8_t channelIndex = static_cast<uint8_t>(channel);
#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
    // A failed transaction can still have changed the volatile register. Mark
    // the override before the first write and clear it only after a verified
    // saved-profile restore or a real restart.
    sessionMcpOverrideMask |= static_cast<uint8_t>(1u << channelIndex);
#endif
    const bool isolateForVerify = !batteryPowerMode && pgl::gld::board::HAS_PCF8574;
    if (isolateForVerify) {
        dac.captureSensorPowerState();
        dac.setAutomaticSensorPowerControl(true);
        dac.setRestoreSensorPowerAfterWrite(false);
        dac.setSensorPowerSettleMs(500);
    }
    const bool writeOk = dac.writeDac(channelIndex, static_cast<uint16_t>(code));
    uint16_t readback = 0;
    const bool readOk = writeOk && dac.readDac(channelIndex, readback);
    const bool powerRestored = !isolateForVerify || dac.restoreSensorPower();
    if (isolateForVerify) {
        dac.setAutomaticSensorPowerControl(false);
        dac.setRestoreSensorPowerAfterWrite(true);
        dac.setSensorPowerSettleMs(50);
    }
    recordRuntimeDacVerification(channelIndex, static_cast<uint16_t>(code), readback,
                                 readOk && powerRestored, "session_write", true);
    if (!writeOk || !readOk || readback != static_cast<uint16_t>(code) || !powerRestored) {
        dacReady = false;
        emitCommandAck("SET_SESSION_MCP", "error", "DAC apply/readback verification failed", false);
        return;
    }

    logPrintf("GLD_SESSION_MCP_APPLY=OK channel=%ld code=%ld persisted=0\n", channel, code);
    emitCommandAck("SET_SESSION_MCP", "ok", "session MCP applied; not saved", false);
    emitStatusJson();
}

void driveAlarmOutputs(bool inferenceAlarm);

// GLD2 routes PCF8574 P0..P7 to the active-HIGH EN inputs of the eight
// TPS22919 sensor-module load switches.  This is intentionally a volatile
// commissioning control: boot always returns every sensor module to ON and
// the command never modifies a Nulling profile, model binding, or NVS.
void onSetSensorPowerJson(const char* payload) {
    StaticJsonDocument<96> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("SET_SENSOR_POWER", "error", "invalid json", false);
        return;
    }
    if (!doc.containsKey("enabled") || !doc["enabled"].is<bool>()) {
        emitCommandAck("SET_SENSOR_POWER", "rejected", "enabled boolean is required", false);
        return;
    }
    const bool all = doc["all"] | false;
    const bool hasChannel = doc.containsKey("channel") && doc["channel"].is<long>();
    if (!all && !hasChannel) {
        emitCommandAck("SET_SENSOR_POWER", "rejected", "channel integer or all=true is required", false);
        return;
    }
    const long channel = hasChannel ? doc["channel"].as<long>() : -1;
    const bool enabled = doc["enabled"].as<bool>();
    if (!all && (channel < 0 || channel >= pgl::gld::board::SENSOR_COUNT)) {
        emitCommandAck("SET_SENSOR_POWER", "rejected", "channel must be 0..7", false);
        return;
    }
    if (!pgl::gld::board::HAS_PCF8574) {
        emitCommandAck("SET_SENSOR_POWER", "rejected", "sensor module power control requires GLD2 PCF8574 hardware", false);
        return;
    }
    if (!pcfReady || !pcf8574.ready()) {
        emitCommandAck("SET_SENSOR_POWER", "error", "PCF8574 is not ready", false);
        return;
    }

    const uint8_t current = pcf8574.outputs();
    uint8_t next = current;
    uint8_t enChannel = 0;
    if (all) {
        next = enabled ? pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_ON : 0x00;
    } else {
        enChannel = pgl::gld::board::SENSOR_TO_POWER_EN[channel];
        const uint8_t bit = static_cast<uint8_t>(1u << enChannel);
        next = enabled
            ? static_cast<uint8_t>(current | bit)
            : static_cast<uint8_t>(current & static_cast<uint8_t>(~bit));
    }
    if (!pcf8574.writeOutputs(next)) {
        pcfReady = false;
        pcfAllLoadSwitchesOn = false;
        emitCommandAck("SET_SENSOR_POWER", "error", "PCF8574 output write failed", false);
        return;
    }
    pcfAllLoadSwitchesOn = next == pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_ON;
    logPrintf("GLD_SENSOR_POWER_APPLY=OK scope=%s sensor=%ld en=%u enabled=%u outputs=0x%02X persisted=0\n",
              all ? "all" : "single", channel, static_cast<unsigned>(enChannel), enabled ? 1u : 0u, pcf8574.outputs());
    emitCommandAck("SET_SENSOR_POWER", "ok", enabled ? "sensor module enabled; not saved" : "sensor module disabled; not saved", false);
    emitStatusJson();
}

void onSetAlarmModeJson(const char* payload) {
    StaticJsonDocument<96> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("SET_ALARM_MODE", "error", "invalid json", false);
        return;
    }
    if (!doc.containsKey("mode") || !doc["mode"].is<const char*>()) {
        emitCommandAck("SET_ALARM_MODE", "rejected", "mode must be auto or manual", false);
        return;
    }
    const char* requested = doc["mode"].as<const char*>();
    pgl::gld::GldAlarmControlMode nextMode;
    if (strcmp(requested, "auto") == 0) {
        nextMode = pgl::gld::GldAlarmControlMode::Auto;
    } else if (strcmp(requested, "manual") == 0) {
        nextMode = pgl::gld::GldAlarmControlMode::Manual;
    } else {
        emitCommandAck("SET_ALARM_MODE", "rejected", "mode must be auto or manual", false);
        return;
    }

    // Apply this sequence even when the requested mode equals the current
    // mode. Re-applying MANUAL must never leave a prior test output ON, and
    // re-applying AUTO must resolve the output from current inference state.
    alarmControlMode = nextMode;
    manualAlarmCommanded = false;
    driveAlarmOutputs(lastAlarm);

    logPrintf("GLD_ALARM_MODE_APPLY mode=%s sessionOnly=1 persisted=0 inferenceAlarm=%u manualCommanded=%u physicalCommanded=%u\n",
              pgl::gld::gldAlarmControlModeName(alarmControlMode),
              lastAlarm ? 1u : 0u,
              manualAlarmCommanded ? 1u : 0u,
              physicalAlarmCommanded ? 1u : 0u);
    emitCommandAck("SET_ALARM_MODE", "ok",
                   alarmControlMode == pgl::gld::GldAlarmControlMode::Auto
                       ? "AUTO active; manual test cleared; valid inference controls physical alarm; boot default remains AUTO"
                       : "MANUAL TEST active for this session only; test output cleared OFF; reboot restores AUTO",
                   false);
    emitStatusJson();
}

void onSetManualAlarmJson(const char* payload) {
    StaticJsonDocument<64> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("SET_MANUAL_ALARM", "error", "invalid json", false);
        return;
    }
    if (!doc.containsKey("enabled") || !doc["enabled"].is<bool>()) {
        emitCommandAck("SET_MANUAL_ALARM", "rejected", "enabled boolean is required", false);
        return;
    }
    if (alarmControlMode != pgl::gld::GldAlarmControlMode::Manual) {
        emitCommandAck("SET_MANUAL_ALARM", "rejected", "select manual alarm mode before testing output", false);
        return;
    }
    manualAlarmCommanded = doc["enabled"].as<bool>();
    driveAlarmOutputs(lastAlarm);
    logPrintf("GLD_ALARM_MANUAL_APPLY enabled=%u inferenceAlarm=%u inferencePhysicalOutput=suppressed physicalCommanded=%u persisted=0\n",
              manualAlarmCommanded ? 1u : 0u,
              lastAlarm ? 1u : 0u,
              physicalAlarmCommanded ? 1u : 0u);
    emitCommandAck("SET_MANUAL_ALARM", "ok",
                   manualAlarmCommanded ? "manual alarm test ON; physical output commanded"
                                        : "manual alarm test OFF",
                   false);
    emitStatusJson();
}

// This command is deliberately separate from SET_MODE. It records an
// operator's explicit clean-air acknowledgement and clears only the persisted
// alarm latch. It never silences physical alarm outputs; the following mode
// reboot owns those outputs. A later valid alarm still latches normally.
void onVerifyCleanAirForNulling() {
    if (currentMode != pgl::gld::GldMode::INFERENCE) {
        emitCommandAck("VERIFY_CLEAN_AIR_FOR_NULLING", "rejected", "clean-air verification is allowed only in inference mode", false);
        return;
    }
    // A retained battery-delivery record must not prevent a 24 V operator
    // from confirming clean air and re-calibrating the sensor.  The record is
    // deliberately retained here; it remains owned by the battery-session
    // delivery flow and is not erased by a nulling acknowledgement.
    if (batteryPowerMode) {
        emitCommandAck("VERIFY_CLEAN_AIR_FOR_NULLING", "rejected", "battery alarm state cannot be cleared for nulling", false);
        return;
    }
    if (batteryPendingAlarm.active) {
        logPrintln("GLD_NULLING_PENDING_BATTERY_ALARM_RETAINED external_power=1");
    }
    const bool wasLatched = pgl::gld::readGldAlarmLatched();
    const bool latchClearPersisted = !wasLatched || pgl::gld::writeGldAlarmLatched(false);
    if (wasLatched && !latchClearPersisted) {
        // The operator's explicit clean-air confirmation authorizes Nulling.
        // Keep an NVS write fault visible, but do not block the mode switch.
        logPrintln("GLD_NULLING_ALARM_LATCH_CLEAR_PERSIST=FAIL override=operator_confirmed_clean_air");
    }
    // Force a later valid alarm scan to persist/re-latch even though this
    // operator acknowledgement cleared the previous in-memory edge.
    lastAlarm = false;
    logPrintf("GLD_ALARM_LATCH_OPERATOR_CLEAR=OK reason=operator_verified_clean_air_for_nulling wasLatched=%u outputHeld=1 relatchArmed=1\n",
              wasLatched ? 1u : 0u);
    emitCommandAck("VERIFY_CLEAN_AIR_FOR_NULLING", "ok",
                   wasLatched
                       ? (latchClearPersisted ? "alarm latch cleared for confirmed nulling" : "nulling authorized; alarm latch clear was not persisted")
                       : "no alarm latch was active; clean-air confirmation recorded",
                   false);
}

// Explicit local operator action: approve the most recently saved complete
// Nulling profile for this exact compiled model/scaler pair. New Nulling runs
// deliberately invalidate readiness until this action is repeated.
void onBindModelToActiveNullingProfile() {
    if (FIELDTEST_MODEL_UNVERIFIED || TFBG_CONTINUOUS_BATTERY || !pgl::gld::model::PRODUCTION_APPROVED) {
        emitCommandAck("BIND_MODEL_TO_ACTIVE_NULLING_PROFILE", "rejected", "binding is unavailable in a non-production build", false);
        return;
    }
    if (currentMode != pgl::gld::GldMode::INFERENCE) {
        emitCommandAck("BIND_MODEL_TO_ACTIVE_NULLING_PROFILE", "rejected", "binding is allowed only in inference mode", false);
        return;
    }
    if (nullingRetryArmed || !nullingProfileApplied || nullingProfileId == 0) {
        emitCommandAck("BIND_MODEL_TO_ACTIVE_NULLING_PROFILE", "rejected", "no stable applied nulling profile is available", false);
        return;
    }
    pgl::gld::GldNullingProfile profile{};
    if (!pgl::gld::loadNullingProfile(profile) || profile.profileId != nullingProfileId) {
        emitCommandAck("BIND_MODEL_TO_ACTIVE_NULLING_PROFILE", "rejected", "latest complete nulling profile is unavailable or changed", false);
        return;
    }

    pgl::gld::GldModelBinding updated{};
    updated.magic = pgl::gld::MODEL_BINDING_MAGIC;
    updated.schemaVersion = pgl::gld::MODEL_BINDING_SCHEMA_VERSION;
    updated.nullingProfileId = profile.profileId;
    updated.modelFingerprint = pgl::gld::modelBindingFingerprint(
        pgl::gld::model::PROFILE_ID, pgl::gld::model::SCALER_PROFILE_ID);
    updated.checksum = updated.magic ^ (static_cast<uint32_t>(updated.schemaVersion) << 16) ^
                       updated.nullingProfileId ^ updated.modelFingerprint ^ 0xC35A91E7u;
    if (!pgl::gld::saveModelBinding(updated)) {
        modelBinding = pgl::gld::GldModelBinding{};
        modelBindingLoaded = false;
        modelProfileReady = false;
        emitCommandAck("BIND_MODEL_TO_ACTIVE_NULLING_PROFILE", "error", "failed to persist model binding", false);
        return;
    }
    modelBinding = updated;
    modelBindingLoaded = true;
    modelProfileReady = modelProfileMatchesActiveNulling();
    logPrintf("MODEL_NULLING_BIND=OK profileId=%u fingerprint=%08lX ready=%u\n",
              updated.nullingProfileId, static_cast<unsigned long>(updated.modelFingerprint),
              modelProfileReady ? 1u : 0u);
    emitCommandAck("BIND_MODEL_TO_ACTIVE_NULLING_PROFILE", "ok", "latest nulling profile bound to model", false);
}

void onSetQcResultJson(const char* payload) {
    StaticJsonDocument<192> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("SET_QC_RESULT", "error", "invalid json", false);
        return;
    }
    if (!doc.containsKey("channel") || !doc.containsKey("pass")) {
        emitCommandAck("SET_QC_RESULT", "rejected", "channel and pass are required", false);
        return;
    }
    const int channel = doc["channel"].as<int>();
    if (channel < 0 || channel >= pgl::gld::board::SENSOR_COUNT) {
        emitCommandAck("SET_QC_RESULT", "rejected", "channel must be 0..7", false);
        return;
    }
    const bool pass = doc["pass"].as<bool>();
    const char* timestamp = doc["timestamp"].as<const char*>();
    if (timestamp == nullptr) timestamp = "";

    pgl::gld::GldQcProfile profile{};
    if (!pgl::gld::loadQcProfile(profile)) {
        profile = pgl::gld::GldQcProfile{};
    }
    profile.validMagic = pgl::gld::QC_PROFILE_VALID_MAGIC;
    profile.tested[channel] = 1;
    profile.passed[channel] = pass ? 1u : 0u;
    strncpy(profile.timestamp[channel], timestamp, pgl::gld::QC_TIMESTAMP_LEN - 1);
    profile.timestamp[channel][pgl::gld::QC_TIMESTAMP_LEN - 1] = '\0';

    if (!pgl::gld::saveQcProfile(profile)) {
        emitCommandAck("SET_QC_RESULT", "error", "failed to save qc result", false);
        return;
    }
    logPrintf("GLD_QC_RESULT_SAVE=OK channel=%d pass=%u\n", channel, pass ? 1u : 0u);
    emitCommandAck("SET_QC_RESULT", "ok", "qc result saved", false);
}

void onResetQcResultJson(const char* payload) {
    StaticJsonDocument<64> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("RESET_QC_RESULT", "error", "invalid json", false);
        return;
    }
    if (!doc.containsKey("channel")) {
        emitCommandAck("RESET_QC_RESULT", "rejected", "channel is required", false);
        return;
    }
    const int channel = doc["channel"].as<int>();
    if (channel < 0 || channel >= pgl::gld::board::SENSOR_COUNT) {
        emitCommandAck("RESET_QC_RESULT", "rejected", "channel must be 0..7", false);
        return;
    }

    pgl::gld::GldQcProfile profile{};
    if (!pgl::gld::loadQcProfile(profile)) {
        profile = pgl::gld::GldQcProfile{};
    }
    profile.validMagic = pgl::gld::QC_PROFILE_VALID_MAGIC;
    profile.tested[channel] = 0;
    profile.passed[channel] = 0;
    profile.timestamp[channel][0] = '\0';

    if (!pgl::gld::saveQcProfile(profile)) {
        emitCommandAck("RESET_QC_RESULT", "error", "failed to save qc reset", false);
        return;
    }
    logPrintf("GLD_QC_RESULT_RESET=OK channel=%d\n", channel);
    emitCommandAck("RESET_QC_RESULT", "ok", "qc result reset", false);
}

void onResetQcAll() {
    pgl::gld::GldQcProfile profile{};
    profile.validMagic = pgl::gld::QC_PROFILE_VALID_MAGIC;
    if (!pgl::gld::saveQcProfile(profile)) {
        emitCommandAck("RESET_QC_ALL", "error", "failed to save qc reset", false);
        return;
    }
    logPrintln("GLD_QC_RESULT_RESET_ALL=OK");
    emitCommandAck("RESET_QC_ALL", "ok", "all qc results reset", false);
}

void emitQcStatusJson() {
    pgl::gld::GldQcProfile qcProfile{};
    const bool qcValid = pgl::gld::loadQcProfile(qcProfile);
    if (!qcValid) qcProfile = pgl::gld::GldQcProfile{};

    pgl::gld::GldNullingProfile nullingProfile{};
    const bool nullingValid = pgl::gld::loadNullingProfile(nullingProfile);

    // The saved nulling profile is operator metadata requested explicitly by
    // GET_QC_STATUS, not live telemetry. Keep it with QC so a reconnect can
    // display the exact NVS snapshot without inferring it from transient logs.
    StaticJsonDocument<2048> doc;
    char chIdHex[5];
    formatHex4(runtimeConfig.chId, chIdHex, sizeof(chIdHex));
    doc["deviceId"] = runtimeConfig.deviceId;
    doc["nodeId"] = runtimeConfig.nodeId;
    doc["chId"] = chIdHex;

    JsonArray channels = doc.createNestedArray("channels");
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        JsonObject c = channels.createNestedObject();
        c["channel"] = ch;
        c["sensor"] = pgl::gld::board::SENSOR_NAMES[ch];
        c["nullingOk"] = nullingValid && nullingProfile.channelOk[ch] != 0;
        c["tested"] = qcProfile.tested[ch] != 0;
        c["pass"] = qcProfile.passed[ch] != 0;
        c["timestamp"] = qcProfile.timestamp[ch];
    }

    JsonObject savedProfile = doc.createNestedObject("nullingProfile");
    savedProfile["valid"] = nullingValid;
    if (nullingValid) {
        savedProfile["profileId"] = nullingProfile.profileId;
        JsonArray dacCode = savedProfile.createNestedArray("dacCode");
        JsonArray baselineV = savedProfile.createNestedArray("baselineV");
        JsonArray afterV = savedProfile.createNestedArray("afterV");
        JsonArray channelOk = savedProfile.createNestedArray("channelOk");
        for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
            dacCode.add(nullingProfile.dacCode[ch]);
            baselineV.add(nullingProfile.baselineV[ch]);
            afterV.add(nullingProfile.afterV[ch]);
            channelOk.add(nullingProfile.channelOk[ch] != 0);
        }
    }
    rawJsonLine("GLD_QC_STATUS_JSON", doc);
}

// Forward declaration - defined further down near the nulling retry state
// machine, but the QC tab's single-channel nulling command needs it here.
bool ensureNullingHardwareReady();
void requestNullingRetryFromSerialCommand(bool failedOnly = false);
void checkSerial();
void firmwareServiceTick();

void onRunNullingSingleJson(const char* payload) {
    StaticJsonDocument<96> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("RUN_NULLING_SINGLE", "error", "invalid json", false);
        return;
    }
    if (!doc.containsKey("channel")) {
        emitCommandAck("RUN_NULLING_SINGLE", "rejected", "channel is required", false);
        return;
    }
    const int channel = doc["channel"].as<int>();
    if (channel < 0 || channel >= pgl::gld::board::SENSOR_COUNT) {
        emitCommandAck("RUN_NULLING_SINGLE", "rejected", "channel must be 0..7", false);
        return;
    }
    if (!ensureNullingHardwareReady()) {
        emitCommandAck("RUN_NULLING_SINGLE", "error", "ADS/DAC not ready", false);
        return;
    }

    const pgl::gld::GldNullingSingleResult result = pgl::gld::runNullingServiceSingleChannel(
        ads, dac, static_cast<uint8_t>(channel), nullingLogLine, firmwareServiceTick, nullingConfig);

    // A single-channel service may update only an already-complete production
    // profile. Never promote a partial/failing result into a valid profile.
    pgl::gld::GldNullingProfile existing{};
    const bool hadExisting = pgl::gld::loadNullingProfile(existing);
    if (!hadExisting) {
        emitCommandAck("RUN_NULLING_SINGLE", "rejected",
                       "complete nulling profile required before single-channel update", false);
        return;
    }
    if (!result.success) {
        emitCommandAck("RUN_NULLING_SINGLE", "failed",
                       "channel nulling failed; active profile unchanged", false);
        return;
    }
    if (existing.profileId == UINT8_MAX) {
        emitCommandAck("RUN_NULLING_SINGLE", "rejected",
                       "nulling profile id exhausted; maintenance reset required", false);
        return;
    }

    pgl::gld::GldNullingProfile toSave = existing;
    toSave.profileId = static_cast<uint8_t>(existing.profileId + 1u);
    toSave.dacCode[channel]   = result.dacCode;
    toSave.baselineV[channel] = result.baselineV;
    toSave.afterV[channel]    = result.afterV;
    toSave.channelOk[channel] = 1u;

    if (!pgl::gld::isNullingProfileValid(toSave)) {
        emitCommandAck("RUN_NULLING_SINGLE", "error", "updated profile validation failed", false);
        return;
    }
    if (!dac.writeDac(static_cast<uint8_t>(channel), result.dacCode)) {
        emitCommandAck("RUN_NULLING_SINGLE", "error", "DAC apply failed; active profile unchanged", false);
        return;
    }
    if (!pgl::gld::saveNullingProfile(toSave)) {
        (void)dac.writeDac(static_cast<uint8_t>(channel), existing.dacCode[channel]);
        emitCommandAck("RUN_NULLING_SINGLE", "error", "nulling result computed but failed to save profile", false);
        return;
    }
    nullingProfileId = toSave.profileId;
    nullingProfileApplied = true;
    logPrintf("GLD_NULLING_SINGLE_SAVE=OK channel=%d success=%u profileId=%u\n",
              channel, 1u, toSave.profileId);
    emitCommandAck("RUN_NULLING_SINGLE", "ok", "channel nulled", false);
}

// Diagnostic voltage-vs-DAC-code sweep for one channel, used by the QC tab's
// "Full Scale Nulling" popup to show the operator the sensor's full response
// curve. Does not alter the persisted nulling profile - the DAC is restored
// to that channel's currently-nulled code (or 0 if never nulled) once the
// sweep finishes.
void onRunFullScaleSweepJson(const char* payload) {
    StaticJsonDocument<96> doc;
    if (deserializeJson(doc, payload)) {
        emitCommandAck("RUN_FULLSCALE_SWEEP", "error", "invalid json", false);
        return;
    }
    if (!doc.containsKey("channel")) {
        emitCommandAck("RUN_FULLSCALE_SWEEP", "rejected", "channel is required", false);
        return;
    }
    const int channel = doc["channel"].as<int>();
    if (channel < 0 || channel >= pgl::gld::board::SENSOR_COUNT) {
        emitCommandAck("RUN_FULLSCALE_SWEEP", "rejected", "channel must be 0..7", false);
        return;
    }
    if (!ensureNullingHardwareReady()) {
        emitCommandAck("RUN_FULLSCALE_SWEEP", "error", "ADS/DAC not ready", false);
        return;
    }

    // Restore exactly the effective DAC code that was active when the sweep
    // began. This preserves a session-only Running trim as well as a saved
    // Nulling profile, without reading or writing NVS.
    const uint16_t restoreCode = dac.lastValue(static_cast<uint8_t>(channel));

    emitCommandAck("RUN_FULLSCALE_SWEEP", "ok", "running full scale sweep", false);
    // firmwareServiceTick (not bare checkSerial) - a full 4096-code sweep runs
    // well past the external TPL5010 watchdog's keepalive window, so the tick
    // function must also pulse the watchdog (see maintainWdtKeepalive) or the
    // board hard-resets mid-sweep.
    fullScaleSweepCancelRequested = false;
    fullScaleSweepActive = true;
    const pgl::gld::GldFullScaleSweepResult result = pgl::gld::runFullScaleSweep(
        ads, dac, static_cast<uint8_t>(channel), restoreCode, 1, nullingLogLine,
        firmwareServiceTick, []() { return fullScaleSweepCancelRequested; });
    fullScaleSweepActive = false;
    fullScaleSweepCancelRequested = false;
    if (result.cancelled) {
        if (!result.success) {
            // Cancelling is safe only if the original DAC output was restored.
            // Keep the runtime conservative if that final write failed.
            dacReady = false;
            nullingProfileApplied = false;
            nullingProfileId = 0;
            logPrintf("GLD_FULLSCALE_SWEEP_RESULT=CANCELLED channel=%d restoreCode=%u restoreOk=0 runtimeInvalidated=1\n",
                      channel, result.restoredCode);
            return;
        }
        logPrintf("GLD_FULLSCALE_SWEEP_RESULT=CANCELLED channel=%d restoreCode=%u restoreOk=1\n",
                  channel, result.restoredCode);
        return;
    }
    if (!result.success) {
        dacReady = false;
        nullingProfileApplied = false;
        nullingProfileId = 0;
        logPrintf("GLD_FULLSCALE_SWEEP_RESULT=FAIL channel=%d status=%s restoreCode=%u runtimeInvalidated=1\n",
                  channel,
                  pgl::gld::gldNullingStatusName(result.status),
                  result.restoredCode);
    } else {
        logPrintf("GLD_FULLSCALE_SWEEP_RESULT=PASS channel=%d restoreCode=%u\n",
                  channel, result.restoredCode);
    }
}

void onCancelFullScaleSweep() {
    if (!fullScaleSweepActive) {
        emitCommandAck("CANCEL_FULLSCALE_SWEEP", "rejected", "no full scale sweep is active", false);
        return;
    }
    if (fullScaleSweepCancelRequested) {
        emitCommandAck("CANCEL_FULLSCALE_SWEEP", "ok", "full scale sweep cancellation already requested", false);
        return;
    }
    fullScaleSweepCancelRequested = true;
    emitCommandAck("CANCEL_FULLSCALE_SWEEP", "ok", "full scale sweep cancellation requested", false);
}

void handleSerialCommand(const pgl::gld::GldSerialCommand& command) {
    switch (command.type) {
        case pgl::gld::GldSerialCommandType::Unknown:
            onUnknownSerialCommand(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::SetMode:
            onModeCmd(command.mode);
            break;
        case pgl::gld::GldSerialCommandType::DebugOn:
            onDebugCmd(true);
            break;
        case pgl::gld::GldSerialCommandType::DebugOff:
            onDebugCmd(false);
            break;
        case pgl::gld::GldSerialCommandType::AppPing:
            emitCommandAck("APP_PING", "ok", "pong", false);
            break;
        case pgl::gld::GldSerialCommandType::GetInfo:
            emitInfoJson();
            break;
        case pgl::gld::GldSerialCommandType::GetStatus:
            emitStatusJson();
            break;
        case pgl::gld::GldSerialCommandType::GetTelemetry:
            emitTelemetryJson();
            break;
        case pgl::gld::GldSerialCommandType::Restart:
            restartFromSerialCommand();
            break;
        case pgl::gld::GldSerialCommandType::RunBootCheck:
            runBootCheckFromSerialCommand();
            break;
        case pgl::gld::GldSerialCommandType::RunCurrentStateCheck:
            runCurrentStateCheckFromSerialCommand();
            break;
        case pgl::gld::GldSerialCommandType::RunI2cScan:
            runI2cScanFromSerialCommand();
            break;
        case pgl::gld::GldSerialCommandType::RunTcaChannelScan:
            runTcaChannelScanFromSerialCommand();
            break;
        case pgl::gld::GldSerialCommandType::RunAdsMcpSweep:
            runAdsMcpSweepFromSerialCommand();
            break;
        case pgl::gld::GldSerialCommandType::SleepNow:
            sleepNowFromSerialCommand();
            break;
        case pgl::gld::GldSerialCommandType::ServiceHoldOff:
            serviceHoldOffFromSerialCommand();
            break;
        case pgl::gld::GldSerialCommandType::SetAppConfigJson:
            onSetAppConfigJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::SetDeviceIdJson:
            onSetDeviceIdJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::SetChAddressJson:
            onSetChAddressJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::SetLoraConfigJson:
            onSetLoraConfigJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::SetNullingConfigJson:
            onSetNullingConfigJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::SetSessionMcpJson:
            onSetSessionMcpJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::SetSensorPowerJson:
            onSetSensorPowerJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::SetAlarmModeJson:
            onSetAlarmModeJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::SetManualAlarmJson:
            onSetManualAlarmJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::VerifyCleanAirForNulling:
            onVerifyCleanAirForNulling();
            break;
        case pgl::gld::GldSerialCommandType::RetryNulling:
            requestNullingRetryFromSerialCommand();
            break;
        case pgl::gld::GldSerialCommandType::RetryFailedNulling:
            requestNullingRetryFromSerialCommand(true);
            break;
        case pgl::gld::GldSerialCommandType::BindModelToActiveNullingProfile:
            onBindModelToActiveNullingProfile();
            break;
        case pgl::gld::GldSerialCommandType::SetQcResultJson:
            onSetQcResultJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::GetQcStatus:
            emitQcStatusJson();
            break;
        case pgl::gld::GldSerialCommandType::RunNullingSingleJson:
            onRunNullingSingleJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::ResetQcResultJson:
            onResetQcResultJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::ResetQcAll:
            onResetQcAll();
            break;
        case pgl::gld::GldSerialCommandType::RunFullScaleSweepJson:
            onRunFullScaleSweepJson(command.payload);
            break;
        case pgl::gld::GldSerialCommandType::CancelFullScaleSweep:
            onCancelFullScaleSweep();
            break;
        case pgl::gld::GldSerialCommandType::InjectTplDone:
            injectTplDoneFromSerialCommand();
            break;
        case pgl::gld::GldSerialCommandType::InjectTplClr:
            injectTplClrFromSerialCommand();
            break;
        case pgl::gld::GldSerialCommandType::None:
        default:
            break;
    }
}

// Check Serial every loop tick for operator/app commands.
// Guarded against re-entrancy: long-running command handlers (e.g. RUN_BOOT_CHECK)
// call firmwareServiceTick() internally to keep the WDT fed and stay responsive,
// which would otherwise let a newly arrived command dispatch itself from deep
// inside an already-executing handler and blow the loopTask stack. While a
// command is being handled, any serial bytes that arrive stay queued in the
// UART buffer and are picked up on the next non-reentrant call.
//
// RESTART is the one exception: it is checked and actioned unconditionally,
// even from a reentrant call deep inside a multi-minute nulling or full-scale
// sweep tick loop, so a stuck or very long-running sweep can never leave the
// board unrecoverable from software until it finishes or is power-cycled -
// ESP.restart() never returns, so there is no stack to unwind. Any other
// CANCEL_FULLSCALE_SWEEP shares this priority path. Ordinary commands are
// queued and drained once nesting unwinds, so they cannot block stop/restart.
void checkSerial() {
    static bool inProgress = false;
    constexpr uint8_t PENDING_COMMAND_CAPACITY = 8;
    static pgl::gld::GldSerialCommand pendingCommands[PENDING_COMMAND_CAPACITY]{};
    static uint8_t pendingHead = 0;
    static uint8_t pendingCount = 0;

    pgl::gld::GldSerialCommand parsed{};
    if (pgl::gld::parseSerialCommand(parsed)) {
        if (parsed.type == pgl::gld::GldSerialCommandType::Restart) {
            restartFromSerialCommand();
            return;  // unreachable in practice - ESP.restart() reboots immediately
        }
        if (parsed.type == pgl::gld::GldSerialCommandType::CancelFullScaleSweep) {
            // This path remains callable from firmwareServiceTick() while the
            // synchronous sweep handler owns `inProgress` or a normal command
            // is already queued for later execution.
            onCancelFullScaleSweep();
            return;
        }
        if (pendingCount < PENDING_COMMAND_CAPACITY) {
            const uint8_t tail = static_cast<uint8_t>(
                (pendingHead + pendingCount) % PENDING_COMMAND_CAPACITY);
            pendingCommands[tail] = parsed;
            ++pendingCount;
        } else {
            emitCommandAck("SERIAL_COMMAND", "busy", "command queue is full", false);
        }
    }

    if (inProgress) {
        return;
    }
    inProgress = true;
    for (uint8_t i = 0; i < PENDING_COMMAND_CAPACITY && pendingCount > 0; ++i) {
        const pgl::gld::GldSerialCommand command = pendingCommands[pendingHead];
        pendingHead = static_cast<uint8_t>((pendingHead + 1U) % PENDING_COMMAND_CAPACITY);
        --pendingCount;
        if (command.type == pgl::gld::GldSerialCommandType::Restart) {
            restartFromSerialCommand();
            return;
        }
        handleSerialCommand(command);
    }
    inProgress = false;
}

void pulseWdtKeepaliveNow() {
    const bool serviceHoldRequested = serviceHoldActive ||
        batteryPersistenceFaultHold ||
        digitalRead(pgl::gld::board::PIN_USER_BUTTON) == LOW ||
        !cfgButtonRawHigh || cfgButtonPressArmed;
    if (batteryPowerMode && !TFBG_CONTINUOUS_BATTERY && !serviceHoldRequested) {
        lastWdtKeepaliveMs = millis();
        return;
    }
    pgl::gld::pulseGldTpl5010Keepalive();
    lastWdtKeepaliveMs = millis();
}

void maintainWdtKeepalive() {
    const bool serviceHoldRequested = serviceHoldActive ||
        batteryPersistenceFaultHold ||
        digitalRead(pgl::gld::board::PIN_USER_BUTTON) == LOW ||
        !cfgButtonRawHigh || cfgButtonPressArmed;
    if (batteryPowerMode && !TFBG_CONTINUOUS_BATTERY && !serviceHoldRequested) return;
    const uint32_t now = millis();
    if (now - lastWdtKeepaliveMs >= pgl::gld::GLD_WDT_KEEPALIVE_INTERVAL_MS) {
        pulseWdtKeepaliveNow();
    }
}

bool serviceHoldBlocksClr() {
    // LOW immediately inhibits CLR, even before the release edge has completed
    // the persistent toggle. This prevents the board powering off while the
    // operator is still holding CFG and waiting to release it.
    const bool cfgLowNow = digitalRead(pgl::gld::board::PIN_USER_BUTTON) == LOW;
    return batteryPowerMode &&
           (serviceHoldActive || batteryPersistenceFaultHold ||
            cfgLowNow || !cfgButtonRawHigh || cfgButtonPressArmed);
}

void blinkServiceHoldEnabled() {
#if PGL_GLD_BOARD_PROFILE_WROOM_U1_N16R8 || PGL_GLD_BOARD_PROFILE_GLD2
    // IO39 is the active-low status LED on this production profile. On the
    // legacy profile GPIO39 is LoRa RST, so this indication is compiled out.
    for (uint8_t i = 0; i < 2; ++i) {
        digitalWrite(pgl::gld::board::PIN_STATUS_LED, ACTIVE_LOW_OUTPUT_ON);
        delay(120);
        digitalWrite(pgl::gld::board::PIN_STATUS_LED, ACTIVE_LOW_OUTPUT_OFF);
        delay(120);
    }
    digitalWrite(pgl::gld::board::PIN_STATUS_LED,
                 lastAlarm ? ACTIVE_LOW_OUTPUT_ON : ACTIVE_LOW_OUTPUT_OFF);
#endif
}

void setServiceHoldActive(bool active, const char* source) {
    if (serviceHoldActive == active) {
        logPrintf("GLD_SERVICE_HOLD state=%s source=%s unchanged=1\n",
                  active ? "ON" : "OFF", source != nullptr ? source : "unknown");
        return;
    }

    serviceHoldActive = active;
    const bool persisted = pgl::gld::writeGldServiceHold(active);
    logPrintf("GLD_SERVICE_HOLD state=%s source=%s persisted=%u batteryMode=%u session=%s\n",
              active ? "ON" : "OFF",
              source != nullptr ? source : "unknown",
              persisted ? 1u : 0u,
              batteryPowerMode ? 1 : 0,
              batterySessionStateName(batterySessionState));

    if (active) {
        blinkServiceHoldEnabled();
        if (batteryPowerMode) {
            // Feed TPL5010 immediately, then maintainWdtKeepalive() continues
            // every 10 seconds while CLR is inhibited for service/upload.
            pulseWdtKeepaliveNow();
        }
    }
}

void beginServiceHoldButton() {
    pinMode(pgl::gld::board::PIN_USER_BUTTON, INPUT_PULLUP);
    const bool initialHigh = digitalRead(pgl::gld::board::PIN_USER_BUTTON) == HIGH;
    cfgButtonRawHigh = initialHigh;
    cfgButtonStableHigh = initialHigh;
    // If the operator deliberately holds CFG through boot, releasing it is the
    // first valid RISING event. Pin setup runs after the 1-second rail settle,
    // so the VCC ramp itself cannot arm this path.
    cfgButtonPressArmed = !initialHigh;
    cfgButtonRawChangedMs = millis();
    logPrintf("GLD_CFG_BUTTON_INIT level=%s pressArmed=%u serviceHold=%u\n",
              initialHigh ? "HIGH" : "LOW",
              cfgButtonPressArmed ? 1 : 0,
              serviceHoldActive ? 1 : 0);
}

void maintainServiceHoldButton() {
    if (!batteryPowerMode) return;

    const uint32_t now = millis();
    const bool rawHigh = digitalRead(pgl::gld::board::PIN_USER_BUTTON) == HIGH;
    if (rawHigh != cfgButtonRawHigh) {
        cfgButtonRawHigh = rawHigh;
        cfgButtonRawChangedMs = now;
        return;
    }
    if (rawHigh == cfgButtonStableHigh || now - cfgButtonRawChangedMs < CFG_BUTTON_DEBOUNCE_MS) {
        return;
    }

    cfgButtonStableHigh = rawHigh;
    if (!cfgButtonStableHigh) {
        cfgButtonPressArmed = true;
        logPrintln("GLD_CFG_BUTTON event=PRESS level=LOW");
        return;
    }

    if (cfgButtonPressArmed) {
        cfgButtonPressArmed = false;
        logPrintln("GLD_CFG_BUTTON event=RELEASE level=HIGH rising=1");
        setServiceHoldActive(!serviceHoldActive, "cfg_release");
    }
}

bool batteryRuntimeReady() {
    if (SENSORLESS_BENCH && SIMULATED_MODEL_OUTPUT) {
        return radioReady;
    }
    if (FIELDTEST_MODEL_UNVERIFIED || SIMULATED_MODEL_OUTPUT) {
        return adsReady && radioReady;
    }
    return adsReady && radioReady && mlReady && nullingProfileApplied && modelProfileReady;
}

void startBatteryInferenceSession() {
    const uint32_t now = millis();
    batterySessionState = BatterySessionState::Warmup;
    batterySessionStartedMs = now;
    batteryStateStartedMs = now;
    batteryLastSampleAttemptMs = now;
    batteryLastWarmupPrimeMs = 0;
    batteryNextTxAttemptMs = 0;
    batteryValidSampleBatches = 0;
    batteryAlarmTxAttempts = 0;
    batteryAlarmAckReceived = false;
    batteryCyclePoweredOff = false;
    snprintf(batteryCompletionReason, sizeof(batteryCompletionReason), "session_running");
    logPrintf("GLD_BATTERY_SESSION_START warmupMs=%lu validBatches=%u sampleIntervalMs=%lu alarmTxAttempts=%u rxWindowMs=%lu deadlineMs=%lu pendingAlarm=%u serviceHold=%u\n",
              static_cast<unsigned long>(BATTERY_SENSOR_WARMUP_MS),
              static_cast<unsigned>(BATTERY_VALID_SAMPLE_BATCHES),
              static_cast<unsigned long>(SCAN_INTERVAL_MS),
              static_cast<unsigned>(BATTERY_ALARM_TX_ATTEMPTS),
              static_cast<unsigned long>(LORA_RX_WINDOW_MS),
              static_cast<unsigned long>(BATTERY_SESSION_DEADLINE_MS),
              batteryPendingAlarm.active ? 1 : 0,
              serviceHoldActive ? 1 : 0);
}

const char* batteryRuntimeBlockReason() {
    if (!radioReady) return "radio_not_ready";
    if (SENSORLESS_BENCH && SIMULATED_MODEL_OUTPUT) return "none";
    if (!adsReady) return "ads_not_ready";
    if (FIELDTEST_MODEL_UNVERIFIED || SIMULATED_MODEL_OUTPUT) return "none";
    if (!mlReady) return "ml_not_ready";
    if (!nullingProfileApplied) return "nulling_profile_not_applied";
    if (!modelProfileReady) return "model_profile_unapproved_or_mismatch";
    return "none";
}

void armBatteryFaultPowerOff(const char* reason) {
    if (batteryFaultPowerOffArmed) return;
    batteryFaultPowerOffArmed = true;
    batteryFaultPowerOffDueMs = millis() + BATTERY_FAULT_SERIAL_HOLD_MS;
    logPrintf("GLD_BATTERY_SESSION_WAIT reason=%s delayMs=%lu adsReady=%u radioReady=%u mlReady=%u\n",
              reason != nullptr ? reason : "hardware_not_ready",
              static_cast<unsigned long>(BATTERY_FAULT_SERIAL_HOLD_MS),
              adsReady ? 1 : 0,
              radioReady ? 1 : 0,
              mlReady ? 1 : 0);
}

void enterBatteryPersistenceFaultHold(const char* reason) {
    batteryPersistenceFaultHold = true;
    batteryPersistenceRetryDueMs = millis() + BATTERY_ALARM_RETRY_DELAY_MS;
    batterySessionState = BatterySessionState::CompleteHeld;
    batteryStateStartedMs = millis();
    snprintf(batteryCompletionReason, sizeof(batteryCompletionReason), "%s",
             reason != nullptr ? reason : "persistence_fault");
    logPrintf("GLD_BATTERY_PERSISTENCE_HOLD reason=%s retryMs=%lu clrBlocked=1\n",
              batteryCompletionReason,
              static_cast<unsigned long>(BATTERY_ALARM_RETRY_DELAY_MS));
    pulseWdtKeepaliveNow();
}

void completeBatterySessionAndPowerOff(const char* reason) {
    if (batteryCyclePoweredOff || batterySessionState == BatterySessionState::PowerOffIssued) return;

    if (FIELDTEST_MODEL_UNVERIFIED) {
        logPrintf("GLD_FIELDTEST_POWER_OFF_SUPPRESSED reason=%s action=continuous_keepalive\n",
                  reason != nullptr ? reason : "session_done");
        pulseWdtKeepaliveNow();
        return;
    }

    snprintf(batteryCompletionReason, sizeof(batteryCompletionReason), "%s",
             reason != nullptr ? reason : "session_done");
    if (SENSORLESS_REPEAT_BENCH) {
        batterySessionState = BatterySessionState::CompleteHeld;
        batteryStateStartedMs = millis();
        logPrintf("GLD_SENSORLESS_REPEAT_HOLD reason=%s intervalMs=%lu action=repeat_without_power_off\n",
                  batteryCompletionReason,
                  static_cast<unsigned long>(SENSORLESS_REPEAT_INTERVAL_MS));
        pulseWdtKeepaliveNow();
        return;
    }
    if (serviceHoldBlocksClr()) {
        if (batterySessionState != BatterySessionState::CompleteHeld) {
            batterySessionState = BatterySessionState::CompleteHeld;
            batteryStateStartedMs = millis();
            logPrintf("GLD_BATTERY_SESSION_HELD reason=%s clrBlocked=1 holdEffective=1 serviceHold=%u cfgLow=%u\n",
                      batteryCompletionReason,
                      serviceHoldActive ? 1 : 0,
                      cfgButtonRawHigh ? 0 : 1);
            pulseWdtKeepaliveNow();
        }
        return;
    }

    logPrintf("GLD_BATTERY_SESSION_DONE power_off reason=%s done=LOW_HIGH_LOW donePulseUs=%lu doneToClrDelayUs=%lu clr=HIGH_LOW_HIGH clrPulseUs=%lu\n",
              batteryCompletionReason,
              static_cast<unsigned long>(pgl::gld::GLD_TPL5010_DONE_PULSE_US),
              static_cast<unsigned long>(pgl::gld::GLD_DONE_TO_CLR_DELAY_US),
              static_cast<unsigned long>(pgl::gld::GLD_POWER_LATCH_CLEAR_PULSE_US));
    Serial.flush();
#if defined(ARDUINO_ARCH_ESP32)
    Serial0.flush();
#endif
    if (serviceHoldBlocksClr()) {
        batterySessionState = BatterySessionState::CompleteHeld;
        batteryStateStartedMs = millis();
        logPrintf("GLD_BATTERY_SESSION_POWER_OFF_ABORT reason=%s cfgLowOrHold=1 action=complete_held\n",
                  batteryCompletionReason);
        pulseWdtKeepaliveNow();
        return;
    }
    batteryCyclePoweredOff = true;
    batterySessionState = BatterySessionState::PowerOffIssued;
    batteryStateStartedMs = millis();
    pgl::gld::pulseGldTpl5010DoneThenPowerLatchClear();
}

void applyRuntimePowerReading(const pgl::gld::GldPowerReading& power,
                              const char* source,
                              bool immediate = false) {
    lastKnownBatteryMv = power.batteryMv;
    lastKnownExternalPower = power.externalPower;
    external24VPowerMode = power.mode == pgl::gld::GldPowerMode::External24V;
    const bool requestedBatteryMode = TFBG_CONTINUOUS_BATTERY || !power.externalPower;
    if (requestedBatteryMode == batteryPowerMode) {
        powerModeCandidateCount = 0;
        powerModeCandidateBattery = requestedBatteryMode;
        return;
    }

    if (!immediate) {
        if (powerModeCandidateCount == 0 ||
            powerModeCandidateBattery != requestedBatteryMode) {
            powerModeCandidateBattery = requestedBatteryMode;
            powerModeCandidateCount = 1;
            return;
        }
        if (powerModeCandidateCount < POWER_RECONCILE_STABLE_SAMPLES) {
            ++powerModeCandidateCount;
        }
        if (powerModeCandidateCount < POWER_RECONCILE_STABLE_SAMPLES) {
            return;
        }
    }

    const bool previousBatteryMode = batteryPowerMode;
    batteryPowerMode = requestedBatteryMode;
    powerModeCandidateCount = 0;
#if PGL_GLD_BOARD_PROFILE_GLD2
    dac.setAutomaticSensorPowerControl(batteryPowerMode);
    if (!batteryPowerMode && pcfReady) {
        uint8_t liveOutputs = 0;
        const bool readOk = pcf8574.readOutputs(liveOutputs);
        pcfAllLoadSwitchesOn = readOk &&
                                liveOutputs == pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_ON;
        logPrintf("GLD2_PCF8574_SYNC source=%s read=%u outputs=0x%02X allLoadSwitchesOn=%u\n",
                  source != nullptr ? source : "runtime", readOk ? 1u : 0u,
                  pcf8574.outputs(), pcfAllLoadSwitchesOn ? 1u : 0u);
    }
#endif
    logPrintf("GLD_POWER_TRANSITION source=%s fromBattery=%u toBattery=%u mode=%s batterySense=%s ambiguous=%u batteryMv=%u\n",
              source != nullptr ? source : "runtime",
              previousBatteryMode ? 1u : 0u,
              batteryPowerMode ? 1u : 0u,
              pgl::gld::gldPowerModeName(power.mode),
              pgl::gld::gldBatterySenseStatusName(power.batterySenseStatus),
              power.powerSourceAmbiguous ? 1u : 0u,
              power.batteryMv);

    if (batteryPowerMode) {
        if (currentMode != pgl::gld::GldMode::INFERENCE) {
            const bool persisted = pgl::gld::writeGldMode(pgl::gld::GldMode::INFERENCE);
            powerTransitionShutdownPending = true;
            logPrintf("MODE_POWER_TRANSITION_BLOCK mode=%s nextMode=inference persisted=%u action=power_off\n",
                      pgl::gld::gldModeName(currentMode), persisted ? 1u : 0u);
            completeBatterySessionAndPowerOff("unsupported_mode_power_transition");
            return;
        }
        if (!TFBG_CONTINUOUS_BATTERY) {
            startBatteryInferenceSession();
        }
        return;
    }

    // External power returned before CLR: cancel the one-shot state so an
    // in-flight battery session cannot cut a newly restored external rail.
    powerTransitionShutdownPending = false;
    batteryPersistenceFaultHold = false;
    batterySessionState = BatterySessionState::Inactive;
    batteryFaultPowerOffArmed = false;
    batteryCyclePoweredOff = false;
    logPrintln("GLD_BATTERY_SESSION_CANCEL reason=external_power_restored clrInhibited=1");
}

void reconcileRuntimePowerMode() {
    const uint32_t now = millis();
    if (now - lastPowerReconcileMs < POWER_RECONCILE_INTERVAL_MS) {
        return;
    }
    lastPowerReconcileMs = now;
    applyRuntimePowerReading(pgl::gld::readGldPower(), "periodic", false);
}

bool readStpSource24V() {
    return pgl::gld::board::PIN_POWER_SOURCE_STATUS >= 0 &&
           digitalRead(pgl::gld::board::PIN_POWER_SOURCE_STATUS) == HIGH;
}

void maintainModbusRtu() {
#if PGL_GLD_BOARD_PROFILE_GLD2
    if (!modbusReady) return;
    uint16_t statusBits = 0;
    statusBits |= adsReady ? (1U << 0) : 0U;
    statusBits |= dacReady ? (1U << 1) : 0U;
    statusBits |= radioReady ? (1U << 2) : 0U;
    statusBits |= mlReady ? (1U << 3) : 0U;
    statusBits |= lastInferenceValid ? (1U << 4) : 0U;
    statusBits |= lastAlarm ? (1U << 5) : 0U;
    statusBits |= readStpSource24V() ? (1U << 6) : 0U;
    statusBits |= lastKnownExternalPower ? (1U << 7) : 0U;
    pgl::gld::GldModbusRtuSnapshot snapshot{};
    snapshot.statusBits = statusBits;
    snapshot.gasClass = lastResult.gasClass;
    snapshot.confidence = lastResult.confidence;
    snapshot.batteryMv = lastKnownBatteryMv;
    snapshot.source24V = readStpSource24V() ? 1U : 0U;
    snapshot.externalPower = lastKnownExternalPower ? 1U : 0U;
    snapshot.txCounterLow = static_cast<uint16_t>(txCounter & 0xFFFFU);
    snapshot.nodeId = runtimeConfig.nodeId;
    modbusRtu.poll(snapshot);
#endif
}

void firmwareServiceTick() {
    maintainServiceHoldButton();
    serviceTca9548aPresenceProbe();
    checkSerial();
    maintainModbusRtu();
    maintainWdtKeepalive();
}

void serviceDelay(uint32_t durationMs) {
    const uint32_t startedMs = millis();
    while (millis() - startedMs < durationMs) {
        firmwareServiceTick();
        const uint32_t elapsedMs = millis() - startedMs;
        const uint32_t remainingMs = durationMs > elapsedMs ? durationMs - elapsedMs : 0;
        delay(remainingMs > 50 ? 50 : remainingMs);
    }
    firmwareServiceTick();
}

// ---------------------------------------------------------------------------
// Common hardware init (all modes)
// ---------------------------------------------------------------------------

bool isValidBoardPin(int pin) {
    return pin >= 0;
}

void optionalPinMode(int pin, uint8_t mode) {
    if (isValidBoardPin(pin)) {
        pinMode(static_cast<uint8_t>(pin), mode);
    }
}

void optionalDigitalWrite(int pin, uint8_t value) {
    if (isValidBoardPin(pin)) {
        digitalWrite(static_cast<uint8_t>(pin), value);
    }
}

void setupPins() {
    pinMode(pgl::gld::board::PIN_LORA_CS,    OUTPUT); digitalWrite(pgl::gld::board::PIN_LORA_CS,    HIGH);
    pinMode(pgl::gld::board::PIN_LORA_RST,   OUTPUT); digitalWrite(pgl::gld::board::PIN_LORA_RST,   HIGH);
    pinMode(pgl::gld::board::PIN_LORA_RXEN,  OUTPUT); digitalWrite(pgl::gld::board::PIN_LORA_RXEN,  LOW);
    pinMode(pgl::gld::board::PIN_LORA_TXEN,  OUTPUT); digitalWrite(pgl::gld::board::PIN_LORA_TXEN,  LOW);
#if PGL_GLD_BOARD_PROFILE_GLD2
    // GPIO40 drives the Q4 low-side switch through R94; R41 pulls it LOW.
    // Disable boost and keep the Q4 gate LOW for a deterministic alarm OFF.
    optionalPinMode(pgl::gld::board::PIN_ALARM_ENABLE_BOOST, OUTPUT);
    optionalDigitalWrite(pgl::gld::board::PIN_ALARM_ENABLE_BOOST, LOW);
    optionalPinMode(pgl::gld::board::PIN_ALARM_LAMP, OUTPUT);
    optionalDigitalWrite(pgl::gld::board::PIN_ALARM_LAMP, LOW);
#else
    optionalPinMode(pgl::gld::board::PIN_ALARM_LAMP, OUTPUT);
    optionalPinMode(pgl::gld::board::PIN_ALARM_ENABLE_BOOST, OUTPUT);
    optionalDigitalWrite(pgl::gld::board::PIN_ALARM_LAMP, ACTIVE_LOW_OUTPUT_OFF);
#endif
    optionalPinMode(pgl::gld::board::PIN_BUZZER,     OUTPUT); optionalDigitalWrite(pgl::gld::board::PIN_BUZZER,     ACTIVE_LOW_OUTPUT_OFF);
    optionalPinMode(pgl::gld::board::PIN_DC_FAN,     OUTPUT); optionalDigitalWrite(pgl::gld::board::PIN_DC_FAN,     LOW);
    optionalPinMode(pgl::gld::board::PIN_STATUS_LED, OUTPUT); optionalDigitalWrite(pgl::gld::board::PIN_STATUS_LED, ACTIVE_LOW_OUTPUT_OFF);
    optionalPinMode(pgl::gld::board::PIN_POWER_SOURCE_STATUS, INPUT);
}

const char* passFail(bool ok) {
    return ok ? "PASS" : "FAIL";
}

const char* okNotOk(bool ok) {
    return ok ? "OK" : "NOT_OK";
}

const char* checkedOkNotOk(bool checked, bool ok) {
    return checked ? okNotOk(ok) : "SKIP";
}

struct BootAdsReport {
    bool ok = false;
    const char* reason = "not_checked";
    int drdyLevel = -1;
    int drdyPulldownLevel = -1;
    int drdyPullupLevel = -1;
    int misoPulldownLevel = -1;
    int misoPullupLevel = -1;
    int csLevel = -1;
    int syncLevel = -1;
    uint8_t status = 0;
    uint8_t mux = 0;
    uint8_t adcon = 0;
    uint8_t drate = 0;
};

struct BootI2cReport {
    bool fullBusScanPerformed = false;
    bool tcaOk = false;
    bool pcfOk = false;
    uint8_t detectedAddressCount = 0;
    char detectedAddresses[80]{};
    bool mcpOk[pgl::gld::board::SENSOR_COUNT]{};
    uint8_t mcpAddrMask[pgl::gld::board::SENSOR_COUNT]{};
    uint8_t mcpOkCount = 0;
};

struct BootMcpControlReport {
    bool tested = false;
    bool dacReady = false;
    bool writeLow[pgl::gld::board::SENSOR_COUNT]{};
    bool writeHigh[pgl::gld::board::SENSOR_COUNT]{};
};

struct BootDiagnosticsResult {
    BootAdsReport ads;
    BootI2cReport i2c;
    BootMcpControlReport mcpControl;
};

uint8_t bootBoolMask(const bool values[pgl::gld::board::SENSOR_COUNT]);

const char* bootReportFailureReason(const BootAdsReport& adsReport,
                                    const BootI2cReport& i2cReport,
                                    const BootMcpControlReport& mcpControl,
                                    bool radioChecked,
                                    bool radioOk,
                                    bool mlChecked,
                                    bool mlOk) {
    if (!adsReport.ok) return "ads_boot_fail";
    if (!i2cReport.tcaOk) return "tca_boot_fail";
    for (uint8_t sensor = 0; sensor < pgl::gld::board::SENSOR_COUNT; ++sensor) {
        const bool mcpOk = mcpControl.tested
                               ? i2cReport.mcpOk[sensor] &&
                                     mcpControl.dacReady &&
                                     mcpControl.writeLow[sensor] &&
                                     mcpControl.writeHigh[sensor]
                               : i2cReport.mcpOk[sensor];
        if (!mcpOk) return "mcp_boot_fail";
    }
    if (radioChecked && !radioOk) return "lora_boot_fail";
    if (mlChecked && !mlOk) return "ml_boot_fail";
    return nullptr;
}

bool bootReportHasNonAdsFailure(const BootI2cReport& i2cReport,
                                const BootMcpControlReport& mcpControl,
                                bool radioChecked,
                                bool radioOk,
                                bool mlChecked,
                                bool mlOk) {
    if (!i2cReport.tcaOk) return true;
    for (uint8_t sensor = 0; sensor < pgl::gld::board::SENSOR_COUNT; ++sensor) {
        const bool mcpOk = mcpControl.tested
                               ? i2cReport.mcpOk[sensor] &&
                                     mcpControl.dacReady &&
                                     mcpControl.writeLow[sensor] &&
                                     mcpControl.writeHigh[sensor]
                               : i2cReport.mcpOk[sensor];
        if (!mcpOk) return true;
    }
    if (radioChecked && !radioOk) return true;
    if (mlChecked && !mlOk) return true;
    return false;
}

void armBootReportRecoveryIfNeeded(const BootAdsReport& adsReport,
                                   const BootI2cReport& i2cReport,
                                   const BootMcpControlReport& mcpControl,
                                   bool radioChecked,
                                   bool radioOk,
                                   bool mlChecked,
                                   bool mlOk) {
    if (SENSORLESS_BENCH && SIMULATED_MODEL_OUTPUT && (!radioChecked || radioOk)) {
        bootRecoveryArmed = false;
        bootRecoveryRestartAllowed = false;
        bootRecoveryNonAdsFailure = false;
        bootRecoveryRestartCount = 0;
        copyBounded(bootRecoveryReason, sizeof(bootRecoveryReason), "none");
        return;
    }

    const char* reason = bootReportFailureReason(adsReport, i2cReport, mcpControl,
                                                 radioChecked, radioOk, mlChecked, mlOk);
    if (reason == nullptr) {
        bootRecoveryArmed = false;
        bootRecoveryRestartAllowed = false;
        bootRecoveryNonAdsFailure = false;
        bootRecoveryRestartCount = 0;
        copyBounded(bootRecoveryReason, sizeof(bootRecoveryReason), "none");
        return;
    }

    // Sensor-path I2C failures must remain visible to the operator, but they
    // are not safe reasons to repeatedly reboot a 24 V GLD2 while modules are
    // being powered, wired, or diagnosed.  In particular, a missing root TCA
    // makes every MCP absent too; rebooting cannot restore an I2C ACK and
    // starves the serial diagnostic/control path.
    if (strcmp(reason, "mcp_boot_fail") == 0 ||
        strcmp(reason, "tca_boot_fail") == 0) {
        bootRecoveryArmed = false;
        bootRecoveryRestartAllowed = false;
        bootRecoveryNonAdsFailure = true;
        bootRecoveryRestartCount = 0;
        copyBounded(bootRecoveryReason, sizeof(bootRecoveryReason), reason);
        setRecoveryReason(reason);
        logPrintf("BOOT_RECOVERY_DISABLED reason=%s action=keep_running\n", reason);
        return;
    }

    bootRecoveryArmed = true;
    bootRecoveryNonAdsFailure = bootReportHasNonAdsFailure(i2cReport, mcpControl,
                                                           radioChecked, radioOk,
                                                           mlChecked, mlOk);
    bootRecoveryRestartAllowed = bootRecoveryNonAdsFailure || !adsReport.ok;
    bootRecoveryDueMs = millis() + BOOT_RECOVERY_DELAY_MS;
    copyBounded(bootRecoveryReason, sizeof(bootRecoveryReason), reason);
    setRecoveryReason(reason);
    logPrintf("BOOT_RECOVERY_ARM reason=%s delayMs=%lu restartCount=%u maxRestart=%u\n",
              bootRecoveryReason,
              static_cast<unsigned long>(BOOT_RECOVERY_DELAY_MS),
              static_cast<unsigned>(bootRecoveryRestartCount),
              static_cast<unsigned>(BOOT_RECOVERY_MAX_RESTARTS));
}

void maintainBootReportRecovery() {
    if (!bootRecoveryArmed) return;
    if (static_cast<int32_t>(millis() - bootRecoveryDueMs) < 0) return;

    bootRecoveryArmed = false;
    logPrintf("BOOT_RECOVERY_DUE reason=%s adsReady=%u restartCount=%u\n",
              bootRecoveryReason,
              adsReady ? 1 : 0,
              static_cast<unsigned>(bootRecoveryRestartCount));

    if (!adsReady) {
        setRecoveryReason("boot_report_ads_retry");
        logPrintln("BOOT_RECOVERY_RETRY target=ADS1256");
        const bool ok = ads.begin(gldSpi);
        adsReady = ok;
        if (ok) {
            ++adsRecoveryCount;
            adsReadFailStreak = 0;
            logPrintf("BOOT_RECOVERY_RETRY_RESULT target=ADS1256 result=OK count=%lu\n",
                      static_cast<unsigned long>(adsRecoveryCount));
            if (!bootRecoveryNonAdsFailure) {
                bootRecoveryRestartAllowed = false;
                copyBounded(bootRecoveryReason, sizeof(bootRecoveryReason), "none");
                logPrintln("BOOT_RECOVERY_CLEAR reason=ads_retry_ok");
                return;
            }
        } else {
            ++adsRecoveryFailCount;
            logPrintf("BOOT_RECOVERY_RETRY_RESULT target=ADS1256 result=FAIL failCount=%lu\n",
                      static_cast<unsigned long>(adsRecoveryFailCount));
        }
    }

    if (!bootRecoveryRestartAllowed) return;
    if (!bootRecoveryNonAdsFailure && adsReady) return;
    if (bootRecoveryRestartCount >= BOOT_RECOVERY_MAX_RESTARTS) {
        logPrintf("BOOT_RECOVERY_RESTART_SUPPRESSED reason=%s restartCount=%u maxRestart=%u\n",
                  bootRecoveryReason,
                  static_cast<unsigned>(bootRecoveryRestartCount),
                  static_cast<unsigned>(BOOT_RECOVERY_MAX_RESTARTS));
        return;
    }

    ++bootRecoveryRestartCount;
    logPrintf("BOOT_RECOVERY_RESTART reason=%s restartCount=%u delayMs=%lu\n",
              bootRecoveryReason,
              static_cast<unsigned>(bootRecoveryRestartCount),
              static_cast<unsigned long>(BOOT_RECOVERY_DELAY_MS));
    Serial.flush();
#if defined(ARDUINO_ARCH_ESP32)
    Serial0.flush();
#endif
    ESP.restart();
}

bool i2cAck(uint8_t addr) {
    firmwareServiceTick();
    Wire.beginTransmission(addr);
    const bool ok = Wire.endTransmission() == 0;
    firmwareServiceTick();
    return ok;
}

bool tcaSelect(uint8_t muxChannel) {
    if (muxChannel > 7) return false;
    firmwareServiceTick();
    Wire.beginTransmission(pgl::gld::board::TCA9548A_ADDR);
    Wire.write(static_cast<uint8_t>(1U << muxChannel));
    const bool ok = Wire.endTransmission() == 0;
    firmwareServiceTick();
    return ok;
}

bool tcaDisableAll() {
    firmwareServiceTick();
    Wire.beginTransmission(pgl::gld::board::TCA9548A_ADDR);
    Wire.write(static_cast<uint8_t>(0));
    const bool ok = Wire.endTransmission() == 0;
    firmwareServiceTick();
    return ok;
}

bool recoverGld2RootI2cForPcf(const char* source);

void probeInputPullLevels(int pin, int& pulldownLevel, int& pullupLevel) {
    pinMode(static_cast<uint8_t>(pin), INPUT_PULLDOWN);
    delay(2);
    pulldownLevel = digitalRead(pin);
    pinMode(static_cast<uint8_t>(pin), INPUT_PULLUP);
    delay(2);
    pullupLevel = digitalRead(pin);
    pinMode(static_cast<uint8_t>(pin), INPUT);
}

uint8_t readAdsRegisterRawNoWait(uint8_t reg) {
    firmwareServiceTick();
    gldSpi.beginTransaction(SPISettings(ADS1256_SPI_HZ, MSBFIRST, SPI_MODE1));
    digitalWrite(pgl::gld::board::PIN_ADS1256_CS, LOW);
    delayMicroseconds(5);
    gldSpi.transfer(static_cast<uint8_t>(ADS1256_RREG_CMD | (reg & 0x0F)));
    gldSpi.transfer(0x00);
    delayMicroseconds(5);
    const uint8_t value = gldSpi.transfer(0xFF);
    digitalWrite(pgl::gld::board::PIN_ADS1256_CS, HIGH);
    gldSpi.endTransaction();
    firmwareServiceTick();
    return value;
}

BootAdsReport probeBootAds(bool ok) {
    BootAdsReport report{};
    report.ok = ok;
    report.drdyLevel = digitalRead(pgl::gld::board::PIN_ADS1256_DRDY);
    report.csLevel = digitalRead(pgl::gld::board::PIN_ADS1256_CS);
    report.syncLevel = digitalRead(pgl::gld::board::PIN_ADS1256_SYNC);
    report.reason = ok ? "ok" : (report.drdyLevel == HIGH ? "drdy_timeout" : "init_failed");
    report.status = readAdsRegisterRawNoWait(ADS1256_REG_STATUS);
    report.mux = readAdsRegisterRawNoWait(ADS1256_REG_MUX);
    report.adcon = readAdsRegisterRawNoWait(ADS1256_REG_ADCON);
    report.drate = readAdsRegisterRawNoWait(ADS1256_REG_DRATE);
    probeInputPullLevels(
        pgl::gld::board::PIN_ADS1256_DRDY,
        report.drdyPulldownLevel,
        report.drdyPullupLevel);
    probeInputPullLevels(
        pgl::gld::board::PIN_SPI_MISO,
        report.misoPulldownLevel,
        report.misoPullupLevel);
    return report;
}

uint8_t scanMcpAddressMaskOnSelectedMux() {
    uint8_t mask = 0;
    for (uint8_t offset = 0; offset < 8; ++offset) {
        const uint8_t addr = static_cast<uint8_t>(pgl::gld::board::MCP4725_ADDR + offset);
        if (i2cAck(addr)) {
            mask |= static_cast<uint8_t>(1U << offset);
        }
    }
    return mask;
}

void scanI2cBus(BootI2cReport& report) {
    size_t used = 0;
    for (uint8_t addr = 0x03; addr <= 0x77; ++addr) {
        if (!i2cAck(addr)) continue;
        ++report.detectedAddressCount;
        const int written = snprintf(report.detectedAddresses + used,
                                     sizeof(report.detectedAddresses) - used,
                                     "%s0x%02X", used == 0 ? "" : ",", addr);
        if (written < 0 || static_cast<size_t>(written) >= sizeof(report.detectedAddresses) - used) {
            copyBounded(report.detectedAddresses, sizeof(report.detectedAddresses), "truncated");
            return;
        }
        used += static_cast<size_t>(written);
    }
    if (used == 0) copyBounded(report.detectedAddresses, sizeof(report.detectedAddresses), "none");
}

void probeSelectedMcp4725(char* addresses, size_t addressesSize, uint8_t& count) {
    // Each selected TCA branch is a known MCP4725-only test path.  Scanning
    // every address on every branch can take nearly a minute when absent I2C
    // addresses consume the configured timeout.  Probe the sole required
    // address instead; the root-bus report remains the full 0x03..0x77 scan.
    const bool mcpAck = i2cAck(pgl::gld::board::MCP4725_ADDR);
    count = mcpAck ? 1 : 0;
    copyBounded(addresses, addressesSize, mcpAck ? "0x60" : "none");
}

BootI2cReport probeBootI2c(bool scanFullBus) {
    BootI2cReport report{};
    // Do this before the full root-address scan.  On a wedged I2C bus,
    // scanning 0x03..0x77 may block the command indefinitely; the line-level
    // recovery instead emits an actionable failure and lets normal runtime
    // continue.
    if (!recoverGld2RootI2cForPcf("boot_i2c_probe")) {
        logPrintln("GLD2_MCP_BOOT_SCAN rootI2cNotIdle=1 skipProbe=1");
        return report;
    }
    firmwareServiceTick();

    // A GLD2 boot report is an isolated electrical diagnostic. Leaving every
    // TPS22919 enabled (PCF=0xFF) permits all external modules to load or hold
    // their downstream I2C branches at once. Start from deterministic 0x00;
    // the report owns no pre-boot power state and deliberately leaves 0x00.
    // Probe the two required root devices before the diagnostic full scan.
    // If neither ACKs while the physical lines are idle, scanning every I2C
    // address adds no information and can block boot on this board.
    if (pgl::gld::board::HAS_PCF8574) {
        report.pcfOk = i2cAck(pgl::gld::board::PCF8574_ADDR);
    }
    const bool directTcaAck = i2cAck(pgl::gld::board::TCA9548A_ADDR);
    report.tcaOk = directTcaAck;
    if (!report.pcfOk && !directTcaAck) {
        copyBounded(report.detectedAddresses, sizeof(report.detectedAddresses), "root_no_ack");
        logPrintln("GLD2_MCP_BOOT_SCAN rootDevicesNoAck=1 skipFullScan=1");
        return report;
    }

    bool bootIsolationActive = false;
    if (pgl::gld::board::HAS_PCF8574) {
        if (report.pcfOk && !pcfReady) {
            pcfReady = pcf8574.begin(Wire);
            logPrintf("GLD2_MCP_BOOT_SCAN pcfReinitBeforeIsolation=%u\n", pcfReady ? 1u : 0u);
        }
        if (report.pcfOk && pcfReady) {
            const bool offOk = pcf8574.writeOutputs(
                pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_OFF);
            bootIsolationActive = offOk;
            pcfAllLoadSwitchesOn = false;
            logPrintf("GLD2_MCP_BOOT_SCAN isolateAll beforeRoot pcf=0x00 off=%u\n",
                      offOk ? 1u : 0u);
            if (offOk) {
                serviceDelay(BOOT_SENSOR_MODULE_POWER_SETTLE_MS);
            }
        }
    }
    if (scanFullBus) {
        report.fullBusScanPerformed = true;
        scanI2cBus(report);
    }
    const bool rootScanSawTca = report.fullBusScanPerformed &&
                                strstr(report.detectedAddresses, "0x71") != nullptr;
    report.tcaOk = directTcaAck || rootScanSawTca;
    if (rootScanSawTca && !directTcaAck) {
        logPrintln("GLD2_MCP_BOOT_SCAN usingRootTcaAck=1 directTcaAck=0");
    }

    // GLD2 module discovery follows the verified physical header pairings:
    // EN0->SCL7/SDA7, EN1->SCL0/SDA0, EN2->SCL1/SDA1, EN3->SCL4/SDA4,
    // EN4->SCL3/SDA3, EN5->SCL2/SDA2, EN6->SCL6/SDA6, EN7->SCL5/SDA5.
    // Every boot report enables exactly one TPS22919 per scan, irrespective
    // of power mode, and leaves all EN lines OFF afterward.
    if (report.tcaOk && report.pcfOk && pgl::gld::board::HAS_PCF8574 && !pcfReady) {
        pcfReady = pcf8574.begin(Wire);
        logPrintf("GLD2_MCP_BOOT_SCAN pcfReinitAfterRootAck=%u\n", pcfReady ? 1u : 0u);
    }
    bool isolatedMcpScanPerformed = false;
    if (report.tcaOk && report.pcfOk && pcfReady && bootIsolationActive) {
        uint8_t outputs = pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_OFF;
        const bool resetOutputsOk = true;
        // Scan channel is the user-visible header order, not the literal U33
        // mux number. For example scan channel 0 is H2/EN0/SCL7/SDA7 and it
        // therefore writes physical TCA mux 7.
        for (uint8_t scanChannel = 0; scanChannel < pgl::gld::board::SENSOR_COUNT;
             ++scanChannel) {
            const uint8_t en = pgl::gld::board::SENSOR_TO_POWER_EN[scanChannel];
            outputs = static_cast<uint8_t>(1U << en);
            const bool powerOk = pcf8574.writeOutputs(outputs);
            if (powerOk) {
                serviceDelay(BOOT_SENSOR_MODULE_POWER_SETTLE_MS);
            }

            const uint8_t muxChannel = pgl::gld::board::SENSOR_TO_MUX_CH[scanChannel];
            const bool selected = tcaSelect(muxChannel);
            char addresses[80]{};
            uint8_t count = 0;
            if (selected) {
                probeSelectedMcp4725(addresses, sizeof(addresses), count);
            } else {
                copyBounded(addresses, sizeof(addresses), "not_selected");
            }
            // This is the authoritative MCP result: precisely one TPS22919
            // branch is powered and its matching TCA channel is selected.
            // A later all-modules-on scan cannot distinguish equal 0x60
            // addresses and must not overwrite this evidence.
            const bool mcpDetected = selected && strstr(addresses, "0x60") != nullptr;
            report.mcpAddrMask[scanChannel] = mcpDetected ? 0x01 : 0x00;
            report.mcpOk[scanChannel] = mcpDetected;
            if (mcpDetected) ++report.mcpOkCount;
            const bool deselected = tcaDisableAll();
            const bool rootTcaRecovered = deselected && i2cAck(pgl::gld::board::TCA9548A_ADDR);
            const bool powerOffAfterScan = pcf8574.writeOutputs(
                pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_OFF);
            logPrintf("GLD2_MCP_BOOT_SCAN channel=%u header=%s sensor=%s en=%u pcfOutputs=0x%02X "
                      "pcfResetOk=%u pcfWriteOk=%u tcaMux=%u lines=SCL%u/SDA%u selected=%u "
                      "count=%u addrs=%s tcaOff=%u rootTcaAck=%u sensorOff=%u\n",
                      static_cast<unsigned>(scanChannel), pgl::gld::board::SENSOR_HEADERS[scanChannel],
                      pgl::gld::board::SENSOR_NAMES[scanChannel], static_cast<unsigned>(en), outputs,
                      resetOutputsOk ? 1u : 0u,
                      powerOk ? 1u : 0u, static_cast<unsigned>(muxChannel),
                      static_cast<unsigned>(muxChannel), static_cast<unsigned>(muxChannel),
                      selected ? 1u : 0u, static_cast<unsigned>(count), addresses,
                      deselected ? 1u : 0u, rootTcaRecovered ? 1u : 0u,
                      powerOffAfterScan ? 1u : 0u);
        }
        isolatedMcpScanPerformed = true;
    } else if (report.tcaOk && report.pcfOk && pcfReady && !bootIsolationActive) {
        logPrintln("GLD2_MCP_BOOT_SCAN skipped isolation_failed=1");
    } else if (report.tcaOk) {
        logPrintf("GLD2_MCP_BOOT_SCAN skipped tcaOk=1 pcfOk=%u pcfReady=%u\n",
                  report.pcfOk ? 1u : 0u, pcfReady ? 1u : 0u);
    }

    if (!isolatedMcpScanPerformed) {
        for (uint8_t sensor = 0; sensor < pgl::gld::board::SENSOR_COUNT; ++sensor) {
            firmwareServiceTick();
            const uint8_t muxChannel = static_cast<uint8_t>(pgl::gld::board::SENSOR_TO_MUX_CH[sensor]);
            const bool muxOk = report.tcaOk && tcaSelect(muxChannel);
            report.mcpAddrMask[sensor] = muxOk ? scanMcpAddressMaskOnSelectedMux() : 0;
            report.mcpOk[sensor] = (report.mcpAddrMask[sensor] & 0x01) != 0;
            if (report.mcpOk[sensor]) ++report.mcpOkCount;
        }
    }
    tcaDisableAll();
    if (bootIsolationActive) {
        const bool finalOffOk = pcf8574.writeOutputs(
            pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_OFF);
        pcfAllLoadSwitchesOn = false;
        logPrintf("GLD2_MCP_BOOT_SCAN completePcf=0x00 finalOff=%u\n",
                  finalOffOk ? 1u : 0u);
    }
    return report;
}

// Observational I2C check for the operator's current sensor-power state.
// It never writes PCF8574/EN, never initializes GldDacMux, and never writes a
// DAC code. A powered-off module is intentionally reported as unavailable.
BootI2cReport probeCurrentStateI2c(bool scanFullBus) {
    BootI2cReport report{};
    if (!recoverGld2RootI2cForPcf("current_state_i2c_probe")) {
        logPrintln("GLD2_CURRENT_I2C rootI2cNotIdle=1 skipProbe=1");
        return report;
    }
    firmwareServiceTick();
    // Bound the observation just like boot diagnostics.  With no root-device
    // ACK there cannot be a reachable downstream MCP, so do not perform the
    // optional broad scan or a final TCA write that can stall this command.
    report.tcaOk = i2cAck(pgl::gld::board::TCA9548A_ADDR);
    report.pcfOk = pgl::gld::board::HAS_PCF8574 &&
                   i2cAck(pgl::gld::board::PCF8574_ADDR);
    if (!report.tcaOk && !report.pcfOk) {
        copyBounded(report.detectedAddresses, sizeof(report.detectedAddresses), "root_no_ack");
        logPrintln("GLD2_CURRENT_I2C rootDevicesNoAck=1 skipRest=1");
        return report;
    }
    if (scanFullBus) {
        report.fullBusScanPerformed = true;
        scanI2cBus(report);
    }
    const bool rootScanSawTca = report.fullBusScanPerformed &&
                                strstr(report.detectedAddresses, "0x71") != nullptr;
    report.tcaOk = report.tcaOk || rootScanSawTca;

    for (uint8_t sensor = 0; sensor < pgl::gld::board::SENSOR_COUNT; ++sensor) {
        firmwareServiceTick();
        const uint8_t muxChannel = static_cast<uint8_t>(pgl::gld::board::SENSOR_TO_MUX_CH[sensor]);
        const bool selected = report.tcaOk && tcaSelect(muxChannel);
        report.mcpAddrMask[sensor] = selected ? scanMcpAddressMaskOnSelectedMux() : 0;
        report.mcpOk[sensor] = (report.mcpAddrMask[sensor] & 0x01U) != 0;
        if (report.mcpOk[sensor]) ++report.mcpOkCount;
    }
    tcaDisableAll();
    return report;
}

BootMcpControlReport testBootMcpControl(bool externalPower) {
    BootMcpControlReport report{};
    if (!externalPower) {
        return report;
    }

    report.tested = true;
    dac.setSensorPowerSettleMs(BOOT_DAC_SENSOR_POWER_SETTLE_MS);
    dac.setRestoreSensorPowerAfterWrite(false);
    // A DAC edge test is part of Boot IC Report, so it follows the same
    // one-TPS22919-at-a-time rule as MCP discovery even on external 24 V.
    // GldDacMux restores the PCF mask it captured on exit.
    const bool diagnosticPowerIsolation = pgl::gld::board::HAS_PCF8574 && pcfReady;
    dac.setAutomaticSensorPowerControl(diagnosticPowerIsolation);
    (void)dac.begin(Wire, &pcf8574);
    dacReady = dac.ready();
    report.dacReady = dacReady;
    if (!dacReady) {
        dac.setAutomaticSensorPowerControl(batteryPowerMode);
        dac.setRestoreSensorPowerAfterWrite(true);
        dac.setSensorPowerSettleMs(NORMAL_DAC_SENSOR_POWER_SETTLE_MS);
        return report;
    }

    for (uint8_t sensor = 0; sensor < pgl::gld::board::SENSOR_COUNT; ++sensor) {
#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
        // GLD3 boot control must leave every MCP at the value it loaded when
        // its isolated rail was enabled. The read is intentionally after the
        // rail transition, so this is an EEPROM-loaded baseline rather than a
        // claim about a possibly different pre-diagnostic volatile value.
        uint16_t baseline = 0;
        const bool baselineRead = dac.readDac(sensor, baseline);
        bool lowOk = true;
        bool highOk = true;
        for (uint8_t offset = 0; offset < BOOT_MCP_TEST_EDGE_COUNT && baselineRead; ++offset) {
            const uint16_t lowCode = static_cast<uint16_t>(BOOT_MCP_TEST_LOW_START + offset);
            lowOk = dac.writeDac(sensor, lowCode) && lowOk;
            serviceDelay(BOOT_DAC_SETTLE_MS);
        }
        uint16_t lowReadback = 0;
        const bool lowRead = baselineRead && lowOk && dac.readDac(sensor, lowReadback);
        const bool lowMatch = lowRead && lowReadback == BOOT_MCP_TEST_LOW_END;
        for (uint8_t offset = 0; offset < BOOT_MCP_TEST_EDGE_COUNT && baselineRead; ++offset) {
            const uint16_t highCode = static_cast<uint16_t>(BOOT_MCP_TEST_HIGH_START + offset);
            highOk = dac.writeDac(sensor, highCode) && highOk;
            serviceDelay(BOOT_DAC_SETTLE_MS);
        }
        uint16_t highReadback = 0;
        const bool highRead = baselineRead && highOk && dac.readDac(sensor, highReadback);
        const bool highMatch = highRead && highReadback == BOOT_MCP_TEST_HIGH_END;
        const bool restoreWrite = baselineRead && dac.writeDac(sensor, baseline);
        uint16_t restoreReadback = 0;
        const bool restoreRead = restoreWrite && dac.readDac(sensor, restoreReadback);
        const bool restoreMatch = restoreRead && restoreReadback == baseline;
        report.writeLow[sensor] = baselineRead && lowOk && lowMatch;
        report.writeHigh[sensor] = highOk && highMatch && restoreMatch;
        logPrintf("GLD3_BOOT_MCP_CONTROL ch=%u baselineScope=isolated_power_on baseline=%u baselineRead=%u "
                  "low=%u lowRead=%u lowMatch=%u high=%u highRead=%u highMatch=%u "
                  "restoreWrite=%u restoreRead=%u restoreMatch=%u\n",
                  static_cast<unsigned>(sensor), static_cast<unsigned>(baseline),
                  baselineRead ? 1u : 0u, lowOk ? 1u : 0u, lowRead ? 1u : 0u,
                  lowMatch ? 1u : 0u, highOk ? 1u : 0u, highRead ? 1u : 0u,
                  highMatch ? 1u : 0u, restoreWrite ? 1u : 0u,
                  restoreRead ? 1u : 0u, restoreMatch ? 1u : 0u);
#else
        bool lowOk = true;
        bool highOk = true;
        for (uint8_t offset = 0; offset < BOOT_MCP_TEST_EDGE_COUNT; ++offset) {
            const uint16_t lowCode = static_cast<uint16_t>(BOOT_MCP_TEST_LOW_START + offset);
            lowOk = dac.writeDac(sensor, lowCode) && lowOk;
            serviceDelay(BOOT_DAC_SETTLE_MS);
        }
        for (uint8_t offset = 0; offset < BOOT_MCP_TEST_EDGE_COUNT; ++offset) {
            const uint16_t highCode = static_cast<uint16_t>(BOOT_MCP_TEST_HIGH_START + offset);
            highOk = dac.writeDac(sensor, highCode) && highOk;
            serviceDelay(BOOT_DAC_SETTLE_MS);
        }
        report.writeLow[sensor] = lowOk;
        report.writeHigh[sensor] = highOk;
#endif
    }
    const bool restorePowerOk = dac.restoreSensorPower();
    dac.setAutomaticSensorPowerControl(batteryPowerMode);
    dac.setRestoreSensorPowerAfterWrite(true);
    dac.setSensorPowerSettleMs(NORMAL_DAC_SENSOR_POWER_SETTLE_MS);
    if (!restorePowerOk) {
        report.dacReady = false;
    }
    return report;
}

BootDiagnosticsResult runBootHardwareDiagnostics(bool externalPower, bool automaticSensorPowerControl) {
    BootDiagnosticsResult result{};

    logPrintln("BOOT_PROBE_ADS=start");
    adsReady = ads.begin(gldSpi);
    logPrintf("ADS_BEGIN_RESULT=%s\n", adsReady ? "PASS" : "FAIL");
    result.ads = probeBootAds(adsReady);
    logPrintf("BOOT_PROBE_ADS=done adsReady=%u reason=%s drdy=%d pd=%d pu=%d misoPD=%d misoPU=%d cs=%d sync=%d status=0x%02X mux=0x%02X adcon=0x%02X drate=0x%02X\n",
              adsReady ? 1 : 0,
              result.ads.reason,
              result.ads.drdyLevel,
              result.ads.drdyPulldownLevel,
              result.ads.drdyPullupLevel,
              result.ads.misoPulldownLevel,
              result.ads.misoPullupLevel,
              result.ads.csLevel,
              result.ads.syncLevel,
              result.ads.status,
              result.ads.mux,
              result.ads.adcon,
              result.ads.drate);

    logPrintln("BOOT_PROBE_I2C=start");
    result.i2c = probeBootI2c(externalPower);
    logPrintf("BOOT_PROBE_I2C=done fullScan=%u allAddresses=%s allCount=%u tcaOk=%u pcfOk=%u mcpOkCount=%u/%u mcpMask=0x%02X\n",
              result.i2c.fullBusScanPerformed ? 1 : 0,
              result.i2c.fullBusScanPerformed ? result.i2c.detectedAddresses : "skipped",
              static_cast<unsigned>(result.i2c.detectedAddressCount),
              result.i2c.tcaOk ? 1 : 0,
              result.i2c.pcfOk ? 1 : 0,
              result.i2c.mcpOkCount,
              pgl::gld::board::SENSOR_COUNT,
              bootBoolMask(result.i2c.mcpOk));

    logPrintln("BOOT_PROBE_MCP_CONTROL=start");
    const bool rootI2cReadyForMcpControl = result.i2c.tcaOk &&
        (!pgl::gld::board::HAS_PCF8574 || result.i2c.pcfOk);
    if (rootI2cReadyForMcpControl) {
        result.mcpControl = testBootMcpControl(externalPower);
    } else {
        // Do not let a root I2C outage turn a reported boot failure into a
        // long blocking TCA library call.  The I2C report already carries the
        // authoritative root failure; MCP control is explicitly not tested.
        logPrintln("BOOT_PROBE_MCP_CONTROL=skip reason=root_i2c_unavailable");
    }

    lastBootAdsDrdyLevel = result.ads.drdyLevel;
    lastBootAdsDrdyPulldownLevel = result.ads.drdyPulldownLevel;
    lastBootAdsDrdyPullupLevel = result.ads.drdyPullupLevel;
    lastBootAdsMisoPulldownLevel = result.ads.misoPulldownLevel;
    lastBootAdsMisoPullupLevel = result.ads.misoPullupLevel;
    lastBootAdsCsLevel = result.ads.csLevel;
    lastBootAdsSyncLevel = result.ads.syncLevel;
    lastBootAdsStatus = result.ads.status;
    lastBootAdsMux = result.ads.mux;
    lastBootAdsAdcon = result.ads.adcon;
    lastBootAdsDrate = result.ads.drate;
    lastBootAdsReason = result.ads.reason;
    lastBootTcaOk = result.i2c.tcaOk;
    lastBootMcpOkCount = result.i2c.mcpOkCount;
    lastBootMcpControlTested = result.mcpControl.tested;
    lastBootMcpControlOkCount = 0;
    for (uint8_t sensor = 0; sensor < pgl::gld::board::SENSOR_COUNT; ++sensor) {
        lastBootMcpOk[sensor] = result.i2c.mcpOk[sensor];
        lastBootMcpAddrMask[sensor] = result.i2c.mcpAddrMask[sensor];
        lastBootMcpControlOk[sensor] = result.mcpControl.dacReady &&
                                       result.mcpControl.writeLow[sensor] &&
                                       result.mcpControl.writeHigh[sensor];
        if (lastBootMcpControlOk[sensor]) {
            ++lastBootMcpControlOkCount;
        }
    }
    logPrintf("BOOT_PROBE_MCP_CONTROL=done tested=%u dacReady=%u writeOkCount=%u/%u writeMask=0x%02X\n",
              result.mcpControl.tested ? 1 : 0,
              result.mcpControl.dacReady ? 1 : 0,
              lastBootMcpControlOkCount,
              pgl::gld::board::SENSOR_COUNT,
              bootBoolMask(lastBootMcpControlOk));

    return result;
}

void bootTableRow(const char* ic, const char* check, const char* status, const char* detail) {
    logPrintf("| %-15s | %-18s | %-9s | %-40s |\n", ic, check, status, detail);
}

uint8_t bootBoolMask(const bool values[pgl::gld::board::SENSOR_COUNT]) {
    uint8_t mask = 0;
    for (uint8_t sensor = 0; sensor < pgl::gld::board::SENSOR_COUNT; ++sensor) {
        if (values[sensor]) {
            mask |= static_cast<uint8_t>(1U << sensor);
        }
    }
    return mask;
}

// Recreate the ESP I2C controller after boot diagnostics.  The diagnostic
// walks the TCA branches and an unresponsive downstream module can leave the
// controller in a timeout state even though PCF8574 and TCA9548A themselves
// are root-bus devices.  Do not require the TCA disable write to ACK here: the
// following PCF begin/readback is the authoritative sensor-power gate.
bool recoverGld2RootI2cForPcf(const char* source) {
#if PGL_GLD_BOARD_PROFILE_GLD2
    Wire.end();
    // Release both open-drain lines before reattaching the ESP I2C peripheral.
    // If a timed-out peripheral/device has SDA held LOW, issue the standard
    // bounded 9-clock bus-clear sequence followed by an I2C STOP.  This never
    // writes a PCF/TCA register; it only returns the physical bus to idle.
    pinMode(pgl::gld::board::PIN_I2C_SDA, INPUT_PULLUP);
    pinMode(pgl::gld::board::PIN_I2C_SCL, INPUT_PULLUP);
    delayMicroseconds(20);
    const int sdaBefore = digitalRead(pgl::gld::board::PIN_I2C_SDA);
    const int sclBefore = digitalRead(pgl::gld::board::PIN_I2C_SCL);
    uint8_t clearPulses = 0;
    if (sdaBefore == LOW && sclBefore == HIGH) {
        pinMode(pgl::gld::board::PIN_I2C_SCL, OUTPUT_OPEN_DRAIN);
        digitalWrite(pgl::gld::board::PIN_I2C_SCL, HIGH);
        for (; clearPulses < 9 &&
             digitalRead(pgl::gld::board::PIN_I2C_SDA) == LOW; ++clearPulses) {
            digitalWrite(pgl::gld::board::PIN_I2C_SCL, LOW);
            delayMicroseconds(5);
            digitalWrite(pgl::gld::board::PIN_I2C_SCL, HIGH);
            delayMicroseconds(5);
        }
    }
    // Generate STOP only while SCL is released HIGH; if a device holds SCL
    // LOW, release SDA too and let the subsequent timeout report that fact.
    if (digitalRead(pgl::gld::board::PIN_I2C_SCL) == HIGH) {
        pinMode(pgl::gld::board::PIN_I2C_SDA, OUTPUT_OPEN_DRAIN);
        digitalWrite(pgl::gld::board::PIN_I2C_SDA, LOW);
        delayMicroseconds(5);
        digitalWrite(pgl::gld::board::PIN_I2C_SDA, HIGH);
        delayMicroseconds(5);
    }
    pinMode(pgl::gld::board::PIN_I2C_SDA, INPUT_PULLUP);
    pinMode(pgl::gld::board::PIN_I2C_SCL, INPUT_PULLUP);
    delayMicroseconds(20);
    const int sdaAfter = digitalRead(pgl::gld::board::PIN_I2C_SDA);
    const int sclAfter = digitalRead(pgl::gld::board::PIN_I2C_SCL);
    const bool busIdle = sdaAfter == HIGH && sclAfter == HIGH;
    Wire.begin(pgl::gld::board::PIN_I2C_SDA, pgl::gld::board::PIN_I2C_SCL);
#if defined(ARDUINO_ARCH_ESP32)
    Wire.setTimeOut(BOOT_I2C_TIMEOUT_MS);
#endif
    const bool tcaDisableOk = busIdle && tcaDisableAll();
    logPrintf("GLD2_ROOT_I2C_RECOVERY source=%s sda=%d/%d scl=%d/%d pulses=%u tcaDisable=%u\n",
              source != nullptr ? source : "unknown", sdaBefore, sdaAfter,
              sclBefore, sclAfter, static_cast<unsigned>(clearPulses),
              tcaDisableOk ? 1u : 0u);
    return busIdle;
#else
    (void)source;
    return true;
#endif
}

// Boot diagnostics deliberately end with every TPS22919 OFF.  In a non-battery
// runtime, normal operation then explicitly enables every sensor rail.  This
// is a runtime policy decision, not restoration of an unknown pre-boot state.
void enableNonBatteryRuntimeSensorPower(const char* source) {
#if PGL_GLD_BOARD_PROFILE_GLD2
    if (batteryPowerMode || !pgl::gld::board::HAS_PCF8574) {
        return;
    }
    // Boot DAC control ends after a TCA channel selection. Return to the root
    // bus before updating PCF8574.  PCF begin can have failed before the boot
    // diagnostic selected and released the TCA branches, so it must also be
    // retried here rather than silently preserving the all-OFF power-up mask.
    bool enabled = false;
    bool writeOk = false;
    bool readOk = false;
    uint8_t liveOutputs = pcf8574.outputs();
    uint8_t attempts = 0;
    for (; attempts < 3 && !enabled; ++attempts) {
        if (!recoverGld2RootI2cForPcf(source)) {
            pcfReady = false;
            continue;
        }
        // Do not enter the PCF library when its root address has already
        // failed to ACK.  Some library begin/read paths can wait long enough
        // to trip the ESP watchdog, turning a visible I2C fault into a reboot.
        if (!i2cAck(pgl::gld::board::PCF8574_ADDR)) {
            pcfReady = false;
            logPrintf("GLD2_RUNTIME_SENSOR_POWER source=%s pcfRootAck=0 skipDriver=1\n",
                      source != nullptr ? source : "boot");
            break;
        }
        // Always rebuild the PCF driver after Wire.end/begin.  Reusing its
        // previous cache after an I2C controller timeout can report a stale
        // zero mask or make the first post-diagnostic write fail.
        pcfReady = pcf8574.begin(Wire);
        serviceDelay(20);
        if (!pcfReady) continue;
        writeOk = pcf8574.writeOutputs(pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_ON);
        if (!writeOk) {
            pcfReady = false;
            continue;
        }
        serviceDelay(20);
        readOk = pcf8574.readOutputs(liveOutputs);
        enabled = readOk &&
                  liveOutputs == pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_ON;
        if (!readOk) pcfReady = false;
    }
    pcfAllLoadSwitchesOn = enabled;
    logPrintf("GLD2_RUNTIME_SENSOR_POWER source=%s outputs=0x%02X write=%u read=%u enabled=%u attempts=%u\n",
              source != nullptr ? source : "boot", liveOutputs,
              writeOk ? 1u : 0u, readOk ? 1u : 0u,
              enabled ? 1u : 0u, static_cast<unsigned>(attempts));
#else
    (void)source;
#endif
}

// A nulling run writes every MCP4725.  On GLD2, each MCP sits behind a
// TPS22919-powered sensor module, so do not rely on the old PCF cache or a
// preceding inference session: explicitly command and verify all rails ON.
bool ensureNullingSensorPowerReady(const char* source) {
#if PGL_GLD_BOARD_PROFILE_GLD2
    if (batteryPowerMode || !pgl::gld::board::HAS_PCF8574) return true;
    if (!pcfReady) {
        pcfReady = pcf8574.begin(Wire);
        logPrintf("NULLING_SENSOR_POWER_PCF_REBEGIN=%s source=%s\n",
                  pcfReady ? "PASS" : "FAIL",
                  source != nullptr ? source : "unknown");
    }
    if (!pcfReady) {
        pcfAllLoadSwitchesOn = false;
        logPrintf("NULLING_SENSOR_POWER_READY=FAIL source=%s reason=pcf_not_ready\n",
                  source != nullptr ? source : "unknown");
        return false;
    }
    enableNonBatteryRuntimeSensorPower(source);
    uint8_t liveOutputs = pcf8574.outputs();
    const bool readOk = pcf8574.readOutputs(liveOutputs);
    const bool allOn = pcfAllLoadSwitchesOn && readOk &&
                       liveOutputs == pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_ON;
    pcfAllLoadSwitchesOn = allOn;
    logPrintf("NULLING_SENSOR_POWER_READY=%s source=%s outputs=0x%02X read=%u\n",
              allOn ? "PASS" : "FAIL", source != nullptr ? source : "unknown",
              liveOutputs, readOk ? 1u : 0u);
    return allOn;
#else
    (void)source;
    return true;
#endif
}

// On the affected GLD2 bench unit, every MCP4725 answers during the isolated
// boot test but all eight NACK when every TPS22919 rail is held ON.  Keep the
// thermal warmup all-ON, then isolate only the active module for DAC writes.
// The original PCF mask is captured and restored after the full service.
bool runNullingMcpWritePreflight(const char* source, uint8_t channelMask = 0xFFu) {
#if PGL_GLD_BOARD_PROFILE_GLD2
    if (batteryPowerMode || !pgl::gld::board::HAS_PCF8574) return true;

    dac.captureSensorPowerState();
    dac.setAutomaticSensorPowerControl(true);
    dac.setRestoreSensorPowerAfterWrite(false);
    bool allWritesOk = true;
    for (uint8_t channel = 0; channel < pgl::gld::board::SENSOR_COUNT; ++channel) {
        if ((channelMask & static_cast<uint8_t>(1u << channel)) == 0u) continue;
        const bool writeOk = dac.writeDac(channel, 0);
        logPrintf("NULLING_MCP_PREFLIGHT source=%s ch=%u sensor=%s mux=%u address=0x%02X code=0 ack=%u\n",
                  source != nullptr ? source : "unknown",
                  static_cast<unsigned>(channel), pgl::gld::board::SENSOR_NAMES[channel],
                  static_cast<unsigned>(pgl::gld::board::SENSOR_TO_MUX_CH[channel]),
                  static_cast<unsigned>(pgl::gld::board::MCP4725_ADDR), writeOk ? 1u : 0u);
        allWritesOk = allWritesOk && writeOk;
        if (!writeOk) break;
    }
    const bool restored = dac.restoreSensorPower();
    dac.setAutomaticSensorPowerControl(false);
    dac.setRestoreSensorPowerAfterWrite(true);
    uint8_t outputs = pcf8574.outputs();
    const bool readOk = pcf8574.readOutputs(outputs);
    pcfAllLoadSwitchesOn = restored && readOk &&
                            outputs == pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_ON;
    const bool pass = allWritesOk && pcfAllLoadSwitchesOn;
    logPrintf("NULLING_MCP_PREFLIGHT_DONE=%s source=%s restore=0x%02X read=%u\n",
              pass ? "PASS" : "FAIL", source != nullptr ? source : "unknown",
              outputs, readOk ? 1u : 0u);
    return pass;
#else
    (void)source;
    return true;
#endif
}

bool armNullingMcpIsolation() {
#if PGL_GLD_BOARD_PROFILE_GLD2
    if (batteryPowerMode || !pgl::gld::board::HAS_PCF8574) return true;
    dac.captureSensorPowerState();
    dac.setAutomaticSensorPowerControl(true);
    dac.setRestoreSensorPowerAfterWrite(false);
    logPrintln("NULLING_MCP_ISOLATION=ARMED policy=one_active_rail_after_warmup");
#endif
    return true;
}

bool restoreNullingMcpIsolation() {
#if PGL_GLD_BOARD_PROFILE_GLD2
    if (batteryPowerMode || !pgl::gld::board::HAS_PCF8574) return true;
    const bool restored = dac.restoreSensorPower();
    dac.setAutomaticSensorPowerControl(false);
    dac.setRestoreSensorPowerAfterWrite(true);
    uint8_t outputs = pcf8574.outputs();
    const bool readOk = pcf8574.readOutputs(outputs);
    pcfAllLoadSwitchesOn = restored && readOk &&
                            outputs == pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_ON;
    const bool pass = pcfAllLoadSwitchesOn;
    logPrintf("NULLING_MCP_ISOLATION_RESTORE=%s outputs=0x%02X read=%u\n",
              pass ? "PASS" : "FAIL", outputs, readOk ? 1u : 0u);
    return pass;
#else
    return true;
#endif
}

pgl::gld::GldNullingServiceResult runNullingServiceWithMcpIsolation(uint8_t channelMask = 0xFFu) {
    (void)armNullingMcpIsolation();
    pgl::gld::GldNullingServiceResult result =
        pgl::gld::runNullingService(ads, dac, nullingLogLine, firmwareServiceTick, nullingConfig, channelMask);
    if (!restoreNullingMcpIsolation()) {
        result.status = pgl::gld::GldNullingStatus::DacNotReady;
        result.successCount = 0;
    }
    return result;
}

void printBootIcReport(const pgl::gld::GldPowerReading& power,
                       const BootAdsReport& adsReport,
                       const BootI2cReport& i2cReport,
                       const BootMcpControlReport& mcpControl,
                       bool radioChecked,
                       bool radioOk,
                       bool mlChecked,
                       bool mlOk,
                       int mlOutputSize,
                       bool modeReady,
                       const char* modeDetail) {
    char detail[256];

    if (i2cReport.fullBusScanPerformed) {
        logPrintf("GLD2_I2C_SCAN range=0x03-0x77 count=%u addrs=%s\n",
                  static_cast<unsigned>(i2cReport.detectedAddressCount),
                  i2cReport.detectedAddresses);
    }
    logPrintln("[BOOT_IC_REPORT]");
    logPrintln("+-----------------+--------------------+-----------+------------------------------------------+");
    logPrintln("| IC/Fungsi       | Check              | Status    | Detail                                   |");
    logPrintln("+-----------------+--------------------+-----------+------------------------------------------+");

    snprintf(detail, sizeof(detail), "mode=%s external=%u batteryMv=%u",
             pgl::gld::gldPowerModeName(power.mode),
             power.externalPower ? 1 : 0,
             power.batteryMv);
    bootTableRow("POWER", "sense", "OK", detail);

    snprintf(detail, sizeof(detail), "SCK=%d MOSI=%d MISO=%d",
             pgl::gld::board::PIN_SPI_SCK,
             pgl::gld::board::PIN_SPI_MOSI,
             pgl::gld::board::PIN_SPI_MISO);
    bootTableRow("SPI_BUS", "pins", "OK", detail);

    snprintf(detail, sizeof(detail), "reason=%s DRDY=%d ST=0x%02X",
             adsReport.reason,
             adsReport.drdyLevel,
             adsReport.status);
    bootTableRow("ADS1256", "SPI begin", okNotOk(adsReport.ok), detail);

    snprintf(detail, sizeof(detail), "SDA=%d SCL=%d",
             pgl::gld::board::PIN_I2C_SDA,
             pgl::gld::board::PIN_I2C_SCL);
    bootTableRow("I2C_BUS", "pins", "OK", detail);

    if (i2cReport.fullBusScanPerformed) {
        snprintf(detail, sizeof(detail), "count=%u addrs=%s",
                 static_cast<unsigned>(i2cReport.detectedAddressCount),
                 i2cReport.detectedAddresses);
        bootTableRow("I2C_SCAN", "0x03-0x77", "INFO", detail);
    }

    snprintf(detail, sizeof(detail), "addr=0x%02X",
             pgl::gld::board::TCA9548A_ADDR);
    bootTableRow("TCA9548A", "I2C ACK", okNotOk(i2cReport.tcaOk), detail);

    if (pgl::gld::board::HAS_PCF8574) {
        snprintf(detail, sizeof(detail), "addr=0x%02X", pgl::gld::board::PCF8574_ADDR);
        bootTableRow("PCF8574", "I2C ACK", okNotOk(i2cReport.pcfOk), detail);
    }

    for (uint8_t sensor = 0; sensor < pgl::gld::board::SENSOR_COUNT; ++sensor) {
        char icName[24];
        snprintf(icName, sizeof(icName), "MCP4725-%s", pgl::gld::board::SENSOR_NAMES[sensor]);
        const bool testedOk = i2cReport.mcpOk[sensor] &&
                              mcpControl.dacReady &&
                              mcpControl.writeLow[sensor] &&
                              mcpControl.writeHigh[sensor];
        const char* status = mcpControl.tested
                                 ? (testedOk ? "OK_TESTED" : "NOT_OK")
                                 : okNotOk(i2cReport.mcpOk[sensor]);
        if (mcpControl.tested) {
            snprintf(detail, sizeof(detail), "mux=%u addr=0x%02X addrMask=0x%02X write=%u-%u,%u-%u",
                     static_cast<unsigned>(pgl::gld::board::SENSOR_TO_MUX_CH[sensor]),
                     pgl::gld::board::MCP4725_ADDR,
                     i2cReport.mcpAddrMask[sensor],
                     static_cast<unsigned>(BOOT_MCP_TEST_LOW_START),
                     static_cast<unsigned>(BOOT_MCP_TEST_LOW_END),
                     static_cast<unsigned>(BOOT_MCP_TEST_HIGH_START),
                     static_cast<unsigned>(BOOT_MCP_TEST_HIGH_END));
        } else {
            snprintf(detail, sizeof(detail), "mux=%u addr=0x%02X addrMask=0x%02X ack only",
                     static_cast<unsigned>(pgl::gld::board::SENSOR_TO_MUX_CH[sensor]),
                     pgl::gld::board::MCP4725_ADDR,
                     i2cReport.mcpAddrMask[sensor]);
        }
        bootTableRow(icName, mcpControl.tested ? "I2C+DAC write" : "I2C ACK", status, detail);
    }

    snprintf(detail, sizeof(detail), "NSS=%d DIO1=%d RST=%d BUSY=%d state=%d",
             pgl::gld::board::PIN_LORA_CS,
             pgl::gld::board::PIN_LORA_DIO1,
             pgl::gld::board::PIN_LORA_RST,
             pgl::gld::board::PIN_LORA_BUSY,
             static_cast<int>(lastLoraBeginState));
    bootTableRow("SX1262", "LoRa begin", checkedOkNotOk(radioChecked, radioOk), detail);

    snprintf(detail, sizeof(detail), "classes=%d model outputs", mlOutputSize);
    bootTableRow("ML_MODEL", "init/classes", checkedOkNotOk(mlChecked, mlOk), detail);

    bootTableRow("MODE_READY", pgl::gld::gldModeName(currentMode), okNotOk(modeReady), modeDetail);
    logPrintln("+-----------------+--------------------+-----------+------------------------------------------+");
}

// ---------------------------------------------------------------------------
// WiFi + MQTT helpers (dataset mode only)
// ---------------------------------------------------------------------------

void disableNetworkForOfflineMode(const char* reason) {
    if (mqtt.connected()) mqtt.disconnect();
    wifiClient.stop();
    WiFi.disconnect(true);
    WiFi.mode(WIFI_OFF);
    logPrintf("WIFI_OFF mode=%s reason=%s\n",
              pgl::gld::gldModeName(currentMode),
              reason != nullptr ? reason : "offline_mode");
}

bool connectWifi() {
    ++wifiReconnectCount;
    setRecoveryReason("wifi_connect");
    logPrintf("WIFI_CONNECT ssid=%s\n", runtimeConfig.wifiSsid);
    WiFi.mode(WIFI_STA);
    WiFi.begin(runtimeConfig.wifiSsid, runtimeConfig.wifiPassword);
    const uint32_t t0 = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t0 < WIFI_TIMEOUT_MS) {
        serviceDelay(50);
    }
    const bool ok = WiFi.status() == WL_CONNECTED;
    if (!ok) {
        ++wifiReconnectFailCount;
        setRecoveryReason("wifi_connect_failed");
    }
    logPrintf(ok ? "WIFI_CONNECTED ip=%s\n" : "WIFI_CONNECT_FAILED\n",
              ok ? WiFi.localIP().toString().c_str() : "");
    return ok;
}

void maintainWifi() {
    if (WiFi.status() != WL_CONNECTED) connectWifi();
}

// Forward declarations
bool mqttConnect();
void mqttCallback(char* topic, byte* payload, unsigned int length);

bool mqttConnect() {
    if (mqtt.connected()) return true;
    const uint32_t now = millis();
    if (now - lastMqttAttemptMs < MQTT_RETRY_MS) return false;
    lastMqttAttemptMs = now;
    ++mqttReconnectCount;
    setRecoveryReason("mqtt_connect");
    mqtt.setServer(runtimeConfig.mqttHost, runtimeConfig.mqttPort);
    mqtt.setCallback(mqttCallback);
    logPrintf("MQTT_CONNECT host=%s port=%u\n", runtimeConfig.mqttHost, runtimeConfig.mqttPort);
    const bool ok = mqtt.connect(mqttClientId, runtimeConfig.mqttUser, runtimeConfig.mqttPass);
    lastMqttState = mqtt.state();
    if (!ok) {
        ++mqttConnectFailCount;
        setRecoveryReason("mqtt_connect_failed");
    }
    logPrintf("MQTT_CONNECT_RESULT=%s state=%d attempt=%lu failCount=%lu\n",
              ok ? "OK" : "FAIL",
              lastMqttState,
              static_cast<unsigned long>(mqttReconnectCount),
              static_cast<unsigned long>(mqttConnectFailCount));
    if (ok) {
        mqtt.subscribe(topicCmd);
        if (currentMode == pgl::gld::GldMode::DATASET) {
            mqtt.subscribe(topicDataset);
        }
    } else {
        wifiClient.stop();
    }
    return ok;
}

void maintainMqtt() {
    if (!mqtt.connected()) mqttConnect();
    else mqtt.loop();
}

// ---------------------------------------------------------------------------
// MQTT publish helpers
// ---------------------------------------------------------------------------

void publishCmdAck(const char* cmd, const char* result) {
    StaticJsonDocument<128> doc;
    doc["device_id"] = runtimeConfig.deviceId;
    doc["cmd"] = cmd;
    doc["result"] = result;
    doc["timestamp_ms"] = static_cast<uint32_t>(millis());
    char buf[128];
    serializeJson(doc, buf, sizeof(buf));
    mqtt.publish(topicAck, buf, false);
}

void publishDatasetStatus(const char* state, const char* detail) {
    StaticJsonDocument<384> doc;
    doc["device_id"] = runtimeConfig.deviceId;
    doc["stage"] = "DATASET";
    doc["state"] = state;
    doc["detail"] = detail;
    doc["queue_pending"] = datasetQueueCount;
    doc["queue_dropped"] = datasetQueueDropped;
    doc["publish_fail_count"] = datasetPublishFailCount;
    doc["rejected_samples"] = datasetRejectedSamples;
    doc["last_reject_reason"] =
        pgl::gld::gldDatasetRejectReasonName(lastDatasetRejectReason);
    doc["last_reject_channel"] = static_cast<int>(lastDatasetRejectChannel);
    doc["last_reject_ok_finite_count"] = lastDatasetRejectOkFiniteCount;
    doc["last_reject_status"] = lastDatasetRejectStatus;
    doc["last_reject_gain"] = lastDatasetRejectGain;
    doc["last_reject_saturated"] = lastDatasetRejectSaturated;
    char buf[384];
    serializeJson(doc, buf, sizeof(buf));
    mqtt.publish(topicStatus, buf, false);
}

void publishDatasetRejectedStatus(
    const pgl::gld::GldDatasetValidationResult& validation,
    const pgl::gld::GldDatasetChannelSample* samples,
    size_t count) {
    StaticJsonDocument<512> doc;
    doc["device_id"] = runtimeConfig.deviceId;
    doc["stage"] = "DATASET";
    doc["state"] = "sample_rejected";
    doc["detail"] = pgl::gld::gldDatasetRejectReasonName(validation.reason);
    doc["attempted_seq"] = datasetSeq;
    doc["rejected_samples"] = datasetRejectedSamples;
    doc["expected_channel_count"] = pgl::gld::GLD_DATASET_FEATURE_COUNT;
    doc["actual_channel_count"] = count;
    doc["ok_finite_count"] = validation.okFiniteCount;
    doc["channel"] = static_cast<int>(validation.channel);
    if (validation.channel >= 0 &&
        static_cast<size_t>(validation.channel) < count && samples != nullptr) {
        const size_t channel = static_cast<size_t>(validation.channel);
        const pgl::gld::GldDatasetChannelSample& sample = samples[channel];
        doc["expected_feature"] = pgl::gld::GLD_DATASET_CANONICAL_FEATURE_ORDER[channel];
        doc["actual_feature"] = sample.feature != nullptr ? sample.feature : "null";
        doc["sensor_status"] = sample.status;
        doc["gain"] = sample.gain;
        doc["saturated"] = sample.saturated;
        doc["finite"] = std::isfinite(sample.voltage);
    }
    char buf[512];
    serializeJson(doc, buf, sizeof(buf));
    mqtt.publish(topicStatus, buf, false);
}

void publishDatasetSummary() {
    StaticJsonDocument<384> doc;
    doc["device_id"] = runtimeConfig.deviceId;
    doc["stage"] = "DATASET";
    doc["label"] = currentLabel;
    doc["total_samples"] = datasetSeq;
    doc["duration_ms"] = static_cast<uint32_t>(millis() - sessionStartMs);
    doc["nulling_profile_id"] = nullingProfileId;
    doc["queue_pending"] = datasetQueueCount;
    doc["queue_dropped"] = datasetQueueDropped;
    doc["publish_fail_count"] = datasetPublishFailCount;
    doc["rejected_samples"] = datasetRejectedSamples;
    doc["last_reject_reason"] =
        pgl::gld::gldDatasetRejectReasonName(lastDatasetRejectReason);
    doc["last_reject_channel"] = static_cast<int>(lastDatasetRejectChannel);
    char buf[384];
    serializeJson(doc, buf, sizeof(buf));
    mqtt.publish(topicSummary, buf, false);
}

// ---------------------------------------------------------------------------
// MQTT callback — handles SET_MODE (all), dataset commands (dataset mode)
// ---------------------------------------------------------------------------

void handleCmdTopic(const char* payload, unsigned int length) {
    StaticJsonDocument<256> doc;
    if (deserializeJson(doc, payload, length)) return;
    const char* cmd = doc["cmd"] | "";
    if (strcmp(cmd, "SET_MODE") == 0) {
        const char* modeStr = doc["mode"] | "";
        publishCmdAck("SET_MODE", "ok");
        onModeCmd(pgl::gld::gldModeFromString(modeStr));
    }
}

void handleDatasetTopic(const char* payload, unsigned int length) {
    StaticJsonDocument<512> doc;
    if (deserializeJson(doc, payload, length)) {
        publishCmdAck("UNKNOWN", "parse_error");
        return;
    }
    const char* cmd = doc["cmd"] | "";
    if (strcmp(cmd, "SET_MODE") == 0) {
        const char* modeStr = doc["mode"] | "";
        publishCmdAck("SET_MODE", "ok");
        onModeCmd(pgl::gld::gldModeFromString(modeStr));
        return;
    }
    if (strcmp(cmd, "START_DATASET") == 0) {
        if (nullingProfileId == 0 || !nullingProfileApplied) {
            publishCmdAck("START_DATASET", "reject_no_profile");
            return;
        }
        const char* label = doc["label"] | "unknown";
        strncpy(currentLabel, label, sizeof(currentLabel) - 1);
        currentLabel[sizeof(currentLabel) - 1] = '\0';
        targetSamples    = doc["target_samples"]     | 0u;
        const uint32_t requestedSampleIntervalMs =
            doc["sample_interval_ms"] | DATASET_MIN_SAMPLE_INTERVAL_MS;
        sampleIntervalMs = requestedSampleIntervalMs < DATASET_MIN_SAMPLE_INTERVAL_MS
                               ? DATASET_MIN_SAMPLE_INTERVAL_MS
                               : requestedSampleIntervalMs;
        maxDurationMs    = doc["max_duration_ms"]    | 0u;
        useFanIntake     = pgl::gld::board::HAS_DC_FAN &&
                           (doc["use_fan_intake"] | true);
        fanOnMs          = pgl::gld::board::HAS_DC_FAN
                               ? (doc["fan_on_ms"] | 1000u)
                               : 0u;
        postFanSettleMs  = doc["post_fan_settle_ms"] | 0u;
        datasetSeq     = 0;
        datasetRejectedSamples = 0;
        lastDatasetRejectReason = pgl::gld::GldDatasetRejectReason::None;
        lastDatasetRejectChannel = -1;
        lastDatasetRejectOkFiniteCount = 0;
        lastDatasetRejectStatus = 0xFF;
        lastDatasetRejectGain = 0;
        lastDatasetRejectSaturated = false;
        sessionStartMs = millis();
        lastScanMs     = sessionStartMs;
        sampleStep     = SampleStep::None;
        datasetState   = DatasetState::Running;
        optionalDigitalWrite(pgl::gld::board::PIN_STATUS_LED, ACTIVE_LOW_OUTPUT_ON);
        publishCmdAck("START_DATASET", "ok");
        publishDatasetStatus("running", currentLabel);
        logPrintf("DATASET_START label=%s target=%lu interval=%lu\n",
                  currentLabel,
                  static_cast<unsigned long>(targetSamples),
                  static_cast<unsigned long>(sampleIntervalMs));
    } else if (strcmp(cmd, "STOP_DATASET") == 0) {
        if (datasetState == DatasetState::Running)
            optionalDigitalWrite(pgl::gld::board::PIN_DC_FAN, LOW);
        datasetState = DatasetState::Idle;
        sampleStep   = SampleStep::None;
        optionalDigitalWrite(pgl::gld::board::PIN_STATUS_LED, ACTIVE_LOW_OUTPUT_OFF);
        publishCmdAck("STOP_DATASET", "ok");
        publishDatasetSummary();
        publishDatasetStatus("idle", "stopped");
        logPrintf("DATASET_STOP totalSeq=%lu\n", static_cast<unsigned long>(datasetSeq));
    } else {
        publishCmdAck(cmd, "unknown_cmd");
    }
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
    if (strcmp(topic, topicCmd) == 0) {
        handleCmdTopic(reinterpret_cast<const char*>(payload), length);
    } else if (strcmp(topic, topicDataset) == 0) {
        handleDatasetTopic(reinterpret_cast<const char*>(payload), length);
    }
}

// ---------------------------------------------------------------------------
// Nulling helpers
// ---------------------------------------------------------------------------

void armNullingRetry(const char* reason);
const char* nullingRetryReason(pgl::gld::GldNullingStatus status);
void rememberIncompleteNullingResult(const pgl::gld::GldNullingServiceResult& result);

bool initNulling(bool runIfMissing) {
    nullingProfileApplied = false;
    pgl::gld::GldNullingProfile profile{};
    if (pgl::gld::loadNullingProfile(profile)) {
        logPrintf("NULLING_NVS_LOAD=found profileId=%u\n", profile.profileId);
        bool allApplied = true;
        for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
            allApplied = dac.writeDac(ch, profile.dacCode[ch]) && allApplied;
        }
        if (!allApplied) {
            nullingProfileId = 0;
            (void)dac.writeAll(0);
            logPrintln("NULLING_NVS_APPLY=FAIL safeReset=1");
            return false;
        }
        nullingProfileId = profile.profileId;
        nullingProfileApplied = true;
        return true;
    }
    if (!runIfMissing) {
        nullingProfileId = 0;
        logPrintln("NULLING_NVS_LOAD=empty auto_nulling=skip");
        return false;
    }
    logPrintln("NULLING_NVS_LOAD=empty running_nulling_now");
    if (!ensureNullingSensorPowerReady("init_nulling")) {
        logPrintln("NULLING_RUN=BLOCKED reason=sensor_power_not_ready");
        armNullingRetry("sensor_power_not_ready");
        return false;
    }
    if (!runNullingMcpWritePreflight("init_nulling")) {
        logPrintln("NULLING_RUN=BLOCKED reason=mcp_preflight_failed");
        armNullingRetry("mcp_preflight_failed");
        return false;
    }
    const pgl::gld::GldNullingServiceResult result =
        runNullingServiceWithMcpIsolation();
    logPrintf("NULLING_RUN status=%s successCount=%u\n",
              pgl::gld::gldNullingStatusName(result.status), result.successCount);
    if (result.status != pgl::gld::GldNullingStatus::Ok ||
        result.successCount != pgl::gld::board::SENSOR_COUNT) {
        rememberIncompleteNullingResult(result);
        armNullingRetry(nullingRetryReason(result.status));
        return false;
    }
    pgl::gld::GldNullingProfile toSave = result.profile;
    toSave.validMagic = pgl::gld::NULLING_PROFILE_VALID_MAGIC;
    toSave.profileId  = 1;
    if (!pgl::gld::isNullingProfileValid(toSave)) {
        return false;
    }
    if (!pgl::gld::saveNullingProfile(toSave)) {
        return false;
    }
    bool allApplied = true;
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        allApplied = dac.writeDac(ch, toSave.dacCode[ch]) && allApplied;
    }
    if (!allApplied) {
        nullingProfileId = 0;
        (void)dac.writeAll(0);
        return false;
    }
    nullingProfileId = toSave.profileId;
    nullingProfileApplied = true;
    return true;
}

const char* nullingRetryReason(pgl::gld::GldNullingStatus status) {
    switch (status) {
        case pgl::gld::GldNullingStatus::AdsNotReady:       return "ads_not_ready";
        case pgl::gld::GldNullingStatus::DacNotReady:       return "dac_not_ready";
        case pgl::gld::GldNullingStatus::AllChannelsFailed: return "all_channels_failed";
        case pgl::gld::GldNullingStatus::PartialSuccess:    return "partial_success";
        case pgl::gld::GldNullingStatus::Ok:                return "none";
    }
    return "unknown";
}

void armNullingRetry(const char* reason) {
    nullDone = false;
    nullingRetryArmed = false;
    nullingRetryAvailable = true;
    nullingRetryFailedAvailable = pendingNullingFailedMask() != 0u;
    nextNullingRetryMs = 0;
    logPrintf("NULLING_RETRY_REQUIRED reason=%s action=operator_retry\n", reason);
    emitStatusJson();
}

void requestNullingRetryFromSerialCommand(bool failedOnly) {
    const char* commandName = failedOnly ? "RETRY_FAILED_NULLING" : "RETRY_NULLING";
    if (currentMode != pgl::gld::GldMode::NULLING) {
        emitCommandAck(commandName, "rejected", "retry is available only in nulling mode", false);
        return;
    }
    if (!nullingRetryAvailable) {
        emitCommandAck(commandName, "rejected", "no failed nulling run is waiting for retry", false);
        return;
    }
    if (failedOnly && !nullingRetryFailedAvailable) {
        emitCommandAck(commandName, "rejected", "no failed channels are available for targeted retry", false);
        return;
    }
    nullingRetryAvailable = false;
    nullingRetryFailedAvailable = false;
    nullingRetryArmed = true;
    nullingRetryChannelMask = failedOnly ? pendingNullingFailedMask() : 0xFFu;
    nextNullingRetryMs = millis();
    logPrintf("NULLING_RETRY_ACCEPTED attempt=%u policy=%s channelMask=0x%02X\n",
              static_cast<unsigned>(nullingAttemptCount + 1U), failedOnly ? "failed_only" : "all",
              static_cast<unsigned>(nullingRetryChannelMask));
    emitCommandAck(commandName, "ok", failedOnly ? "failed-channel nulling retry queued" : "full nulling retry queued", false);
    emitStatusJson();
}


bool ensureNullingHardwareReady() {
    if (!adsReady) {
        adsReady = ads.begin(gldSpi);
        logPrintf("NULLING_ADS_REBEGIN=%s\n", passFail(adsReady));
    }
    if (!dacReady) {
        dacReady = dac.begin(Wire, &pcf8574);
        logPrintf("NULLING_DAC_REBEGIN=%s\n", passFail(dacReady));
    }
    return adsReady && dacReady;
}

bool saveCompleteNullingProfile(const pgl::gld::GldNullingServiceResult& result,
                                pgl::gld::GldNullingProfile& toSave) {
    if (result.status != pgl::gld::GldNullingStatus::Ok ||
        result.successCount != pgl::gld::board::SENSOR_COUNT) {
        return false;
    }

    pgl::gld::GldNullingProfile existing{};
    pgl::gld::loadNullingProfile(existing);
    if (pgl::gld::isNullingProfileValid(existing) && existing.profileId == UINT8_MAX) {
        logPrintln("NULLING_NVS_SAVE=FAIL reason=profile_id_exhausted");
        return false;
    }
    toSave = result.profile;
    toSave.validMagic = pgl::gld::NULLING_PROFILE_VALID_MAGIC;
    toSave.profileId  = static_cast<uint8_t>(
        pgl::gld::isNullingProfileValid(existing)
            ? static_cast<uint8_t>(existing.profileId + 1u) : 1u);
    if (!pgl::gld::isNullingProfileValid(toSave)) {
        logPrintln("NULLING_NVS_SAVE=FAIL reason=profile_validation");
        return false;
    }
    const bool saved = pgl::gld::saveNullingProfile(toSave);
    logPrintf("NULLING_NVS_SAVE=%s profileId=%u\n",
              saved ? "OK" : "FAIL", toSave.profileId);
    if (saved) {
        nullingProfileId = toSave.profileId;
    }
    return saved;
}

void rememberIncompleteNullingResult(const pgl::gld::GldNullingServiceResult& result) {
    pendingNullingResult = result;
    pendingNullingResultValid = true;
}

pgl::gld::GldNullingServiceResult mergeFailedOnlyRetry(
    const pgl::gld::GldNullingServiceResult& retryResult, uint8_t retryMask) {
    if (!pendingNullingResultValid) return retryResult;
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        if ((retryMask & static_cast<uint8_t>(1u << ch)) == 0u) continue;
        pendingNullingResult.profile.dacCode[ch] = retryResult.profile.dacCode[ch];
        pendingNullingResult.profile.baselineV[ch] = retryResult.profile.baselineV[ch];
        pendingNullingResult.profile.afterV[ch] = retryResult.profile.afterV[ch];
        pendingNullingResult.profile.channelOk[ch] = retryResult.profile.channelOk[ch];
    }
    uint8_t successes = 0u;
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        if (pendingNullingResult.profile.channelOk[ch] != 0u) ++successes;
    }
    pendingNullingResult.successCount = successes;
    pendingNullingResult.attemptedCount = pgl::gld::board::SENSOR_COUNT;
    pendingNullingResult.status = successes == pgl::gld::board::SENSOR_COUNT
        ? pgl::gld::GldNullingStatus::Ok
        : (successes == 0u ? pgl::gld::GldNullingStatus::AllChannelsFailed
                           : pgl::gld::GldNullingStatus::PartialSuccess);
    return pendingNullingResult;
}

void returnToRunningAfterNulling(const pgl::gld::GldNullingProfile& profile) {
    logPrintf("NULLING_AUTO_MODE_SWITCH target=running mode=inference profileId=%u delayMs=%lu\n",
              profile.profileId,
              static_cast<unsigned long>(NULLING_AUTO_RESTART_DELAY_MS));
    if (!pgl::gld::writeGldMode(pgl::gld::GldMode::INFERENCE)) {
        logPrintln("NULLING_AUTO_MODE_SWITCH=FAIL reason=nvs_write");
        armNullingRetry("mode_persist_failed");
        return;
    }
    serviceDelay(NULLING_AUTO_RESTART_DELAY_MS);
    Serial.flush();
#if defined(ARDUINO_ARCH_ESP32)
    Serial0.flush();
#endif
    ESP.restart();
}

void runNullingRetryAttempt() {
    nullingRetryArmed = false;
    nullingRetryAvailable = false;
    ++nullingAttemptCount;
    const uint8_t retryMask = nullingRetryChannelMask;
    const bool failedOnly = retryMask != 0xFFu;
    nullingRetryChannelMask = 0xFFu;
    logPrintf("NULLING_RETRY_START attempt=%u policy=%s channelMask=0x%02X\n",
              static_cast<unsigned>(nullingAttemptCount), failedOnly ? "failed_only" : "all",
              static_cast<unsigned>(retryMask));

    if (!ensureNullingHardwareReady()) {
        logPrintf("NULLING_RETRY_BLOCKED adsReady=%u dacReady=%u\n",
                  adsReady ? 1 : 0, dacReady ? 1 : 0);
        armNullingRetry("hardware_not_ready");
        return;
    }
    if (!ensureNullingSensorPowerReady("manual_retry")) {
        logPrintln("NULLING_RUN=BLOCKED reason=sensor_power_not_ready");
        armNullingRetry("sensor_power_not_ready");
        return;
    }
    if (!runNullingMcpWritePreflight("manual_retry", retryMask)) {
        logPrintln("NULLING_RUN=BLOCKED reason=mcp_preflight_failed");
        armNullingRetry("mcp_preflight_failed");
        return;
    }

    pgl::gld::GldNullingServiceResult result =
        runNullingServiceWithMcpIsolation(retryMask);
    if (failedOnly) {
        result = mergeFailedOnlyRetry(result, retryMask);
    } else {
        rememberIncompleteNullingResult(result);
    }
    logPrintf("NULLING_RETRY_DONE status=%s successCount=%u\n",
              pgl::gld::gldNullingStatusName(result.status), result.successCount);

    pgl::gld::GldNullingProfile toSave{};
    if (saveCompleteNullingProfile(result, toSave)) {
        logPrintln("NULLING_RUNTIME_RESULT=PASS");
        nullDone = true;
        pendingNullingResultValid = false;
        returnToRunningAfterNulling(toSave);
        return;
    }

    const bool fullOk = result.status == pgl::gld::GldNullingStatus::Ok &&
                        result.successCount == pgl::gld::board::SENSOR_COUNT;
    logPrintln(result.status == pgl::gld::GldNullingStatus::PartialSuccess
               ? "NULLING_RUNTIME_RESULT=PARTIAL_RETRY"
               : "NULLING_RUNTIME_RESULT=FAIL_RETRY");
    rememberIncompleteNullingResult(result);
    armNullingRetry(fullOk ? "nvs_save_failed" : nullingRetryReason(result.status));
}

bool runtimeDacVerificationReady() {
    if (batteryPowerMode || !pgl::gld::board::HAS_PCF8574) return true;
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        if (!runtimeMcpReadbackVerified[ch]) return false;
    }
    return true;
}

void recordRuntimeDacVerification(uint8_t channel, uint16_t expected, uint16_t readback,
                                  bool readOk, const char* source, bool logPass) {
    const bool match = readOk && readback == expected;
    runtimeMcpExpected[channel] = expected;
    runtimeMcpReadback[channel] = readback;
    runtimeMcpReadbackVerified[channel] = match;
    runtimeMcpVerifiedAtMs[channel] = match ? millis() : 0;
    if (logPass || !match) {
        logPrintf("RUNTIME_DAC_VERIFY source=%s ch=%u sensor=%s expected=%u readback=%u read=%u match=%u\n",
                  source, static_cast<unsigned>(channel), pgl::gld::board::SENSOR_NAMES[channel],
                  static_cast<unsigned>(expected), static_cast<unsigned>(readback),
                  readOk ? 1u : 0u, match ? 1u : 0u);
    }
}

// Non-battery inference keeps all rails powered.  This periodic readback uses
// only the TCA selection and never changes PCF/EN or writes a DAC value.  One
// channel per interval bounds I2C traffic while making a lost/reset MCP state
// visible within a full eight-channel cycle.
void serviceNonBatteryDacVerification() {
#if PGL_GLD_BOARD_PROFILE_GLD2
    // All external-power sensor rails intentionally remain ON.  Do not make
    // a shared-address probe during inference: the reliable MCP verification
    // is the boot/profile-apply readback performed with scoped rail control.
    if (lastKnownExternalPower) return;
    if (batteryPowerMode || currentMode != pgl::gld::GldMode::INFERENCE || !dacReady || !dac.ready()) return;
    const uint32_t now = millis();
    if (now - lastNonBatteryDacVerifyMs < NON_BATTERY_DAC_VERIFY_INTERVAL_MS) return;
    lastNonBatteryDacVerifyMs = now;
    const uint8_t channel = nextNonBatteryDacVerifyChannel;
    nextNonBatteryDacVerifyChannel = static_cast<uint8_t>(
        (nextNonBatteryDacVerifyChannel + 1U) % pgl::gld::board::SENSOR_COUNT);
    uint16_t readback = 0;
    const uint16_t expected = runtimeMcpExpected[channel];
    const bool readOk = dac.readDac(channel, readback);
    recordRuntimeDacVerification(channel, expected, readback, readOk, "periodic", false);
#endif
}

bool applySavedNullingProfileOnly() {
    nullingProfileApplied = false;
    nullingProfileId = 0;
    pgl::gld::GldNullingProfile profile{};
    if (!pgl::gld::loadNullingProfile(profile)) {
#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
        // An isolated volatile zero does not survive the next rail transition:
        // MCP4725 reloads EEPROM at power-up. Persisting an arbitrary zero is
        // prohibited, so do not claim that an unisolated writeAll reset worked.
        for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
            runtimeMcpReadbackVerified[ch] = false;
            runtimeMcpVerifiedAtMs[ch] = 0;
        }
        logPrintln("BOOT_NULLING_PROFILE_APPLY=SKIP reason=no_profile dacReset=SKIP_UNSAFE_VOLATILE_NO_PERSIST");
#else
        if (dacReady) {
            const bool resetOk = dac.writeAll(0);
            serviceDelay(BOOT_DAC_SETTLE_MS);
            logPrintf("BOOT_NULLING_PROFILE_APPLY=SKIP reason=no_profile dacReset=%s\n",
                      resetOk ? "OK" : "FAIL");
        } else {
            logPrintln("BOOT_NULLING_PROFILE_APPLY=SKIP reason=no_profile");
        }
#endif
        return false;
    }

    if (!dacReady) {
        dacReady = dac.begin(Wire, &pcf8574);
        logPrintf("BOOT_NULLING_DAC_BEGIN=%s\n", passFail(dacReady));
    }
    if (!dacReady) {
        logPrintf("BOOT_NULLING_PROFILE_APPLY=SKIP profileId=%u reason=dac_not_ready\n",
                  profile.profileId);
        return false;
    }

    // The downstream MCP4725 modules share address 0x60.  Apply/verify a
    // saved profile with one TPS22919 rail at a time, but commit a differing
    // code to the MCP EEPROM so it survives the subsequent rail transition.
    // A matching EEPROM-loaded code is only read, preserving EEPROM endurance.
    const bool isolateSensorsForApply = pgl::gld::board::HAS_PCF8574 && pcfReady;
    dac.setAutomaticSensorPowerControl(isolateSensorsForApply);
    if (isolateSensorsForApply) {
        dac.captureSensorPowerState();
        dac.setSensorPowerSettleMs(500);
        dac.setRestoreSensorPowerAfterWrite(false);
    }
    bool allApplied = true;
    bool allReadBack = true;
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        uint16_t before = 0;
        const bool beforeOk = dac.readDac(ch, before);
        const bool needsCommit = !beforeOk || before != profile.dacCode[ch];
        // A matching EEPROM value needs only a volatile refresh. This updates
        // the runtime cache after Boot IC Report's edge test without another
        // EEPROM write cycle.
        const bool writeOk = needsCommit
                                 ? dac.writeDacPersistent(ch, profile.dacCode[ch])
                                 : dac.writeDac(ch, profile.dacCode[ch]);
        if (needsCommit && writeOk) serviceDelay(50);
        uint16_t readback = 0;
        const bool readOk = writeOk && dac.readDac(ch, readback);
        const bool match = readOk && readback == profile.dacCode[ch];
        recordRuntimeDacVerification(ch, profile.dacCode[ch], readback, readOk, "boot_apply", true);
        logPrintf("BOOT_NULLING_DAC_VERIFY ch=%u sensor=%s requested=%u before=%u beforeRead=%u commit=%u write=%u readback=%u read=%u match=%u\n",
                  static_cast<unsigned>(ch), pgl::gld::board::SENSOR_NAMES[ch],
                  static_cast<unsigned>(profile.dacCode[ch]), static_cast<unsigned>(before),
                  beforeOk ? 1u : 0u, needsCommit ? 1u : 0u, writeOk ? 1u : 0u,
                  static_cast<unsigned>(readback), readOk ? 1u : 0u, match ? 1u : 0u);
        allApplied = writeOk && allApplied;
        allReadBack = allReadBack && match;
    }
    serviceDelay(BOOT_DAC_SETTLE_MS);
    allApplied = allApplied && allReadBack;
    if (allApplied) {
        nullingProfileId = profile.profileId;
        nullingProfileApplied = true;
    } else {
        const bool resetOk = dac.writeAll(0);
        logPrintf("BOOT_NULLING_PROFILE_SAFE_RESET=%s\n", resetOk ? "OK" : "FAIL");
    }
    const bool powerRestored = !isolateSensorsForApply || dac.restoreSensorPower();
    dac.setAutomaticSensorPowerControl(batteryPowerMode);
    dac.setRestoreSensorPowerAfterWrite(true);
    dac.setSensorPowerSettleMs(50);
    allApplied = allApplied && powerRestored;
#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
    if (allApplied) {
        sessionMcpOverrideMask = 0;
    } else {
        // A failed final PCF restore means the saved profile is not verified
        // in the resumed power state. Keep the manual-override protection and
        // fail closed instead of exposing a transient per-rail result as ready.
        nullingProfileApplied = false;
        nullingProfileId = 0;
    }
#endif
    logPrintf("BOOT_NULLING_PROFILE_POWER_RESTORE=%s\n", powerRestored ? "OK" : "FAIL");
    logPrintf("BOOT_NULLING_PROFILE_APPLY=%s profileId=%u\n",
              allApplied ? "OK" : "FAIL",
              profile.profileId);
    // Boot emits a preliminary status before I2C and the stored DAC profile
    // are ready.  Publish another snapshot here so Operator never keeps the
    // boot-default code 0 after a verified profile apply.
    emitStatusJson();
    return allApplied;
}

void printBootSensorSnapshotRow(uint8_t rowNumber) {
    char line[256];
    size_t used = static_cast<size_t>(
        snprintf(line, sizeof(line), "%u. ", static_cast<unsigned>(rowNumber)));

    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT && used < sizeof(line); ++ch) {
        firmwareServiceTick();
        const pgl::gld::GldAds1256Reading reading = ads.readChannel(ch);
        const char* sep = (ch + 1U < pgl::gld::board::SENSOR_COUNT) ? " | " : "";
        int written = 0;
        if (reading.status == pgl::gld::GldAds1256Status::Ok) {
            written = snprintf(line + used, sizeof(line) - used,
                               "%s : %.5fV%s",
                               pgl::gld::board::SENSOR_NAMES[ch],
                               reading.voltage,
                               sep);
        } else {
            written = snprintf(line + used, sizeof(line) - used,
                               "%s : ERR(%s)%s",
                               pgl::gld::board::SENSOR_NAMES[ch],
                               pgl::gld::gldAds1256StatusName(reading.status),
                               sep);
        }
        if (written < 0) break;
        used += static_cast<size_t>(written);
    }

    logPrintln(line);
}

void runExternalPowerBootSensorSamples(const pgl::gld::GldPowerReading& power) {
    // The DAC loses its volatile register state whenever the main rail is cut.
    // Apply and verify the complete profile on every boot, including a TPL5010
    // battery wake, before any inference path can become ready.
    (void)applySavedNullingProfileOnly();
    if (!power.externalPower) {
        return;
    }

    logPrintln("[BOOT_SENSOR_SAMPLES]");
    if (!adsReady) {
        logPrintln("BOOT_SENSOR_SAMPLE_BLOCKED reason=ads_not_ready");
        return;
    }

    for (uint8_t sample = 1; sample <= BOOT_SENSOR_SNAPSHOT_COUNT; ++sample) {
        firmwareServiceTick();
        printBootSensorSnapshotRow(sample);
    }
}

void runBootCheckFromSerialCommand() {
    emitCommandAck("RUN_BOOT_CHECK", "ok", "running boot diagnostics", false);

    const pgl::gld::GldPowerReading power = pgl::gld::readGldPower();
    applyRuntimePowerReading(power, "run_boot_check", true);
    logPrintf("RUN_BOOT_CHECK_START mode=%s power=%s externalPower=%u\n",
              pgl::gld::gldModeName(currentMode),
              pgl::gld::gldPowerModeName(power.mode),
              power.externalPower ? 1 : 0);

    const BootDiagnosticsResult bootDiagnostics = runBootHardwareDiagnostics(power.externalPower,
                                                                              batteryPowerMode);

    char modeDetail[128];
    bool modeReady = false;
    bool radioChecked = false;
    bool mlChecked = false;
    bool radioOk = false;
    bool mlOk = false;
    int mlOutputSize = -1;

    if (currentMode == pgl::gld::GldMode::INFERENCE) {
        radioChecked = true;
        mlChecked = true;
        radioOk = radioReady;
        mlOk = mlReady;
        mlOutputSize = network != nullptr ? network->getOutputSize() : -1;
        modeReady = adsReady && radioReady && mlReady;
        snprintf(modeDetail, sizeof(modeDetail), "ads=%s mcp=%u/%u lora=%s ml=%s rerun=1",
                 passFail(adsReady),
                 bootDiagnostics.i2c.mcpOkCount,
                 pgl::gld::board::SENSOR_COUNT,
                 passFail(radioReady),
                 passFail(mlReady));
    } else if (currentMode == pgl::gld::GldMode::DATASET) {
        modeReady = adsReady && dacReady && nullingProfileApplied && nullingProfileId > 0;
        snprintf(modeDetail, sizeof(modeDetail), "ads=%s mcp=%u/%u dac=%s nullingProfileId=%u rerun=1",
                 passFail(adsReady),
                 bootDiagnostics.i2c.mcpOkCount,
                 pgl::gld::board::SENSOR_COUNT,
                 passFail(dacReady),
                 nullingProfileId);
    } else {
        modeReady = adsReady && dacReady;
        snprintf(modeDetail, sizeof(modeDetail), "ads=%s mcp=%u/%u dac=%s nullingRetry=%u rerun=1",
                 passFail(adsReady),
                 bootDiagnostics.i2c.mcpOkCount,
                 pgl::gld::board::SENSOR_COUNT,
                 passFail(dacReady),
                 nullingRetryArmed ? 1 : 0);
    }

    printBootIcReport(power, bootDiagnostics.ads, bootDiagnostics.i2c, bootDiagnostics.mcpControl,
                      radioChecked, radioOk,
                      mlChecked, mlOk, mlOutputSize,
                      modeReady,
                      modeDetail);
    runExternalPowerBootSensorSamples(power);
    if (!batteryPowerMode) {
        enableNonBatteryRuntimeSensorPower("run_boot_check_after_report");
    }
    emitStatusJson();
    logPrintln("RUN_BOOT_CHECK_DONE");
}

void runCurrentStateCheckFromSerialCommand() {
    emitCommandAck("RUN_CURRENT_STATE_CHECK", "ok", "checking current state without changing sensor power", false);

    const pgl::gld::GldPowerReading power = pgl::gld::readGldPower();
    applyRuntimePowerReading(power, "run_current_state_check", true);
    logPrintf("RUN_CURRENT_STATE_CHECK_START mode=%s power=%s externalPower=%u pcfOutputs=0x%02X\n",
              pgl::gld::gldModeName(currentMode), pgl::gld::gldPowerModeName(power.mode),
              power.externalPower ? 1u : 0u, pcfReady ? pcf8574.outputs() : 0u);

    adsReady = ads.begin(gldSpi);
    const BootAdsReport adsReport = probeBootAds(adsReady);
    // This command is deliberately observational and bounded.  A full root
    // scan on 0x03..0x77 can exceed the normal serial timeout on an I2C retry,
    // so only probe the required root addresses and currently powered branches.
    const BootI2cReport i2cReport = probeCurrentStateI2c(false);

    lastBootAdsDrdyLevel = adsReport.drdyLevel;
    lastBootAdsDrdyPulldownLevel = adsReport.drdyPulldownLevel;
    lastBootAdsDrdyPullupLevel = adsReport.drdyPullupLevel;
    lastBootAdsMisoPulldownLevel = adsReport.misoPulldownLevel;
    lastBootAdsMisoPullupLevel = adsReport.misoPullupLevel;
    lastBootAdsCsLevel = adsReport.csLevel;
    lastBootAdsSyncLevel = adsReport.syncLevel;
    lastBootAdsStatus = adsReport.status;
    lastBootAdsMux = adsReport.mux;
    lastBootAdsAdcon = adsReport.adcon;
    lastBootAdsDrate = adsReport.drate;
    lastBootAdsReason = adsReport.reason;
#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
    // All-on/current-mask probing is observational. It is not equivalent to
    // the isolated one-rail functional result and must not overwrite the
    // authoritative boot report retained in GET_STATUS.
    logPrintf("RUN_CURRENT_STATE_CHECK_SCOPE=observational currentMask=0x%02X "
              "isolatedFunctional=not_tested observedMcp=%u/%u authoritativeBootMcp=%u/%u\n",
              pcfReady ? pcf8574.outputs() : 0u,
              i2cReport.mcpOkCount, pgl::gld::board::SENSOR_COUNT,
              lastBootMcpOkCount, pgl::gld::board::SENSOR_COUNT);
#else
    lastBootTcaOk = i2cReport.tcaOk;
    lastBootMcpOkCount = i2cReport.mcpOkCount;
    for (uint8_t sensor = 0; sensor < pgl::gld::board::SENSOR_COUNT; ++sensor) {
        lastBootMcpOk[sensor] = i2cReport.mcpOk[sensor];
        lastBootMcpAddrMask[sensor] = i2cReport.mcpAddrMask[sensor];
    }
#endif

    logPrintf("RUN_CURRENT_STATE_CHECK_I2C tcaOk=%u pcfOk=%u mcpOkCount=%u/%u pcfOutputs=0x%02X\n",
              i2cReport.tcaOk ? 1u : 0u, i2cReport.pcfOk ? 1u : 0u,
              i2cReport.mcpOkCount, pgl::gld::board::SENSOR_COUNT,
              pcfReady ? pcf8574.outputs() : 0u);
    emitStatusJson();
    logPrintln("RUN_CURRENT_STATE_CHECK_DONE no_sensor_power_or_dac_write=1");
}

void runI2cScanFromSerialCommand() {
    emitCommandAck("RUN_I2C_SCAN", "ok", "running manual I2C scan", false);

    Wire.begin(pgl::gld::board::PIN_I2C_SDA, pgl::gld::board::PIN_I2C_SCL);
#if defined(ARDUINO_ARCH_ESP32)
    Wire.setTimeOut(BOOT_I2C_TIMEOUT_MS);
#endif

    char addresses[80]{};
    size_t used = 0;
    uint8_t count = 0;
    for (uint8_t addr = 0x03; addr <= 0x77; ++addr) {
        if (!i2cAck(addr)) continue;
        ++count;
        const int written = snprintf(addresses + used, sizeof(addresses) - used,
                                     "%s0x%02X", used == 0 ? "" : ",", addr);
        if (written < 0 || static_cast<size_t>(written) >= sizeof(addresses) - used) {
            copyBounded(addresses, sizeof(addresses), "truncated");
            break;
        }
        used += static_cast<size_t>(written);
    }
    if (count == 0) copyBounded(addresses, sizeof(addresses), "none");
    logPrintf("I2C_MANUAL_SCAN range=0x03-0x77 count=%u addrs=%s\n",
              static_cast<unsigned>(count), addresses);
    emitCommandAck("RUN_I2C_SCAN", "ok", addresses, false);
}

void runTcaChannelScanFromSerialCommand() {
    emitCommandAck("RUN_TCA_CHANNEL_SCAN", "ok", "scanning MCP addresses on TCA channels", false);

    Wire.begin(pgl::gld::board::PIN_I2C_SDA, pgl::gld::board::PIN_I2C_SCL);
#if defined(ARDUINO_ARCH_ESP32)
    Wire.setTimeOut(BOOT_I2C_TIMEOUT_MS);
#endif

    if (!i2cAck(pgl::gld::board::TCA9548A_ADDR)) {
        emitCommandAck("RUN_TCA_CHANNEL_SCAN", "error", "TCA9548A 0x71 did not ACK", false);
        return;
    }

    // Preserve the operator-commanded sensor-power state. In particular, a
    // GLD2 that boots with every module OFF must remain OFF after this scan.
    const uint8_t originalPcfOutputs = pcf8574.outputs();
    const uint8_t testPatterns[] = {0xFF, 0x00};
    for (const uint8_t outputs : testPatterns) {
        const bool pcfWriteOk = pcf8574.writeOutputs(outputs);
        delay(25);
        for (uint8_t muxChannel = 0; muxChannel < 8; ++muxChannel) {
            const bool selected = tcaSelect(muxChannel);
            char addresses[80]{};
            size_t used = 0;
            uint8_t count = 0;
            if (selected) {
                for (uint8_t addr = pgl::gld::board::MCP4725_ADDR;
                     addr < static_cast<uint8_t>(pgl::gld::board::MCP4725_ADDR + 8U);
                     ++addr) {
                    if (!i2cAck(addr)) continue;
                    ++count;
                    const int written = snprintf(addresses + used, sizeof(addresses) - used,
                                                 "%s0x%02X", used == 0 ? "" : ",", addr);
                    if (written < 0 || static_cast<size_t>(written) >= sizeof(addresses) - used) {
                        copyBounded(addresses, sizeof(addresses), "truncated");
                        break;
                    }
                    used += static_cast<size_t>(written);
                }
            }
            if (count == 0) copyBounded(addresses, sizeof(addresses), "none");
            logPrintf("TCA_MCP_SCAN pcf=0x%02X pcfWrite=%u mux=%u selected=%u range=0x60-0x67 count=%u addrs=%s\n",
                      outputs, pcfWriteOk ? 1u : 0u, static_cast<unsigned>(muxChannel),
                      selected ? 1u : 0u, static_cast<unsigned>(count), addresses);
        }
    }
    tcaDisableAll();
    const bool restored = pcf8574.writeOutputs(originalPcfOutputs);
    pcfAllLoadSwitchesOn = restored &&
                            originalPcfOutputs == pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_ON;
    logPrintf("TCA_MCP_SCAN restorePcf=0x%02X restoreOk=%u\n",
              pcf8574.outputs(), restored ? 1u : 0u);
    emitCommandAck("RUN_TCA_CHANNEL_SCAN", "ok", "complete; see TCA_CHANNEL_SCAN lines", false);
}

struct DiagnosticAdsAverage {
    pgl::gld::GldAds1256Status status = pgl::gld::GldAds1256Status::NotReady;
    int32_t raw = 0;
    float voltage = 0.0f;
    uint8_t gain = 0;
};

DiagnosticAdsAverage readDiagnosticAverage(uint8_t ch) {
    DiagnosticAdsAverage out{};
    float voltageSum = 0.0f;
    int64_t rawSum = 0;
    bool ok = true;
    pgl::gld::GldAds1256Status lastStatus = pgl::gld::GldAds1256Status::Ok;
#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
    pgl::gld::GldAds1256Status firstFailure = pgl::gld::GldAds1256Status::Ok;
#endif
    uint8_t lastGain = 0;

    for (uint8_t sample = 0; sample < DIAG_SWEEP_SAMPLE_COUNT; ++sample) {
        firmwareServiceTick();
        const pgl::gld::GldAds1256Reading reading = ads.readChannel(ch);
        lastStatus = reading.status;
        lastGain = reading.gain;
        if (reading.status != pgl::gld::GldAds1256Status::Ok) {
#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
            if (ok) firstFailure = reading.status;
#endif
            ok = false;
        }
        voltageSum += reading.voltage;
        rawSum += reading.raw;
    }
    firmwareServiceTick();

#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
    out.status = ok ? pgl::gld::GldAds1256Status::Ok : firstFailure;
#else
    out.status = ok ? pgl::gld::GldAds1256Status::Ok : lastStatus;
#endif
    out.voltage = voltageSum / static_cast<float>(DIAG_SWEEP_SAMPLE_COUNT);
    out.raw = static_cast<int32_t>(rawSum / static_cast<int64_t>(DIAG_SWEEP_SAMPLE_COUNT));
    out.gain = lastGain;
    return out;
}

void runAdsMcpSweepFromSerialCommand() {
    emitCommandAck("RUN_ADS_MCP_SWEEP", "ok", "running ADS/MCP sweep", false);

#if defined(PGL_GLD_BOARD_PROFILE_GLD3) && PGL_GLD_BOARD_PROFILE_GLD3
    const pgl::gld::GldPowerReading power = pgl::gld::readGldPower();
    const char* blockedReason = nullptr;
    uint8_t originalPcfOutputs = 0;
    bool originalPcfRead = false;
    if (currentMode != pgl::gld::GldMode::INFERENCE) {
        blockedReason = "mode_not_inference";
    } else if (!power.externalPower || batteryPowerMode) {
        blockedReason = "external_power_required";
    } else if (!pcfReady || !pgl::gld::board::HAS_PCF8574) {
        blockedReason = "pcf_not_ready";
    } else if (sessionMcpOverrideMask != 0u) {
        blockedReason = "active_session_mcp_override";
    } else {
        originalPcfRead = pcf8574.readOutputs(originalPcfOutputs);
        if (!originalPcfRead) blockedReason = "original_pcf_read_failed";
    }
    if (blockedReason != nullptr) {
        logPrintf("ADS_MCP_SWEEP_BLOCKED reason=%s mode=%s externalPower=%u batteryMode=%u "
                  "pcfReady=%u originalPcfRead=%u sessionOverrideMask=0x%02X\n",
                  blockedReason, pgl::gld::gldModeName(currentMode),
                  power.externalPower ? 1u : 0u, batteryPowerMode ? 1u : 0u,
                  pcfReady ? 1u : 0u, originalPcfRead ? 1u : 0u,
                  sessionMcpOverrideMask);
        logPrintf("ADS_MCP_SWEEP_DONE status=blocked reason=%s\n", blockedReason);
        return;
    }

    if (!adsReady) {
        adsReady = ads.begin(gldSpi);
        logPrintf("ADS_MCP_SWEEP_ADS_BEGIN=%s\n", passFail(adsReady));
    }
    if (!adsReady) {
        logPrintln("ADS_MCP_SWEEP_DONE status=blocked reason=ads_not_ready");
        return;
    }

    // readOutputs() above refreshed the PCF cache. Capture that proven live
    // mask before begin() turns every rail off for single-rail isolation.
    dac.captureSensorPowerState();
    dac.setAutomaticSensorPowerControl(true);
    dac.setRestoreSensorPowerAfterWrite(false);
    dac.setSensorPowerSettleMs(BOOT_DAC_SENSOR_POWER_SETTLE_MS);
    // begin() itself powers every rail off before initializing the mux. Clear
    // pre-diagnostic verification and samples before that first mutation so a
    // failed begin cannot leave stale status marked valid.
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        runtimeMcpReadbackVerified[ch] = false;
        runtimeMcpVerifiedAtMs[ch] = 0;
    }
    movingAvg.reset();
    latestTelemetryValid = false;
    dacReady = dac.begin(Wire, &pcf8574);
    logPrintf("ADS_MCP_SWEEP_DAC_BEGIN=%s isolation=one_active_rail originalPcf=0x%02X\n",
              passFail(dacReady), originalPcfOutputs);
    if (!dacReady) {
        const bool restoreWrite = dac.restoreSensorPower() ||
                                  pcf8574.writeOutputs(originalPcfOutputs);
        tcaDisableAll();
        uint8_t livePcf = pcf8574.outputs();
        const bool liveRead = pcf8574.readOutputs(livePcf);
        dac.setAutomaticSensorPowerControl(batteryPowerMode);
        dac.setRestoreSensorPowerAfterWrite(true);
        dac.setSensorPowerSettleMs(NORMAL_DAC_SENSOR_POWER_SETTLE_MS);
        pcfAllLoadSwitchesOn = liveRead &&
            livePcf == pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_ON;
        logPrintf("ADS_MCP_SWEEP_DONE status=blocked reason=dac_not_ready finalPcf=0x%02X "
                  "restoreWrite=%u finalPcfRead=%u restoreMatch=%u "
                  "runtimeVerification=invalidated\n",
                  livePcf, restoreWrite ? 1u : 0u, liveRead ? 1u : 0u,
                  (restoreWrite && liveRead && livePcf == originalPcfOutputs) ? 1u : 0u);
        return;
    }

    pgl::gld::GldNullingProfile profile{};
    const bool profileLoaded = pgl::gld::loadNullingProfile(profile);
    uint16_t baseline[pgl::gld::board::SENSOR_COUNT]{};
    bool baselineValid[pgl::gld::board::SENSOR_COUNT]{};
    bool allDacPass = true;
    bool allAdsPass = true;
    uint8_t passCount = 0;
    logPrintf("ADS_MCP_SWEEP_START codeLow=%u codeHigh=%u samples=%u settleMs=%lu "
              "isolation=one_active_rail baselineScope=isolated_power_on profileLoaded=%u "
              "originalPcf=0x%02X persistentWrites=0\n",
              static_cast<unsigned>(DIAG_SWEEP_DAC_CODE_LOW),
              static_cast<unsigned>(DIAG_SWEEP_DAC_CODE_HIGH),
              static_cast<unsigned>(DIAG_SWEEP_SAMPLE_COUNT),
              static_cast<unsigned long>(DIAG_SWEEP_SETTLE_MS),
              profileLoaded ? 1u : 0u, originalPcfOutputs);

    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        firmwareServiceTick();
        const uint8_t adsInput = pgl::gld::board::SENSOR_TO_ADS_CH[ch];
        const uint8_t muxChannel = pgl::gld::board::SENSOR_TO_MUX_CH[ch];

        baselineValid[ch] = dac.readDac(ch, baseline[ch]);
        const bool writeLow = baselineValid[ch] && dac.writeDac(ch, DIAG_SWEEP_DAC_CODE_LOW);
        uint16_t lowReadback = 0;
        const bool lowRead = writeLow && dac.readDac(ch, lowReadback);
        const bool lowMatch = lowRead && lowReadback == DIAG_SWEEP_DAC_CODE_LOW;
        serviceDelay(DIAG_SWEEP_SETTLE_MS);
        const DiagnosticAdsAverage low = lowMatch ? readDiagnosticAverage(ch) : DiagnosticAdsAverage{};

        const bool writeHigh = baselineValid[ch] && dac.writeDac(ch, DIAG_SWEEP_DAC_CODE_HIGH);
        uint16_t highReadback = 0;
        const bool highRead = writeHigh && dac.readDac(ch, highReadback);
        const bool highMatch = highRead && highReadback == DIAG_SWEEP_DAC_CODE_HIGH;
        serviceDelay(DIAG_SWEEP_SETTLE_MS);
        const DiagnosticAdsAverage high = highMatch ? readDiagnosticAverage(ch) : DiagnosticAdsAverage{};

        const bool restoreWrite = baselineValid[ch] && dac.writeDac(ch, baseline[ch]);
        uint16_t restoreReadback = 0;
        const bool restoreRead = restoreWrite && dac.readDac(ch, restoreReadback);
        const bool restoreMatch = restoreRead && restoreReadback == baseline[ch];
        serviceDelay(BOOT_DAC_SETTLE_MS);

        const bool dacPass = baselineValid[ch] && lowMatch && highMatch && restoreMatch;
        const bool adsPass = low.status == pgl::gld::GldAds1256Status::Ok &&
                             high.status == pgl::gld::GldAds1256Status::Ok;
        const bool channelPass = dacPass && adsPass;
        if (channelPass) ++passCount;
        allDacPass = allDacPass && dacPass;
        allAdsPass = allAdsPass && adsPass;
        const float delta = high.voltage - low.voltage;

        logPrintf("ADS_MCP_SWEEP_RESULT ch=%u sensor=%s ads=%u mux=%u "
                  "v0=%.9f v4000=%.9f delta=%.9f st0=%s st4000=%s ok=%u\n",
                  static_cast<unsigned>(ch), pgl::gld::board::SENSOR_NAMES[ch],
                  static_cast<unsigned>(adsInput), static_cast<unsigned>(muxChannel),
                  low.voltage, high.voltage, delta,
                  pgl::gld::gldAds1256StatusName(low.status),
                  pgl::gld::gldAds1256StatusName(high.status), channelPass ? 1u : 0u);
        logPrintf("ADS_MCP_SWEEP_DETAIL ch=%u baselineScope=isolated_power_on baseline=%u "
                  "baselineRead=%u code0=%u write0=%u read0=%u readback0=%u match0=%u "
                  "code4000=%u write4000=%u read4000=%u readback4000=%u match4000=%u "
                  "persistentWrite=0\n",
                  static_cast<unsigned>(ch), static_cast<unsigned>(baseline[ch]),
                  baselineValid[ch] ? 1u : 0u,
                  static_cast<unsigned>(DIAG_SWEEP_DAC_CODE_LOW), writeLow ? 1u : 0u,
                  lowRead ? 1u : 0u, static_cast<unsigned>(lowReadback), lowMatch ? 1u : 0u,
                  static_cast<unsigned>(DIAG_SWEEP_DAC_CODE_HIGH), writeHigh ? 1u : 0u,
                  highRead ? 1u : 0u, static_cast<unsigned>(highReadback), highMatch ? 1u : 0u);
        logPrintf("ADS_MCP_SWEEP_RESTORE_CHANNEL ch=%u restoreWrite=%u restoreRead=%u "
                  "restoreReadback=%u restoreMatch=%u raw0=%ld raw4000=%ld "
                  "gain0=%u gain4000=%u\n",
                  static_cast<unsigned>(ch),
                  restoreWrite ? 1u : 0u, restoreRead ? 1u : 0u,
                  static_cast<unsigned>(restoreReadback), restoreMatch ? 1u : 0u,
                  static_cast<long>(low.raw), static_cast<long>(high.raw),
                  static_cast<unsigned>(low.gain), static_cast<unsigned>(high.gain));
    }

    tcaDisableAll();
    // Deselect the downstream branch before the rail transition so restoring
    // the root power mask does not retain a potentially disturbed powered
    // branch selected by the last diagnostic transaction.
    const bool restoreWrite = dac.restoreSensorPower();
    uint8_t finalPcfOutputs = pcf8574.outputs();
    const bool finalPcfRead = pcf8574.readOutputs(finalPcfOutputs);
    const bool restoreMatch = restoreWrite && finalPcfRead &&
                              finalPcfOutputs == originalPcfOutputs;
    pcfAllLoadSwitchesOn = finalPcfRead &&
        finalPcfOutputs == pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_ON;
    dac.setAutomaticSensorPowerControl(batteryPowerMode);
    dac.setRestoreSensorPowerAfterWrite(true);
    dac.setSensorPowerSettleMs(NORMAL_DAC_SENSOR_POWER_SETTLE_MS);
    dacReady = allDacPass && restoreMatch;

    // Restoring the PCF mask can power-cycle rails after their per-channel
    // readback. Do not present those earlier reads as current verification.
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        runtimeMcpReadbackVerified[ch] = false;
        runtimeMcpVerifiedAtMs[ch] = 0;
    }
    const bool pass = allDacPass && allAdsPass && restoreMatch &&
                      passCount == pgl::gld::board::SENSOR_COUNT;
    logPrintf("ADS_MCP_SWEEP_RESTORE originalPcf=0x%02X finalPcf=0x%02X "
              "restoreWrite=%u finalRead=%u restoreMatch=%u runtimeVerification=invalidated "
              "recovery=RUN_BOOT_CHECK\n",
              originalPcfOutputs, finalPcfOutputs, restoreWrite ? 1u : 0u,
              finalPcfRead ? 1u : 0u, restoreMatch ? 1u : 0u);
    logPrintf("ADS_MCP_SWEEP_DONE status=%s executionPassCount=%u/%u dacPass=%u adsSamplesValid=%u "
              "powerRestore=%u scope=dac_readback_and_ads_sampling analogResponse=not_graded "
              "analogThreshold=not_defined\n",
              pass ? "pass" : "fail", passCount, pgl::gld::board::SENSOR_COUNT,
              allDacPass ? 1u : 0u, allAdsPass ? 1u : 0u, restoreMatch ? 1u : 0u);
#else
    if (!adsReady) {
        adsReady = ads.begin(gldSpi);
        logPrintf("ADS_MCP_SWEEP_ADS_BEGIN=%s\n", passFail(adsReady));
    }
    if (!dacReady) {
        dacReady = dac.begin(Wire, &pcf8574);
        logPrintf("ADS_MCP_SWEEP_DAC_BEGIN=%s\n", passFail(dacReady));
    }

    if (!adsReady || !dacReady) {
        logPrintf("ADS_MCP_SWEEP_BLOCKED adsReady=%u dacReady=%u\n",
                  adsReady ? 1 : 0, dacReady ? 1 : 0);
        logPrintln("ADS_MCP_SWEEP_DONE status=blocked");
        return;
    }

    pgl::gld::GldNullingProfile profile{};
    const bool profileLoaded = pgl::gld::loadNullingProfile(profile);
    logPrintf("ADS_MCP_SWEEP_START codeLow=%u codeHigh=%u samples=%u settleMs=%lu restore=%s\n",
              static_cast<unsigned>(DIAG_SWEEP_DAC_CODE_LOW),
              static_cast<unsigned>(DIAG_SWEEP_DAC_CODE_HIGH),
              static_cast<unsigned>(DIAG_SWEEP_SAMPLE_COUNT),
              static_cast<unsigned long>(DIAG_SWEEP_SETTLE_MS),
              profileLoaded ? "profile" : "zero");

    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        firmwareServiceTick();
        const uint8_t adsInput = pgl::gld::board::SENSOR_TO_ADS_CH[ch];
        const uint8_t muxChannel = pgl::gld::board::SENSOR_TO_MUX_CH[ch];

        const bool writeLow = dac.writeDac(ch, DIAG_SWEEP_DAC_CODE_LOW);
        serviceDelay(DIAG_SWEEP_SETTLE_MS);
        const DiagnosticAdsAverage low = readDiagnosticAverage(ch);

        const bool writeHigh = dac.writeDac(ch, DIAG_SWEEP_DAC_CODE_HIGH);
        serviceDelay(DIAG_SWEEP_SETTLE_MS);
        const DiagnosticAdsAverage high = readDiagnosticAverage(ch);

        const uint16_t restoreCode = profileLoaded
                                         ? profile.dacCode[ch]
                                         : DIAG_SWEEP_DAC_CODE_LOW;
        const bool restoreOk = dac.writeDac(ch, restoreCode);
        serviceDelay(BOOT_DAC_SETTLE_MS);

        const bool ok = writeLow &&
                        writeHigh &&
                        restoreOk &&
                        low.status == pgl::gld::GldAds1256Status::Ok &&
                        high.status == pgl::gld::GldAds1256Status::Ok;
        const float delta = high.voltage - low.voltage;

        logPrintf("ADS_MCP_SWEEP_RESULT ch=%u sensor=%s ads=%u mux=%u "
                  "v0=%.9f v4000=%.9f delta=%.9f st0=%s st4000=%s ok=%u\n",
                  static_cast<unsigned>(ch),
                  pgl::gld::board::SENSOR_NAMES[ch],
                  static_cast<unsigned>(adsInput),
                  static_cast<unsigned>(muxChannel),
                  low.voltage,
                  high.voltage,
                  delta,
                  pgl::gld::gldAds1256StatusName(low.status),
                  pgl::gld::gldAds1256StatusName(high.status),
                  ok ? 1 : 0);
        logPrintf("ADS_MCP_SWEEP_DETAIL ch=%u code0=%u code4000=%u write0=%u write4000=%u "
                  "raw0=%ld raw4000=%ld gain0=%u gain4000=%u restoreCode=%u restoreOk=%u\n",
                  static_cast<unsigned>(ch),
                  static_cast<unsigned>(DIAG_SWEEP_DAC_CODE_LOW),
                  static_cast<unsigned>(DIAG_SWEEP_DAC_CODE_HIGH),
                  writeLow ? 1 : 0,
                  writeHigh ? 1 : 0,
                  static_cast<long>(low.raw),
                  static_cast<long>(high.raw),
                  static_cast<unsigned>(low.gain),
                  static_cast<unsigned>(high.gain),
                  static_cast<unsigned>(restoreCode),
                  restoreOk ? 1 : 0);
    }

    logPrintln("ADS_MCP_SWEEP_DONE status=ok");
#endif
}

// ---------------------------------------------------------------------------
// LoRa (inference mode)
// ---------------------------------------------------------------------------

void onLoRaRxDone() { loraRxFlag = true; }

bool beginLoraRadio() {
    if (!loraModule) {
        loraModule = new Module(
            pgl::gld::board::PIN_LORA_CS, pgl::gld::board::PIN_LORA_DIO1,
            pgl::gld::board::PIN_LORA_RST, pgl::gld::board::PIN_LORA_BUSY,
            gldSpi);
    }
    if (!loraRadio) loraRadio = new SX1262(loraModule);
    if (radioReady) {
        loraRadio->standby();
    }
    logPrintf("GLD_STAR_CONFIG freqMHz=%.3f bwKHz=%.2f sf=%u cr=%u sync=0x%02X power=%d preamble=%u tcxo=%.1f xtal=%.1f\n",
              runtimeConfig.loraFreqMHz,
              runtimeConfig.loraBwKHz,
              runtimeConfig.loraSf,
              runtimeConfig.loraCr,
              runtimeConfig.loraSyncWord,
              runtimeConfig.loraTxPowerDbm,
              runtimeConfig.loraPreamble,
              runtimeConfig.loraTcxoVoltage,
              runtimeConfig.loraXtalVoltage);
    int16_t state = loraRadio->begin(runtimeConfig.loraFreqMHz,
                                     runtimeConfig.loraBwKHz,
                                     runtimeConfig.loraSf,
                                     runtimeConfig.loraCr,
                                     runtimeConfig.loraSyncWord,
                                     runtimeConfig.loraTxPowerDbm,
                                     runtimeConfig.loraPreamble,
                                     runtimeConfig.loraTcxoVoltage);
    if (state == RADIOLIB_ERR_SPI_CMD_FAILED) {
        state = loraRadio->begin(runtimeConfig.loraFreqMHz,
                                 runtimeConfig.loraBwKHz,
                                 runtimeConfig.loraSf,
                                 runtimeConfig.loraCr,
                                 runtimeConfig.loraSyncWord,
                                 runtimeConfig.loraTxPowerDbm,
                                 runtimeConfig.loraPreamble,
                                 runtimeConfig.loraXtalVoltage);
    }
    lastLoraBeginState = state;
    logPrintf("GLD_STAR_BEGIN_STATE=%d\n", state);
    if (state != RADIOLIB_ERR_NONE) { logPrintln("GLD_STAR_READY=0"); return false; }
    loraRadio->setRfSwitchPins(pgl::gld::board::PIN_LORA_RXEN, pgl::gld::board::PIN_LORA_TXEN);
    logPrintln("GLD_STAR_READY=1");
    return true;
}

struct NonceCtx { uint32_t counter; };

bool nonceProvider(uint8_t nonce[pgl::protocol::GLD_AES_GCM_NONCE_SIZE], void* ctx) {
    if (!ctx) return false;
    auto* nc = static_cast<NonceCtx*>(ctx);
    // Full 96-bit random nonce (esp_random() is a HW TRNG on ESP32), plus a
    // per-boot counter mixed into the last 4 bytes as defense in depth against
    // a short random collision. The leading bytes must not be a fixed
    // constant: a fixed prefix collapses effective nonce entropy and weakens
    // the AES-GCM uniqueness guarantee for every device sharing the fleet key.
    for (size_t i = 0; i < pgl::protocol::GLD_AES_GCM_NONCE_SIZE; i += 4) {
        const uint32_t r = esp_random();
        nonce[i]     = static_cast<uint8_t>((r >> 24) & 0xFF);
        nonce[i + 1] = static_cast<uint8_t>((r >> 16) & 0xFF);
        nonce[i + 2] = static_cast<uint8_t>((r >>  8) & 0xFF);
        nonce[i + 3] = static_cast<uint8_t>( r         & 0xFF);
    }
    nonce[8]  ^= static_cast<uint8_t>((nc->counter >> 24) & 0xFF);
    nonce[9]  ^= static_cast<uint8_t>((nc->counter >> 16) & 0xFF);
    nonce[10] ^= static_cast<uint8_t>((nc->counter >>  8) & 0xFF);
    nonce[11] ^= static_cast<uint8_t>( nc->counter        & 0xFF);
    ++nc->counter;
    return true;
}

void drivePhysicalAlarmOutputs(bool enabled) {
#if PGL_GLD_BOARD_PROFILE_GLD2
    // GPIO40 drives Q4's gate through R94. Q4's R41 gate pulldown means:
    // ON  = EN_BOOST HIGH, then ALARM HIGH.
    // OFF = ALARM LOW, then EN_BOOST LOW.
    if (enabled) {
        optionalDigitalWrite(pgl::gld::board::PIN_ALARM_ENABLE_BOOST, HIGH);
        optionalDigitalWrite(pgl::gld::board::PIN_ALARM_LAMP, HIGH);
    } else {
        optionalDigitalWrite(pgl::gld::board::PIN_ALARM_LAMP, LOW);
        optionalDigitalWrite(pgl::gld::board::PIN_ALARM_ENABLE_BOOST, LOW);
    }
#else
    optionalDigitalWrite(pgl::gld::board::PIN_ALARM_LAMP,
                         enabled ? ACTIVE_LOW_OUTPUT_ON : ACTIVE_LOW_OUTPUT_OFF);
    optionalDigitalWrite(pgl::gld::board::PIN_BUZZER,
                         enabled ? ACTIVE_LOW_OUTPUT_ON : ACTIVE_LOW_OUTPUT_OFF);
    optionalDigitalWrite(pgl::gld::board::PIN_STATUS_LED,
                         enabled ? ACTIVE_LOW_OUTPUT_ON : ACTIVE_LOW_OUTPUT_OFF);
#endif
    physicalAlarmCommanded = enabled;
}

void driveAlarmOutputs(bool inferenceAlarm) {
    if (FIELDTEST_MODEL_UNVERIFIED) {
        inferenceAlarm = false;
    }
    const bool requested = pgl::gld::gldPhysicalAlarmCommanded(
        alarmControlMode, inferenceAlarm, manualAlarmCommanded);
    drivePhysicalAlarmOutputs(requested);
}

bool updateAlarmOutputs(bool alarm) {
    if (FIELDTEST_MODEL_UNVERIFIED) {
        driveAlarmOutputs(false);
        logPrintf("GLD_MODEL_BENCH_ALARM_SUPPRESSED requested=%u\n", alarm ? 1 : 0);
        return true;
    }
    if (alarm == lastAlarm) {
        driveAlarmOutputs(alarm);
        return true;
    }

    const bool persisted = pgl::gld::writeGldAlarmLatched(alarm);
    if (!persisted && !alarm) {
        // Clearing must survive the imminent TPL5010 power cut. If NVS cannot
        // commit the clear state, keep the logical alarm latched and retry on
        // a later valid scan instead of reviving a stale latch next boot. AUTO
        // keeps the physical alarm on; MANUAL continues to suppress inference
        // output by explicit operator policy.
        logPrintln("GLD_ALARM_PERSIST=FAIL requested=clear failSafe=latched");
        driveAlarmOutputs(true);
        return false;
    }

    lastAlarm = alarm;
    driveAlarmOutputs(alarm);
    if (!persisted) {
        logPrintln("GLD_ALARM_PERSIST=FAIL requested=set physicalAlarm=on");
    }
    logPrintf("GLD_ALARM_OUTPUT inferenceAlarm=%u mode=%s manualCommanded=%u physicalCommanded=%u\n",
              alarm ? 1u : 0u,
              pgl::gld::gldAlarmControlModeName(alarmControlMode),
              manualAlarmCommanded ? 1u : 0u,
              physicalAlarmCommanded ? 1u : 0u);
    return persisted;
}

uint8_t modelClassToGasClass(int predicted) {
    if (predicted < 0 || predicted >= pgl::gld::model::EXPECTED_OUTPUT_ELEMENTS) {
        return pgl::protocol::GLD_GAS_ANOMALY;
    }
    const uint8_t gasClass = pgl::gld::model::CLASS_MAP[predicted];
    return pgl::protocol::isValidGasClass(gasClass)
        ? gasClass
        : pgl::protocol::GLD_GAS_ANOMALY;
}

bool modelProfileMatchesActiveNulling() {
    if (FIELDTEST_MODEL_UNVERIFIED || SIMULATED_MODEL_OUTPUT) {
        return true;
    }
    if (!mlReady || !nullingProfileApplied || nullingProfileId == 0) {
        return false;
    }
    if (TFBG_CONTINUOUS_BATTERY) {
        // tfbg is an explicitly non-production field exercise environment.
        return true;
    }
    const uint32_t compiledFingerprint = pgl::gld::modelBindingFingerprint(
        pgl::gld::model::PROFILE_ID, pgl::gld::model::SCALER_PROFILE_ID);
    return pgl::gld::model::PRODUCTION_APPROVED &&
           modelBindingLoaded &&
           pgl::gld::isModelBindingValid(modelBinding) &&
           modelBinding.modelFingerprint == compiledFingerprint &&
           modelBinding.nullingProfileId == nullingProfileId;
}

bool runInference(const float mavVoltage[8]) {
    if (!mlReady || !network->isInitialized()) {
        return false;
    }
    // Channel n is fed directly as feature n (no remap - hardware channel order
    // already matches CNN_GAS_ADC_NAMES order: MQ8, MQ135, MQ3, MQ5, MQ4, MQ7,
    // MQ6, MQ2). Normalization, evidence-feature computation, and INT8
    // quantization happen inside NeuralNetwork::predict().
    float confidenceFloat = 0.0f;
    const int predicted = network->predict(mavVoltage, confidenceFloat);
    if (predicted < 0 || !std::isfinite(confidenceFloat) ||
        confidenceFloat < 0.0f || confidenceFloat > 1.0f) {
        logPrintln("GLD_ML_PREDICT_ERROR");
        return false;
    }
    lastResult = {modelClassToGasClass(predicted),
                  static_cast<uint8_t>(confidenceFloat * 100.0f)};
    logPrintf("GLD_ML_RESULT predictedClass=%d gasClass=%u(%s) confidence=%u\n",
              predicted, lastResult.gasClass,
              pgl::gld::gldGasClassName(lastResult.gasClass),
              lastResult.confidence);
    return true;
}

bool runScan(bool requireCompleteBatch = false) {
    (void)requireCompleteBatch;
    pgl::gld::GldAds1256Reading readings[pgl::gld::board::SENSOR_COUNT]{};
    float mavVoltage[8] = {};
    uint8_t okChannels = 0;
    if (SENSORLESS_BENCH) {
        okChannels = pgl::gld::board::SENSOR_COUNT;
        for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
            latestSensorGain[ch] = 1;
            latestSensorStatus[ch] = static_cast<uint8_t>(pgl::gld::GldAds1256Status::Ok);
            latestSensorVoltage[ch] = 0.0f;
            mavVoltage[ch] = 0.0f;
        }
        logPrintf("GLD_SENSORLESS_BENCH_SCAN dummyChannels=%u adsReady=%u mcpOk=%u/%u\n",
                  static_cast<unsigned>(okChannels),
                  adsReady ? 1u : 0u,
                  static_cast<unsigned>(lastBootMcpOkCount),
                  static_cast<unsigned>(pgl::gld::board::SENSOR_COUNT));
    } else {
        for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
            const pgl::gld::GldAds1256Reading r = ads.readChannel(ch);
            readings[ch] = r;
            latestSensorGain[ch] = r.gain;
            latestSensorStatus[ch] = static_cast<uint8_t>(r.status);
            if (r.status == pgl::gld::GldAds1256Status::Ok && !r.saturated) ++okChannels;
        }
    }
    noteAdsReadHealth(okChannels, "runScan");
    const bool allValid = okChannels == pgl::gld::board::SENSOR_COUNT;
    latestTelemetryValid = allValid;

    uint8_t primedChannels = 0;
    if (SENSORLESS_BENCH) {
        primedChannels = pgl::gld::board::SENSOR_COUNT;
    } else {
        for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
            const bool mayCommit = allValid &&
                                   readings[ch].status == pgl::gld::GldAds1256Status::Ok &&
                                   !readings[ch].saturated;
            mavVoltage[ch] = mayCommit ? movingAvg.add(ch, readings[ch].voltage)
                                       : movingAvg.value(ch);
            latestSensorVoltage[ch] = mavVoltage[ch];
            if (movingAvg.count(ch) >= MIN_PRIMED_COUNT) ++primedChannels;
        }
    }

    const bool primed = primedChannels >= pgl::gld::board::SENSOR_COUNT;
    modelProfileReady = modelProfileMatchesActiveNulling();
    if (FIELDTEST_MODEL_UNVERIFIED) {
        // Payload is intentionally dummy/safe: it proves the authenticated
        // GLD -> CH telemetry path, not gas classification correctness. LoRa
        // cadence is the primary field-test objective, so ADS warm-up/read
        // failures remain visible in diagnostics but never block dummy TX.
        lastResult = {pgl::protocol::GLD_GAS_CLEAR, 0};
        lastInferenceValid = true;
        logPrintf("GLD_FIELDTEST_DUMMY_RESULT allValid=%u primed=%u gasClass=%u confidence=%u\n",
                  allValid ? 1u : 0u, primed ? 1u : 0u,
                  lastResult.gasClass, lastResult.confidence);
#if defined(PGL_GLD_SIMULATED_ALARM_MODEL)
    } else if (true) {
        // Bench-only alarm simulation: keep the production alarm/radio path
        // active, but replace the ML output with a deterministic non-clear
        // result so end-to-end alarm routing can be tested without gas.
        lastResult = {
            static_cast<uint8_t>(PGL_GLD_SIMULATED_ALARM_GAS_CLASS),
            static_cast<uint8_t>(PGL_GLD_SIMULATED_ALARM_CONFIDENCE),
        };
        lastInferenceValid = true;
        logPrintf("GLD_SIM_ALARM_MODEL_RESULT allValid=%u primed=%u gasClass=%u(%s) confidence=%u\n",
                  allValid ? 1u : 0u, primed ? 1u : 0u,
                  lastResult.gasClass, pgl::gld::gldGasClassName(lastResult.gasClass),
                  lastResult.confidence);
#elif defined(PGL_GLD_SIMULATED_CLEAR_MODEL)
    } else if (true) {
        // Bench-only clear simulation for route/pull tests while the bundled
        // model artifact contract is being updated.
        lastResult = {pgl::protocol::GLD_GAS_CLEAR, 100};
        lastInferenceValid = true;
        logPrintf("GLD_SIM_CLEAR_MODEL_RESULT allValid=%u primed=%u gasClass=%u(%s) confidence=%u\n",
                  allValid ? 1u : 0u, primed ? 1u : 0u,
                  lastResult.gasClass, pgl::gld::gldGasClassName(lastResult.gasClass),
                  lastResult.confidence);
#endif
    } else {
        lastInferenceValid = allValid && primed && mlReady && nullingProfileApplied &&
                             modelProfileReady && runtimeDacVerificationReady() &&
                             runInference(mavVoltage);
    }
    sensorFaultActive = FIELDTEST_MODEL_UNVERIFIED ? !(allValid && primed)
                                                   : !lastInferenceValid;
    // The model output is classification confidence, not a calibrated %LEL
    // value. A valid non-clear classification therefore uses a conservative
    // fail-safe alarm policy instead of comparing softmax confidence to 30%.
    const bool classifierAlarm = lastInferenceValid &&
                                 lastResult.gasClass != pgl::protocol::GLD_GAS_CLEAR;
    const bool alarm = FIELDTEST_MODEL_UNVERIFIED ? false : classifierAlarm;
    logPrintf("GLD_SENSOR_SCAN seq=%lu allValid=%u primed=%u inferenceValid=%u sensorFault=%u gasClass=%u(%s) confidence=%u alarm=%u\n",
              static_cast<unsigned long>(txCounter),
              allValid ? 1 : 0, primed ? 1 : 0,
              lastInferenceValid ? 1 : 0, sensorFaultActive ? 1 : 0,
              lastResult.gasClass, pgl::gld::gldGasClassName(lastResult.gasClass),
              lastResult.confidence, alarm ? 1 : 0);
    if (lastInferenceValid) {
        (void)updateAlarmOutputs(alarm);
    } else {
        logPrintf("GLD_ALARM_OUTPUT held=%u reason=sensor_or_inference_fault\n",
                  lastAlarm ? 1 : 0);
    }
    return allValid;
}

bool openLoRaRxWindow(bool expectAlarmAck, uint8_t expectedSeq) {
    if (!radioReady || !loraRadio) return false;
    bool alarmAckMatched = false;
    loraRxFlag = false;
    loraRadio->setPacketReceivedAction(onLoRaRxDone);
    loraRadio->startReceive();
    const uint32_t t0 = millis();
    while (!loraRxFlag && millis() - t0 < LORA_RX_WINDOW_MS) {
        serviceDelay(5);
    }
    if (loraRxFlag) {
        uint8_t rxBuf[pgl::protocol::APPFRAME_OVERHEAD + pgl::protocol::STAR_MAX_PAYLOAD]{};
        const size_t rxLen = loraRadio->getPacketLength();
        const int16_t rxState = loraRadio->readData(rxBuf, sizeof(rxBuf));
        logPrintf("GLD_LORA_DOWNLINK_RX state=%d len=%u\n", rxState, static_cast<unsigned>(rxLen));
        if (rxState == RADIOLIB_ERR_NONE) {
            if (expectAlarmAck && ALLOW_UNAUTHENTICATED_ALARM_ACK &&
                pgl::gld::parseCompactAlarmAck(rxBuf, rxLen,
                                               runtimeConfig.chId,
                                               runtimeConfig.nodeId,
                                               expectedSeq)) {
                alarmAckMatched = true;
                logPrintf("GLD_LORA_ALARM_ACK matched=1 chId=0x%04X nodeId=0x%04X seq=%u\n",
                          runtimeConfig.chId, runtimeConfig.nodeId, expectedSeq);
            } else {
                if (expectAlarmAck && !ALLOW_UNAUTHENTICATED_ALARM_ACK) {
                    logPrintln("GLD_LORA_ALARM_ACK rejected=1 reason=unauthenticated_ack_disabled");
                }
                pgl::gld::GldMode newMode;
                const uint16_t previousCommandId = runtimeConfig.lastDownlinkCommandId;
                if (pgl::gld::parseLoRaDownlinkCmd(rxBuf, rxLen,
                                                   runtimeConfig.nodeId,
                                                   runtimeConfig.aesKey,
                                                   runtimeConfig.aesKeyPresent,
                                                   runtimeConfig.lastDownlinkCommandId,
                                                   newMode)) {
                    if (!saveDownlinkReplayState()) {
                        runtimeConfig.lastDownlinkCommandId = previousCommandId;
                        logPrintln("GLD_LORA_DOWNLINK_CMD rejected=1 reason=replay_state_persist_failed");
                    } else {
                        logPrintf("GLD_LORA_DOWNLINK_CMD mode=%s commandId=%u persisted=1\n",
                                  pgl::gld::gldModeName(newMode),
                                  runtimeConfig.lastDownlinkCommandId);
                        onModeCmd(newMode);
                    }
                }
            }
        }
    }
    loraRadio->standby();
    if (expectAlarmAck && !alarmAckMatched) {
        logPrintf("GLD_LORA_ALARM_ACK matched=0 expectedSeq=%u windowMs=%lu\n",
                  expectedSeq, static_cast<unsigned long>(LORA_RX_WINDOW_MS));
    }
    return alarmAckMatched;
}

bool buildTxSnapshot(const pgl::gld::GldClassifyResult& result,
                     GldTxSnapshot& snapshot) {
    snapshot = {};
    if (!runtimeConfig.aesKeyPresent || runtimeConfig.aesKeyId == 0) {
        lastLoraTxState = -32767;
        lastLoraTxOk = false;
        logPrintln("GLD_SECURITY_NOT_PROVISIONED aesKey=0 txBlocked=1");
        logPrintln("GLD_LORA_TX_RESULT=FAIL");
        return false;
    }

    uint8_t sequence = 0;
    if (!pgl::gld::reserveGldTxSequence(sequence)) {
        lastLoraTxState = -32766;
        lastLoraTxOk = false;
        logPrintln("GLD_TX_SEQUENCE_RESERVE=FAIL txBlocked=1");
        return false;
    }
    txSeq = sequence;

    const pgl::gld::GldPowerReading power = pgl::gld::readGldPower();
    const uint16_t batteryMv = power.batteryValid ? power.batteryMv
                                                   : pgl::protocol::GLD_BATTERY_MV_INVALID;
    pgl::gld::GldFrameBuilderConfig config{
        runtimeConfig.nodeId, runtimeConfig.chId,
        runtimeConfig.aesKeyId, runtimeConfig.aesKey,
        TFBG_CONTINUOUS_BATTERY ? false : power.externalPower,
        1,
    };
    pgl::gld::GldFrameBuildInput input{
        result.gasClass, result.confidence, batteryMv, sequence,
    };
    NonceCtx nonceCtx{txCounter};
    pgl::gld::GldBuiltFrame frame{};
    const pgl::gld::GldFrameStatus buildStatus =
        pgl::gld::buildGldUplinkFrame(config, input, nonceProvider, &nonceCtx, frame);
    txCounter = nonceCtx.counter;

    logPrintf("GLD_TX_HEADER status=%s seq=%u typeFlags=0x%02X alarm=%u gasClass=%u(%s) confidence=%u frameSize=%u\n",
              pgl::gld::gldFrameStatusName(buildStatus), sequence, frame.typeFlags,
              frame.alarm ? 1 : 0, result.gasClass,
              pgl::gld::gldGasClassName(result.gasClass),
              result.confidence, static_cast<unsigned>(frame.size));

    if (buildStatus != pgl::gld::GldFrameStatus::Ok) {
        lastLoraTxState = -32768;
        lastLoraTxOk = false;
        logPrintln("GLD_LORA_TX_RESULT=FAIL");
        return false;
    }

    if (frame.size > sizeof(snapshot.frame)) {
        lastLoraTxState = -32765;
        lastLoraTxOk = false;
        logPrintln("GLD_TX_SNAPSHOT=FAIL reason=frame_too_large");
        return false;
    }
    snapshot.valid = true;
    snapshot.alarm = frame.alarm;
    snapshot.sequence = sequence;
    snapshot.frameLen = static_cast<uint8_t>(frame.size);
    memcpy(snapshot.frame, frame.bytes, frame.size);
    return true;
}

bool loadFrozenPendingSnapshot(const pgl::gld::GldPendingAlarm& pending,
                               GldTxSnapshot& snapshot) {
    snapshot = {};
    if (!pgl::gld::gldPendingAlarmHasFrozenFrame(pending)) {
        return false;
    }
    snapshot.valid = true;
    snapshot.alarm = true;
    snapshot.sequence = pending.sequence;
    snapshot.frameLen = pending.frameLen;
    memcpy(snapshot.frame, pending.frame, pending.frameLen);
    txSeq = pending.sequence;
    return true;
}

bool persistAlarmSnapshot(const pgl::gld::GldClassifyResult& result,
                          const GldTxSnapshot& snapshot) {
    if (!snapshot.valid || !snapshot.alarm || snapshot.frameLen == 0) {
        return false;
    }
    pgl::gld::GldPendingAlarm pending{};
    pending.active = true;
    pending.gasClass = result.gasClass;
    pending.confidence = result.confidence;
    pending.sequence = snapshot.sequence;
    pending.frameLen = snapshot.frameLen;
    memcpy(pending.frame, snapshot.frame, snapshot.frameLen);
    batteryPendingAlarm = pending;
    if (!pgl::gld::writeGldPendingAlarm(pending)) {
        batteryPendingSaveRequired = true;
        logPrintf("GLD_BATTERY_ALARM_PENDING_SAVE=FAIL seq=%u txBlocked=1\n",
                  snapshot.sequence);
        return false;
    }
    batteryPendingSaveRequired = false;
    logPrintf("GLD_BATTERY_ALARM_PENDING_SAVE=OK seq=%u frameLen=%u frozen=1\n",
              pending.sequence, pending.frameLen);
    return true;
}

bool transmitSnapshot(const GldTxSnapshot& snapshot,
                      bool expectAlarmAck = false) {
    if (FIELDTEST_MODEL_UNVERIFIED && (snapshot.alarm || expectAlarmAck)) {
        lastLoraTxState = -32763;
        lastLoraTxOk = false;
        logPrintf("GLD_FIELDTEST_ALARM_TX_SUPPRESSED frameLen=%u alarm=%u alarmAck=%u\n",
                  static_cast<unsigned>(snapshot.frameLen), snapshot.alarm ? 1 : 0,
                  expectAlarmAck ? 1 : 0);
        return false;
    }
    if (FIELDTEST_MODEL_UNVERIFIED) {
        logPrintf("GLD_FIELDTEST_TELEMETRY_TX frameLen=%u\n",
                  static_cast<unsigned>(snapshot.frameLen));
    }
    if (!snapshot.valid || snapshot.frameLen == 0 || !radioReady || loraRadio == nullptr) {
        lastLoraTxState = -32764;
        lastLoraTxOk = false;
        logPrintln("GLD_LORA_TX_RESULT=FAIL reason=invalid_snapshot_or_radio");
        return false;
    }

    digitalWrite(pgl::gld::board::PIN_ADS1256_CS, HIGH);
    const int16_t txState = loraRadio->transmit(snapshot.frame, snapshot.frameLen);
    lastLoraTxState = txState;
    lastLoraTxOk = txState == RADIOLIB_ERR_NONE;
    digitalWrite(pgl::gld::board::PIN_LORA_RXEN, LOW);
    digitalWrite(pgl::gld::board::PIN_LORA_TXEN, LOW);
    logPrintf("GLD_STAR_TX_STATE=%d seq=%u frameLen=%u frozen=%u\n",
              txState, snapshot.sequence, snapshot.frameLen,
              snapshot.alarm ? 1u : 0u);
    logPrintln(txState == RADIOLIB_ERR_NONE ? "GLD_LORA_TX_RESULT=PASS" : "GLD_LORA_TX_RESULT=FAIL");

    // Class A RX window for downlink commands
    return openLoRaRxWindow(expectAlarmAck, snapshot.sequence);
}

bool transmitOnce(bool expectAlarmAck = false) {
    if (!lastInferenceValid) {
        lastLoraTxOk = false;
        logPrintln("GLD_LORA_TX_RESULT=BLOCKED reason=inference_invalid");
        return false;
    }
    GldTxSnapshot snapshot{};
    if (!buildTxSnapshot(lastResult, snapshot)) {
        return false;
    }
    return transmitSnapshot(snapshot, expectAlarmAck);
}

bool prepareAndPersistAlarmDelivery(const pgl::gld::GldClassifyResult& result) {
    GldTxSnapshot snapshot{};
    if (!buildTxSnapshot(result, snapshot) || !snapshot.alarm) {
        logPrintln("GLD_BATTERY_ALARM_PREPARE=FAIL reason=frame_build");
        return false;
    }
    batteryTxSnapshot = snapshot;
    batterySendingPersistedAlarm = true;
    if (!persistAlarmSnapshot(result, snapshot)) {
        return false;
    }
    return true;
}

bool activateQueuedFreshAlarm(const char* reason) {
    if (!batteryFreshAlarmQueued || !batteryFreshInferenceValid || !batteryFreshAlarm) {
        return false;
    }
    if (!prepareAndPersistAlarmDelivery(batteryFreshResult)) {
        return false;
    }
    batteryFreshAlarmQueued = false;
    batteryAlarmTxAttempts = 0;
    batteryAlarmAckReceived = false;
    batteryNextTxAttemptMs = millis();
    (void)updateAlarmOutputs(true);
    logPrintf("GLD_BATTERY_FRESH_ALARM_ACTIVATED reason=%s gasClass=%u confidence=%u seq=%u\n",
              reason != nullptr ? reason : "queued",
              batteryFreshResult.gasClass,
              batteryFreshResult.confidence,
              batteryTxSnapshot.sequence);
    return true;
}

void runBatteryInferenceSession() {
    const uint32_t now = millis();

    if (batterySessionState == BatterySessionState::Inactive ||
        batterySessionState == BatterySessionState::PowerOffIssued) {
        return;
    }

    if (batterySessionState == BatterySessionState::CompleteHeld) {
        if (SENSORLESS_REPEAT_BENCH) {
            if (now - batterySessionStartedMs >= SENSORLESS_REPEAT_INTERVAL_MS) {
                logPrintf("GLD_SENSORLESS_REPEAT_RESTART intervalMs=%lu elapsedMs=%lu previousReason=%s\n",
                          static_cast<unsigned long>(SENSORLESS_REPEAT_INTERVAL_MS),
                          static_cast<unsigned long>(now - batterySessionStartedMs),
                          batteryCompletionReason);
                startBatteryInferenceSession();
            }
            return;
        }
        if (batteryPersistenceFaultHold) {
            if (static_cast<int32_t>(now - batteryPersistenceRetryDueMs) >= 0) {
                batteryPersistenceFaultHold = false;
                batterySessionState = BatterySessionState::Transmit;
                batteryStateStartedMs = now;
                batteryNextTxAttemptMs = now;
                logPrintln("GLD_BATTERY_PERSISTENCE_HOLD retry=1 state=transmit clrBlocked=0");
            }
            return;
        }
        if (!serviceHoldBlocksClr()) {
            logPrintln("GLD_BATTERY_SESSION_RELEASED serviceHold=0 action=power_off");
            completeBatterySessionAndPowerOff(batteryCompletionReason);
        }
        return;
    }

    if (now - batterySessionStartedMs >= BATTERY_SESSION_DEADLINE_MS) {
        logPrintf("GLD_BATTERY_SESSION_DEADLINE elapsedMs=%lu state=%s validBatches=%u txAttempts=%u\n",
                  static_cast<unsigned long>(now - batterySessionStartedMs),
                  batterySessionStateName(batterySessionState),
                  static_cast<unsigned>(batteryValidSampleBatches),
                  static_cast<unsigned>(batteryAlarmTxAttempts));
        completeBatterySessionAndPowerOff("hard_deadline");
        return;
    }

    switch (batterySessionState) {
        case BatterySessionState::Warmup:
            if (batteryLastWarmupPrimeMs == 0 ||
                now - batteryLastWarmupPrimeMs >= SCAN_INTERVAL_MS) {
                batteryLastWarmupPrimeMs = now;
                uint8_t stableChannels = 0;
                if (SENSORLESS_BENCH) {
                    stableChannels = pgl::gld::board::SENSOR_COUNT;
                } else {
                    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
                        const pgl::gld::GldAds1256Reading reading = ads.readChannel(ch);
                        if (reading.status == pgl::gld::GldAds1256Status::Ok &&
                            !reading.saturated) {
                            ++stableChannels;
                        }
                    }
                }
                logPrintf("GLD_BATTERY_WARMUP_AGC stableChannels=%u/%u\n",
                          static_cast<unsigned>(stableChannels),
                          static_cast<unsigned>(pgl::gld::board::SENSOR_COUNT));
            }
            if (now - batteryStateStartedMs < BATTERY_SENSOR_WARMUP_MS) return;
            movingAvg.reset();
            batteryValidSampleBatches = 0;
            batteryLastSampleAttemptMs = 0;
            batterySessionState = BatterySessionState::Sampling;
            batteryStateStartedMs = now;
            logPrintf("GLD_BATTERY_WARMUP_DONE elapsedMs=%lu movingAverageReset=1\n",
                      static_cast<unsigned long>(now - batterySessionStartedMs));
            return;

        case BatterySessionState::Sampling: {
            if (batteryLastSampleAttemptMs != 0 &&
                now - batteryLastSampleAttemptMs < SCAN_INTERVAL_MS) {
                return;
            }
            batteryLastSampleAttemptMs = now;
            lastScanMs = now;
            const bool completeValidBatch = runScan(true);
            if (completeValidBatch) {
                if (SENSORLESS_BENCH) {
                    if (batteryValidSampleBatches < BATTERY_VALID_SAMPLE_BATCHES) {
                        ++batteryValidSampleBatches;
                    }
                } else {
                    uint8_t primedBatchCount = UINT8_MAX;
                    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
                        const uint8_t count = movingAvg.count(ch);
                        if (count < primedBatchCount) primedBatchCount = count;
                    }
                    batteryValidSampleBatches = primedBatchCount;
                }
            }
            logPrintf("GLD_BATTERY_SAMPLE valid=%u count=%u required=%u\n",
                      completeValidBatch ? 1 : 0,
                      static_cast<unsigned>(batteryValidSampleBatches),
                      static_cast<unsigned>(BATTERY_VALID_SAMPLE_BATCHES));
            if (batteryValidSampleBatches < BATTERY_VALID_SAMPLE_BATCHES) return;

            batteryFreshInferenceValid = lastInferenceValid;
            batteryFreshResult = lastResult;
            batteryFreshAlarm = lastInferenceValid &&
                                lastResult.gasClass != pgl::protocol::GLD_GAS_CLEAR;
            batteryFreshAlarmQueued = false;
            batterySendingPersistedAlarm = false;
            batteryTxSnapshot = {};

            if (!batteryFreshInferenceValid && !batteryPendingAlarm.active) {
                armBatteryFaultPowerOff("inference_invalid");
                if (static_cast<int32_t>(now - batteryFaultPowerOffDueMs) >= 0) {
                    completeBatterySessionAndPowerOff("inference_invalid");
                }
                return;
            }

            if (batteryPendingAlarm.active) {
                logPrintf("GLD_BATTERY_PENDING_ALARM_LOAD gasClass=%u confidence=%u freshValid=%u freshGasClass=%u freshConfidence=%u frozen=%u\n",
                          batteryPendingAlarm.gasClass,
                          batteryPendingAlarm.confidence,
                          batteryFreshInferenceValid ? 1u : 0u,
                          batteryFreshResult.gasClass,
                          batteryFreshResult.confidence,
                          pgl::gld::gldPendingAlarmHasFrozenFrame(batteryPendingAlarm) ? 1u : 0u);
                if (!loadFrozenPendingSnapshot(batteryPendingAlarm, batteryTxSnapshot)) {
                    const pgl::gld::GldClassifyResult legacyResult{
                        batteryPendingAlarm.gasClass,
                        batteryPendingAlarm.confidence,
                    };
                    if (!prepareAndPersistAlarmDelivery(legacyResult)) {
                        enterBatteryPersistenceFaultHold("pending_alarm_persist_failed");
                        return;
                    }
                } else {
                    batterySendingPersistedAlarm = true;
                }
                batteryFreshAlarmQueued = batteryFreshAlarm &&
                    (batteryFreshResult.gasClass != batteryPendingAlarm.gasClass ||
                     batteryFreshResult.confidence != batteryPendingAlarm.confidence);
                (void)updateAlarmOutputs(true);
            } else if (batteryFreshAlarm) {
                if (!prepareAndPersistAlarmDelivery(batteryFreshResult)) {
                    enterBatteryPersistenceFaultHold("alarm_persist_failed");
                    return;
                }
                (void)updateAlarmOutputs(true);
            } else if (!buildTxSnapshot(batteryFreshResult, batteryTxSnapshot)) {
                completeBatterySessionAndPowerOff("normal_frame_build_failed");
                return;
            }
            batteryAlarmTxAttempts = 0;
            batteryAlarmAckReceived = false;
            batteryNextTxAttemptMs = now;
            batterySessionState = BatterySessionState::Transmit;
            batteryStateStartedMs = now;
            logPrintf("GLD_BATTERY_INFERENCE_READY alarm=%u freshValid=%u freshQueued=%u gasClass=%u confidence=%u seq=%u frozen=%u\n",
                      batteryTxSnapshot.alarm ? 1u : 0u,
                      batteryFreshInferenceValid ? 1u : 0u,
                      batteryFreshAlarmQueued ? 1u : 0u,
                      batteryFreshResult.gasClass,
                      batteryFreshResult.confidence,
                      batteryTxSnapshot.sequence,
                      batterySendingPersistedAlarm ? 1u : 0u);
            return;
        }

        case BatterySessionState::Transmit: {
            if (static_cast<int32_t>(now - batteryNextTxAttemptMs) < 0) return;

            if (batteryPendingSaveRequired) {
                if (!pgl::gld::writeGldPendingAlarm(batteryPendingAlarm)) {
                    enterBatteryPersistenceFaultHold("pending_alarm_persist_retry_failed");
                    return;
                }
                batteryPendingSaveRequired = false;
                logPrintf("GLD_BATTERY_ALARM_PENDING_SAVE=OK seq=%u retry=1\n",
                          batteryPendingAlarm.sequence);
            }

            if (batteryAlarmAckReceived) {
                const pgl::gld::GldPendingAlarm cleared{};
                if (!pgl::gld::writeGldPendingAlarm(cleared)) {
                    batteryNextTxAttemptMs = millis() + BATTERY_ALARM_RETRY_DELAY_MS;
                    logPrintln("GLD_BATTERY_ALARM_PENDING_CLEAR=FAIL powerOffBlocked=1");
                    enterBatteryPersistenceFaultHold("pending_alarm_clear_failed");
                    return;
                }
                batteryPendingAlarm = {};
                batteryAlarmAckReceived = false;
                if (activateQueuedFreshAlarm("prior_alarm_acknowledged")) {
                    return;
                }
                if (batteryFreshInferenceValid && !batteryFreshAlarm &&
                    !updateAlarmOutputs(false)) {
                    batteryAlarmAckReceived = true;
                    batteryNextTxAttemptMs = millis() + BATTERY_ALARM_RETRY_DELAY_MS;
                    logPrintln("GLD_BATTERY_ALARM_LATCH_CLEAR=FAIL powerOffBlocked=1");
                    enterBatteryPersistenceFaultHold("alarm_latch_clear_failed");
                    return;
                }
                completeBatterySessionAndPowerOff("alarm_ack_received");
                return;
            }

            const bool alarm = batteryTxSnapshot.alarm;
            const bool alarmAck = transmitSnapshot(batteryTxSnapshot, alarm);
            if (alarm) {
                ++batteryAlarmTxAttempts;
            }
            if (!alarm) {
                completeBatterySessionAndPowerOff(lastLoraTxOk
                    ? "normal_tx_rx_done"
                    : "normal_tx_failed");
                return;
            }

            if (alarmAck) {
                batteryAlarmAckReceived = true;
                logPrintf("GLD_BATTERY_ALARM_ACK_SUCCESS attempts=%u\n",
                          static_cast<unsigned>(batteryAlarmTxAttempts));
                batteryNextTxAttemptMs = millis();
                return;
            }

            if (batteryAlarmTxAttempts < BATTERY_ALARM_TX_ATTEMPTS) {
                batteryNextTxAttemptMs = millis() + BATTERY_ALARM_RETRY_DELAY_MS;
                logPrintf("GLD_BATTERY_ALARM_TX_RETRY reason=%s attempt=%u nextAttempt=%u max=%u delayMs=%lu\n",
                          lastLoraTxOk ? "ack_timeout" : "tx_failed",
                          static_cast<unsigned>(batteryAlarmTxAttempts),
                          static_cast<unsigned>(batteryAlarmTxAttempts + 1U),
                          static_cast<unsigned>(BATTERY_ALARM_TX_ATTEMPTS),
                          static_cast<unsigned long>(BATTERY_ALARM_RETRY_DELAY_MS));
                return;
            }

            if (batteryFreshAlarmQueued) {
                if (activateQueuedFreshAlarm("prior_alarm_retry_exhausted")) {
                    return;
                }
                batteryNextTxAttemptMs = millis() + BATTERY_ALARM_RETRY_DELAY_MS;
                logPrintln("GLD_BATTERY_FRESH_ALARM_ACTIVATE=FAIL powerOffBlocked=1");
                enterBatteryPersistenceFaultHold("fresh_alarm_persist_failed");
                return;
            }
            logPrintf("GLD_BATTERY_ALARM_PENDING_RETAIN attempts=%u gasClass=%u confidence=%u seq=%u sleepNext=1\n",
                      static_cast<unsigned>(batteryAlarmTxAttempts),
                      batteryPendingAlarm.gasClass,
                      batteryPendingAlarm.confidence,
                      batteryPendingAlarm.sequence);
            completeBatterySessionAndPowerOff("alarm_ack_timeout_pending");
            return;
        }

        case BatterySessionState::CompleteHeld:
        case BatterySessionState::PowerOffIssued:
        case BatterySessionState::Inactive:
            return;
    }
}

// ---------------------------------------------------------------------------
// Dataset sample publish
// ---------------------------------------------------------------------------

void stopDataset(const char* detail = "completed");

void rejectDatasetRecord(
    const pgl::gld::GldDatasetValidationResult& validation,
    const pgl::gld::GldDatasetChannelSample* samples,
    size_t count) {
    ++datasetRejectedSamples;
    lastDatasetRejectReason = validation.reason;
    lastDatasetRejectChannel = validation.channel;
    lastDatasetRejectOkFiniteCount = validation.okFiniteCount;
    lastDatasetRejectStatus = 0xFF;
    lastDatasetRejectGain = 0;
    lastDatasetRejectSaturated = false;

    if (validation.channel >= 0 &&
        static_cast<size_t>(validation.channel) < count && samples != nullptr) {
        const pgl::gld::GldDatasetChannelSample& sample =
            samples[static_cast<size_t>(validation.channel)];
        lastDatasetRejectStatus = sample.status;
        lastDatasetRejectGain = sample.gain;
        lastDatasetRejectSaturated = sample.saturated;
    }

    logPrintf(
        "DATASET_RECORD_REJECT attemptedSeq=%lu reason=%s channel=%d "
        "okFiniteCount=%u status=%u gain=%u saturated=%u rejectedTotal=%lu\n",
        static_cast<unsigned long>(datasetSeq),
        pgl::gld::gldDatasetRejectReasonName(validation.reason),
        static_cast<int>(validation.channel),
        static_cast<unsigned>(validation.okFiniteCount),
        static_cast<unsigned>(lastDatasetRejectStatus),
        static_cast<unsigned>(lastDatasetRejectGain),
        lastDatasetRejectSaturated ? 1u : 0u,
        static_cast<unsigned long>(datasetRejectedSamples));
    publishDatasetRejectedStatus(validation, samples, count);
}

bool publishDataRecord() {
    pgl::gld::GldAds1256Reading readings[pgl::gld::GLD_DATASET_FEATURE_COUNT]{};
    pgl::gld::GldDatasetChannelSample samples[pgl::gld::GLD_DATASET_FEATURE_COUNT]{};
    uint8_t statusOkChannels = 0;

    static_assert(pgl::gld::board::SENSOR_COUNT == pgl::gld::GLD_DATASET_FEATURE_COUNT,
                  "Dataset contract requires exactly eight board channels");
    for (uint8_t ch = 0; ch < pgl::gld::board::SENSOR_COUNT; ++ch) {
        readings[ch] = ads.readChannel(ch);
        const pgl::gld::GldAds1256Reading& reading = readings[ch];
        latestSensorVoltage[ch] = reading.voltage;
        latestSensorGain[ch] = reading.gain;
        latestSensorStatus[ch] = static_cast<uint8_t>(reading.status);
        if (reading.status == pgl::gld::GldAds1256Status::Ok) ++statusOkChannels;
        samples[ch] = pgl::gld::GldDatasetChannelSample{
            pgl::gld::board::SENSOR_NAMES[ch],
            static_cast<uint8_t>(reading.status),
            reading.voltage,
            reading.gain,
            reading.saturated,
        };
    }
    noteAdsReadHealth(statusOkChannels, "dataset");

    pgl::gld::GldDatasetValidationResult validation =
        pgl::gld::validateGldDatasetSample(
            samples,
            pgl::gld::board::SENSOR_COUNT,
            nullingProfileApplied,
            nullingProfileId);
    latestTelemetryValid = validation.accepted;
    if (!validation.accepted) {
        rejectDatasetRecord(validation, samples, pgl::gld::board::SENSOR_COUNT);
        return false;
    }

    // Build the wire record only after all eight readings satisfy the schema.
    StaticJsonDocument<1024> doc;
    doc["device_id"]          = runtimeConfig.deviceId;
    doc["node_id"]            = runtimeConfig.nodeId;
    doc["mode"]               = "DATASET";
    doc["seq"]                = datasetSeq;
    doc["timestamp_ms"]       = static_cast<uint32_t>(millis());
    doc["label"]              = currentLabel;
    doc["nulling_profile_id"] = nullingProfileId;
    JsonArray svArr = doc.createNestedArray("sensor_voltage");
    JsonArray gainArr = doc.createNestedArray("sensor_gain");
    JsonArray statusArr = doc.createNestedArray("sensor_status");
    JsonArray foArr = doc.createNestedArray("feature_order");
    for (size_t ch = 0; ch < pgl::gld::GLD_DATASET_FEATURE_COUNT; ++ch) {
        svArr.add(readings[ch].voltage);
        gainArr.add(readings[ch].gain);
        statusArr.add(static_cast<uint8_t>(readings[ch].status));
        foArr.add(pgl::gld::GLD_DATASET_CANONICAL_FEATURE_ORDER[ch]);
    }

    char payload[DATASET_PAYLOAD_BYTES];
    const size_t requiredLen = measureJson(doc);
    if (doc.overflowed() || requiredLen == 0 || requiredLen >= sizeof(payload)) {
        validation.accepted = false;
        validation.reason = pgl::gld::GldDatasetRejectReason::PayloadEncoding;
        validation.channel = -1;
        rejectDatasetRecord(validation, samples, pgl::gld::board::SENSOR_COUNT);
        return false;
    }
    const size_t len = serializeJson(doc, payload, sizeof(payload));
    if (len != requiredLen) {
        validation.accepted = false;
        validation.reason = pgl::gld::GldDatasetRejectReason::PayloadEncoding;
        validation.channel = -1;
        rejectDatasetRecord(validation, samples, pgl::gld::board::SENSOR_COUNT);
        return false;
    }
    payload[len] = '\0';

    const bool published = publishDatasetPayload(payload, datasetSeq, false);
    if (!published) {
        if (!enqueueDatasetPayload(payload, len, datasetSeq)) {
            logPrintf("DATASET_RECORD_ABORT seq=%lu reason=queue_full\n",
                      static_cast<unsigned long>(datasetSeq));
            stopDataset("queue_full");
            return false;
        }
    }
    logPrintf("DATASET_RECORD seq=%lu ok=%u queued=%u pending=%u len=%u\n",
              static_cast<unsigned long>(datasetSeq), published ? 1 : 0,
              published ? 0 : 1,
              static_cast<unsigned>(datasetQueueCount),
              static_cast<unsigned>(len));
    ++datasetSeq;
    return true;
}

bool shouldAutoStop() {
    if (targetSamples > 0 && datasetSeq >= targetSamples) {
        logPrintf("DATASET_AUTOSTOP target_reached total=%lu\n", static_cast<unsigned long>(datasetSeq));
        return true;
    }
    if (maxDurationMs > 0 && millis() - sessionStartMs >= maxDurationMs) {
        logPrintf("DATASET_AUTOSTOP max_duration total=%lu\n", static_cast<unsigned long>(datasetSeq));
        return true;
    }
    return false;
}

void stopDataset(const char* detail) {
    optionalDigitalWrite(pgl::gld::board::PIN_DC_FAN, LOW);
    datasetState = DatasetState::Idle;
    sampleStep   = SampleStep::None;
    optionalDigitalWrite(pgl::gld::board::PIN_STATUS_LED, ACTIVE_LOW_OUTPUT_OFF);
    publishDatasetSummary();
    publishDatasetStatus("idle", detail != nullptr ? detail : "completed");
}

void runDatasetStateMachine() {
    if (datasetState != DatasetState::Running || !adsReady) return;
    const uint32_t now = millis();
    switch (sampleStep) {
        case SampleStep::None:
            if (now - lastScanMs >= sampleIntervalMs) {
                if (pgl::gld::board::HAS_DC_FAN && useFanIntake && fanOnMs > 0) {
                    optionalDigitalWrite(pgl::gld::board::PIN_DC_FAN, HIGH);
                    stepStartMs = now;
                    sampleStep  = SampleStep::FanOn;
                } else {
                    publishDataRecord(); lastScanMs = now;
                    if (datasetState == DatasetState::Running && shouldAutoStop()) stopDataset();
                }
            }
            break;
        case SampleStep::FanOn:
            if (now - stepStartMs >= fanOnMs) {
                optionalDigitalWrite(pgl::gld::board::PIN_DC_FAN, LOW);
                stepStartMs = now;
                sampleStep  = (postFanSettleMs > 0) ? SampleStep::FanSettle : SampleStep::Scan;
            }
            break;
        case SampleStep::FanSettle:
            if (now - stepStartMs >= postFanSettleMs) sampleStep = SampleStep::Scan;
            break;
        case SampleStep::Scan:
            publishDataRecord(); lastScanMs = now; sampleStep = SampleStep::None;
            if (datasetState == DatasetState::Running && shouldAutoStop()) stopDataset();
            break;
    }
}

}  // namespace

// ---------------------------------------------------------------------------
// Arduino entry points
// ---------------------------------------------------------------------------

void setup() {
    Serial.begin(115200);
#if defined(ARDUINO_ARCH_ESP32)
    Serial0.begin(115200);
#endif
    pgl::gld::beginGldPowerPins();
    // Give USB serial time to settle, but do not dispatch queued operator
    // commands before the boot banner is visible. A queued SLEEP_NOW must not
    // clear the power latch before the operator can see firmware startup.
    delay(1000);
    loadRuntimeConfig();
    modelBindingLoaded = pgl::gld::loadModelBinding(modelBinding);
    if (!modelBindingLoaded) modelBinding = pgl::gld::GldModelBinding{};
    logPrintf("MODEL_NULLING_BIND_LOAD=%s profileId=%u fingerprint=%08lX\n",
              modelBindingLoaded ? "OK" : "MISSING_OR_INVALID",
              modelBinding.nullingProfileId,
              static_cast<unsigned long>(modelBinding.modelFingerprint));
    if (!pgl::gld::loadNullingConfig(nullingConfig)) {
        nullingConfig = pgl::gld::GldNullingConfig{};
    }
    serviceHoldActive = pgl::gld::readGldServiceHold();
    batteryPendingAlarm = pgl::gld::readGldPendingAlarm();
    setupPins();
#if PGL_GLD_BOARD_PROFILE_GLD2
    pcfReady = pcf8574.begin(Wire);
    // Do not alter PCF8574/EN until the actual power mode is known below.
    // On external power, this boot path must preserve every sensor rail.
    pcfAllLoadSwitchesOn = false;
    modbusReady = modbusRtu.begin(pgl::gld::GldModbusRtu::kDefaultUnitId,
                                  pgl::gld::GldModbusRtu::kDefaultBaud,
                                  pgl::gld::board::PIN_RS485_DIR,
                                  pgl::gld::board::PIN_RS485_RX,
                                  pgl::gld::board::PIN_RS485_TX);
#endif
    const bool persistedAlarmLatched = pgl::gld::readGldAlarmLatched();
    if (persistedAlarmLatched || batteryPendingAlarm.active) {
        (void)updateAlarmOutputs(true);
    }
    beginServiceHoldButton();
    movingAvg.reset();

    currentMode = pgl::gld::readGldMode();

    logPrintln("");
    logPrintln("Pertamina GLD unified firmware");
    logPrintf("Firmware name: %s\n", pgl::firmware::GLD_FIRMWARE_NAME);
    logPrintf("Firmware version: %s\n", pgl::firmware::GLD_FIRMWARE_VERSION);
    logPrintf("Protocol version: %s\n", pgl::firmware::PROTOCOL_VERSION);
    logPrintf("Build date/time: %s %s Asia/Jakarta\n", __DATE__, __TIME__);
    logPrintf("GLD_MODE=%s\n", pgl::gld::gldModeName(currentMode));
    logPrintln("GLD_DEBUG=ON command=DEBUG_OFF|DEBUG_ON");
    logPrintf("[BOOT] GLD mulai boot. firmware=%s mode=%s profile=%s\n",
              pgl::firmware::GLD_FIRMWARE_VERSION,
              pgl::gld::gldModeName(currentMode),
              BOARD_PROFILE);

    const pgl::gld::GldPowerReading power = pgl::gld::readGldPower();
    lastKnownBatteryMv = power.batteryMv;
    lastKnownExternalPower = power.externalPower;
    logPrintf("GLD_POWER mode=%s externalPower=%u batteryMv=%u batterySense=%s ambiguous=%u\n",
              pgl::gld::gldPowerModeName(power.mode),
              power.externalPower ? 1 : 0, power.batteryMv,
              pgl::gld::gldBatterySenseStatusName(power.batterySenseStatus),
              power.powerSourceAmbiguous ? 1u : 0u);
    batteryPowerMode = TFBG_CONTINUOUS_BATTERY || !power.externalPower;
#if PGL_GLD_BOARD_PROFILE_GLD2
    dac.setAutomaticSensorPowerControl(batteryPowerMode);
    bool pcfOutputsRead = false;
    if (pcfReady && !batteryPowerMode) {
        // This is observational only: it refreshes the app's PCF status
        // without sending an output byte or changing any TPS22919 EN line.
        uint8_t liveOutputs = 0;
        pcfOutputsRead = pcf8574.readOutputs(liveOutputs);
        pcfAllLoadSwitchesOn = pcfOutputsRead &&
                                liveOutputs == pgl::gld::board::PCF8574_ALL_LOAD_SWITCHES_ON;
    }
    logPrintf("GLD2_PCF8574 ready=%u addr=0x%02X outputs=0x%02X allLoadSwitchesOn=%u powerPolicy=%s read=%u\n",
              pcfReady ? 1u : 0u,
              pgl::gld::board::PCF8574_ADDR,
              pcf8574.outputs(),
              pcfAllLoadSwitchesOn ? 1u : 0u,
              batteryPowerMode ? "automatic" : "preserve",
              pcfOutputsRead ? 1u : 0u);
    logPrintf("GLD2_ST_P raw=%d source=%s\n",
              digitalRead(pgl::gld::board::PIN_POWER_SOURCE_STATUS),
              readStpSource24V() ? "24V" : "BATTERY");
    logPrintf("GLD2_MODBUS role=slave ready=%u unitId=%u baud=%lu format=8N1 readOnly=1\n",
              modbusReady ? 1u : 0u,
              static_cast<unsigned>(pgl::gld::GldModbusRtu::kDefaultUnitId),
              static_cast<unsigned long>(pgl::gld::GldModbusRtu::kDefaultBaud));
#endif
    powerModeCandidateBattery = batteryPowerMode;
    powerModeCandidateCount = 0;
    lastPowerReconcileMs = millis();
    if (batteryPowerMode && !TFBG_CONTINUOUS_BATTERY &&
        currentMode != pgl::gld::GldMode::INFERENCE) {
        const pgl::gld::GldMode rejectedMode = currentMode;
        currentMode = pgl::gld::GldMode::INFERENCE;
        const bool persisted = pgl::gld::writeGldMode(currentMode);
        logPrintf("MODE_BATTERY_REJECTED requested=%s fallback=inference persisted=%u\n",
                  pgl::gld::gldModeName(rejectedMode), persisted ? 1u : 0u);
    }
    if (batteryPowerMode && serviceHoldActive) {
        logPrintln("GLD_SERVICE_HOLD state=ON source=nvs persisted=1");
        blinkServiceHoldEnabled();
    }
    pulseWdtKeepaliveNow();
    emitInfoJson();
    emitStatusJson();

    const BootDiagnosticsResult bootDiagnostics = runBootHardwareDiagnostics(power.externalPower,
                                                                              batteryPowerMode);
    const BootAdsReport& bootAds = bootDiagnostics.ads;
    const BootI2cReport& bootI2c = bootDiagnostics.i2c;
    const BootMcpControlReport& bootMcpControl = bootDiagnostics.mcpControl;

    if (currentMode == pgl::gld::GldMode::INFERENCE) {
        // --- INFERENCE mode init ---
        disableNetworkForOfflineMode("inference_mode");
        network = new NeuralNetwork();
        mlReady = network->isInitialized();
        const int mlInputSize = mlReady ? network->getInputSize() : -1;
        const int mlOutputSize = mlReady ? network->getOutputSize() : -1;
        logPrintf("GLD_ML_INIT initialized=%u inputSize=%d outputSize=%d\n",
                  mlReady ? 1 : 0, mlInputSize, mlOutputSize);

        radioReady = beginLoraRadio();
        runExternalPowerBootSensorSamples(power);
        modelProfileReady = modelProfileMatchesActiveNulling();
        logPrintf("GLD_MODEL_PROFILE id=%s scaler=%s approved=%u boundNullingProfileId=%u bindingValid=%u activeNullingProfileId=%u tfbgOverride=%u ready=%u\n",
                  pgl::gld::model::PROFILE_ID,
                  pgl::gld::model::SCALER_PROFILE_ID,
                  pgl::gld::model::PRODUCTION_APPROVED ? 1u : 0u,
                  modelBindingLoaded ? modelBinding.nullingProfileId : 0u,
                  modelBindingLoaded ? 1u : 0u,
                  nullingProfileId,
                  TFBG_CONTINUOUS_BATTERY ? 1u : 0u,
                  modelProfileReady ? 1u : 0u);
        logPrintf("GLD_INFERENCE_READY adsReady=%u radioReady=%u mlReady=%u nullingApplied=%u modelProfileReady=%u profileId=%u\n",
                  adsReady ? 1 : 0, radioReady ? 1 : 0, mlReady ? 1 : 0,
                  nullingProfileApplied ? 1 : 0, modelProfileReady ? 1 : 0,
                  nullingProfileId);
        char modeDetail[128];
        snprintf(modeDetail, sizeof(modeDetail), "ads=%s mcp=%u/%u lora=%s ml=%s nulling=%s modelProfile=%s profileId=%u",
                 passFail(adsReady),
                 bootI2c.mcpOkCount,
                 pgl::gld::board::SENSOR_COUNT,
                 passFail(radioReady),
                 (FIELDTEST_MODEL_UNVERIFIED || SIMULATED_MODEL_OUTPUT) ? "IGNORED" : passFail(mlReady),
                 (FIELDTEST_MODEL_UNVERIFIED || SIMULATED_MODEL_OUTPUT) ? "IGNORED" : passFail(nullingProfileApplied),
                 passFail(modelProfileReady),
                 nullingProfileId);
        printBootIcReport(power, bootAds, bootI2c, bootMcpControl,
                          true, radioReady,
                          !(FIELDTEST_MODEL_UNVERIFIED || SIMULATED_MODEL_OUTPUT),
                          FIELDTEST_MODEL_UNVERIFIED || SIMULATED_MODEL_OUTPUT || mlReady,
                          mlOutputSize,
                          (SENSORLESS_BENCH && SIMULATED_MODEL_OUTPUT)
                              ? radioReady
                              : (FIELDTEST_MODEL_UNVERIFIED || SIMULATED_MODEL_OUTPUT)
                              ? (adsReady && radioReady)
                              : (adsReady && radioReady && mlReady && nullingProfileApplied && modelProfileReady),
                          modeDetail);
        enableNonBatteryRuntimeSensorPower("boot_inference_after_report");
        armBootReportRecoveryIfNeeded(bootAds, bootI2c, bootMcpControl,
                                      !SENSORLESS_BENCH, radioReady,
                                      !(FIELDTEST_MODEL_UNVERIFIED || SIMULATED_MODEL_OUTPUT),
                                      FIELDTEST_MODEL_UNVERIFIED || SIMULATED_MODEL_OUTPUT || mlReady);

        lastScanMs = millis();
        lastTxMs   = millis();
        if (batteryPowerMode && !TFBG_CONTINUOUS_BATTERY) {
            startBatteryInferenceSession();
        }

    } else {
        // A Nulling mode request is operator-authorized. Alarm latch state is
        // retained for audit/delivery, but never redirects this mode request.
        // --- DATASET / NULLING mode init ---
        if (batteryPowerMode) {
            logPrintf("MODE_BATTERY_ALLOWED_TEMP mode=%s\n",
                      pgl::gld::gldModeName(currentMode));
            pulseWdtKeepaliveNow();
        }
        // Dataset/nulling initializes its runtime before the later report is
        // rendered; its diagnostic phase has nevertheless already completed.
        enableNonBatteryRuntimeSensorPower("boot_service_runtime");
        dacReady = dac.begin(Wire, &pcf8574);
        logPrintf("DAC_MUX_BEGIN_RESULT=%s\n", dacReady ? "PASS" : "FAIL");
        pulseWdtKeepaliveNow();

        if (currentMode == pgl::gld::GldMode::DATASET) {
            if (adsReady && dacReady) {
                initNulling(false);
                pulseWdtKeepaliveNow();
            }
            logPrintf("DATASET_READY adsReady=%u dacReady=%u nullingProfileId=%u\n",
                      adsReady ? 1 : 0, dacReady ? 1 : 0, nullingProfileId);
            char modeDetail[96];
            snprintf(modeDetail, sizeof(modeDetail), "ads=%s mcp=%u/%u dac=%s nullingProfileId=%u",
                     passFail(adsReady),
                     bootI2c.mcpOkCount,
                     pgl::gld::board::SENSOR_COUNT,
                     passFail(dacReady),
                     nullingProfileId);
            printBootIcReport(power, bootAds, bootI2c, bootMcpControl,
                              false, false,
                              false, false, -1,
                              adsReady && dacReady && nullingProfileApplied && nullingProfileId > 0,
                              modeDetail);
            runExternalPowerBootSensorSamples(power);
            armBootReportRecoveryIfNeeded(bootAds, bootI2c, bootMcpControl,
                                          false, false,
                                          false, false);
            pulseWdtKeepaliveNow();
            connectWifi();
            pulseWdtKeepaliveNow();
            mqtt.setBufferSize(MQTT_BUFFER_SIZE);
            mqttConnect();
            pulseWdtKeepaliveNow();
            lastStatusMs = millis();

        } else {
            // NULLING mode: run calibration first (blocking)
            disableNetworkForOfflineMode("nulling_mode");
            if (!adsReady || !dacReady) {
                logPrintf("NULLING_BLOCKED adsReady=%u dacReady=%u\n",
                          adsReady ? 1 : 0, dacReady ? 1 : 0);
                char modeDetail[96];
                snprintf(modeDetail, sizeof(modeDetail), "ads=%s mcp=%u/%u dac=%s nulling=BLOCKED_RETRY",
                         passFail(adsReady),
                         bootI2c.mcpOkCount,
                         pgl::gld::board::SENSOR_COUNT,
                         passFail(dacReady));
                printBootIcReport(power, bootAds, bootI2c, bootMcpControl,
                                  false, false,
                                  false, false, -1,
                                  false,
                                  modeDetail);
                runExternalPowerBootSensorSamples(power);
                armBootReportRecoveryIfNeeded(bootAds, bootI2c, bootMcpControl,
                                              false, false,
                                              false, false);
                armNullingRetry("hardware_not_ready");
            } else if (!ensureNullingSensorPowerReady("boot_nulling")) {
                logPrintln("NULLING_RUN=BLOCKED reason=sensor_power_not_ready");
                armNullingRetry("sensor_power_not_ready");
            } else if (!runNullingMcpWritePreflight("boot_nulling")) {
                logPrintln("NULLING_RUN=BLOCKED reason=mcp_preflight_failed");
                armNullingRetry("mcp_preflight_failed");
            } else {
                logPrintln("NULLING_RUN=start");

                const pgl::gld::GldNullingServiceResult result =
                    runNullingServiceWithMcpIsolation();
                logPrintf("NULLING_RUN_DONE status=%s successCount=%u\n",
                          pgl::gld::gldNullingStatusName(result.status), result.successCount);

                pgl::gld::GldNullingProfile toSave{};
                const bool saved = saveCompleteNullingProfile(result, toSave);
                if (saved) {
                        logPrintln("NULLING_RUNTIME_RESULT=PASS");
                        nullDone = true;
                        char modeDetail[96];
                        snprintf(modeDetail, sizeof(modeDetail), "ads=%s mcp=%u/%u dac=%s nulling=PASS auto=running profileId=%u",
                                 passFail(adsReady),
                                 bootI2c.mcpOkCount,
                                 pgl::gld::board::SENSOR_COUNT,
                                 passFail(dacReady),
                                 toSave.profileId);
                        printBootIcReport(power, bootAds, bootI2c, bootMcpControl,
                                          false, false,
                                          false, false, -1,
                                          true,
                                          modeDetail);
                        runExternalPowerBootSensorSamples(power);
                        armBootReportRecoveryIfNeeded(bootAds, bootI2c, bootMcpControl,
                                                      false, false,
                                                      false, false);
                        returnToRunningAfterNulling(toSave);
                } else {
                        const bool partial = result.status == pgl::gld::GldNullingStatus::PartialSuccess;
                        const bool fullOk = result.status == pgl::gld::GldNullingStatus::Ok &&
                                            result.successCount == pgl::gld::board::SENSOR_COUNT;
                        logPrintln(partial
                                   ? "NULLING_RUNTIME_RESULT=PARTIAL_RETRY"
                                   : "NULLING_RUNTIME_RESULT=FAIL_RETRY");
                        char modeDetail[96];
                        snprintf(modeDetail, sizeof(modeDetail), "ads=%s mcp=%u/%u dac=%s nulling=%s",
                                 passFail(adsReady),
                                 bootI2c.mcpOkCount,
                                 pgl::gld::board::SENSOR_COUNT,
                                 passFail(dacReady),
                                 partial ? "PARTIAL_RETRY" : "FAIL_RETRY");
                        printBootIcReport(power, bootAds, bootI2c, bootMcpControl,
                                          false, false,
                                          false, false, -1,
                                          false,
                                          modeDetail);
                        runExternalPowerBootSensorSamples(power);
                        armBootReportRecoveryIfNeeded(bootAds, bootI2c, bootMcpControl,
                                                      false, false,
                                                      false, false);
                        rememberIncompleteNullingResult(result);
                        armNullingRetry(fullOk ? "nvs_save_failed" : nullingRetryReason(result.status));
                }
            }
        }
    }
}

void loop() {
    firmwareServiceTick();
    reconcileRuntimePowerMode();
    // SHT40 has its own cached global values. Status/telemetry serialization
    // only snapshots this cache; it never starts a measurement itself.
    serviceSht40();
    // In external 24V mode the DC fan is a continuous-running load.
    // Keep this override after power reconciliation so it also applies when
    // the runtime power mode changes while the firmware is already running.
    static bool fanForcedOnFor24V = false;
    if (pgl::gld::board::HAS_DC_FAN && external24VPowerMode) {
        optionalDigitalWrite(pgl::gld::board::PIN_DC_FAN, HIGH);
        fanForcedOnFor24V = true;
    } else if (fanForcedOnFor24V) {
        optionalDigitalWrite(pgl::gld::board::PIN_DC_FAN, LOW);
        fanForcedOnFor24V = false;
    }
    if (powerTransitionShutdownPending) {
        completeBatterySessionAndPowerOff("unsupported_mode_power_transition");
        return;
    }
    maintainBootReportRecovery();

    if (currentMode == pgl::gld::GldMode::INFERENCE) {
        const uint32_t now = millis();
        maintainAdsRecovery("inference_ads_not_ready");
        serviceNonBatteryDacVerification();

        if (batteryPowerMode && !TFBG_CONTINUOUS_BATTERY) {
            // One-shot wake cycle: warm-up, 10 complete valid sample batches,
            // inference, bounded LoRa TX/RX, then final DONE followed by CLR.
            // While service hold is active, CLR is inhibited and DONE becomes
            // periodic so the board stays available for firmware upload.
            if (batterySessionState == BatterySessionState::CompleteHeld) {
                runBatteryInferenceSession();
                return;
            }
            if (!batteryRuntimeReady()) {
                const char* reason = batteryRuntimeBlockReason();
                armBatteryFaultPowerOff(reason);
                if (static_cast<int32_t>(now - batteryFaultPowerOffDueMs) >= 0) {
                    completeBatterySessionAndPowerOff(reason);
                }
                return;
            }
            batteryFaultPowerOffArmed = false;
            runBatteryInferenceSession();
            return;
        }

        if ((adsReady || SENSORLESS_BENCH) && now - lastScanMs >= SCAN_INTERVAL_MS) {
            lastScanMs = now;
            runScan();
        }
        if (radioReady && now - lastTxMs >= TX_INTERVAL_MS) {
            lastTxMs = now;
            transmitOnce();
        }

    } else if (currentMode == pgl::gld::GldMode::DATASET) {
        maintainWifi();
        maintainMqtt();
        flushDatasetQueue();
        maintainAdsRecovery("dataset_ads_not_ready");
        const uint32_t now = millis();
        if (now - lastStatusMs >= STATUS_INTERVAL_MS) {
            lastStatusMs = now;
            if (datasetState == DatasetState::Running)
                publishDatasetStatus("running", currentLabel);
        }
        runDatasetStateMachine();
        serviceDelay(10);

    } else {
        // NULLING mode: offline calibration; Serial commands are checked at loop start.
        if (nullingRetryArmed &&
            static_cast<int32_t>(millis() - nextNullingRetryMs) >= 0) {
            runNullingRetryAttempt();
        }
        serviceDelay(100);
    }
}
