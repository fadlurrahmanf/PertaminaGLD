"""GLD3-only diagnostic contracts, with actual C++ average fault injection.

These host tests do not prove I2C, rail voltage, ADC accuracy, gas response, or
physical restoration. The runtime preprocessor comparison deliberately omits
includes: it protects inactive branches, while PlatformIO validates full builds.
"""

from __future__ import annotations

import ast
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[3]
RUNTIME_PATH = "firmware/gld/src/GldUnifiedMain.cpp"
BASE = "dfba98f237b6b1f83c139f49e0e8a1c2e683e5af"
PACKAGES = Path.home() / ".platformio" / "packages"


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def compiler(package: str, binary: str) -> Path | None:
    bundled = PACKAGES / package / "bin" / binary
    if bundled.exists():
        return bundled
    fallback = shutil.which(binary)
    return Path(fallback) if fallback else None


def preprocess(source: str, definitions: list[str]) -> str:
    cpp = compiler("toolchain-xtensa-esp32s3", "xtensa-esp32s3-elf-g++.exe")
    if cpp is None:
        raise unittest.SkipTest("ESP32-S3 C++ preprocessor unavailable")
    source = re.sub(r"^\s*#\s*include\b[^\n]*", "", source, flags=re.MULTILINE)
    result = subprocess.run(
        [str(cpp), "-E", "-P", "-x", "c++", '-D__TIME__="00:00:00"',
         '-D__DATE__="Jan 01 1970"', *definitions, "-"],
        input=source, text=True, capture_output=True, check=True,
    )
    return " ".join(result.stdout.split())


class Gld3DiagnosticContractTests(unittest.TestCase):
    def active_gld3_section(self, start: str, end: str) -> str:
        source = read(RUNTIME_PATH)
        section = source[source.index(start):source.index(end, source.index(start))]
        return preprocess(section, ["-DPGL_GLD_BOARD_PROFILE_GLD2=1", "-DPGL_GLD_BOARD_PROFILE_GLD3=1"])

    def test_mapping_keeps_independent_tca_and_en_orders(self) -> None:
        source = read("firmware/gld/include/BoardPinsGLD3.h")
        arrays = {
            "SENSOR_NAMES": ["MQ8", "MQ135", "MQ3", "MQ5", "MQ4", "MQ7", "MQ6", "MQ2"],
            "SENSOR_HEADERS": ["H2", "H1", "H3", "H4", "H5", "H6", "H7", "H8"],
            "SENSOR_TO_MUX_CH": [7, 6, 5, 4, 3, 2, 1, 0],
            "SENSOR_TO_POWER_EN": [0, 6, 7, 3, 4, 5, 2, 1],
            "POWER_EN_TO_MUX_CH": [7, 0, 1, 4, 3, 2, 6, 5],
            "SENSOR_TO_ADS_CH": [0, 1, 2, 3, 4, 5, 6, 7],
        }
        for name, expected in arrays.items():
            with self.subTest(array=name):
                body = re.search(rf"{name}\[SENSOR_COUNT\]\s*=\s*\{{([^}}]+)\}}", source).group(1)
                actual = [token.strip().strip('"') for token in body.split(",") if token.strip()]
                self.assertEqual(actual, [str(item) for item in expected])

    def test_board_profile_compile_selects_fan_only_for_gld3(self) -> None:
        cpp = compiler("toolchain-xtensa-esp32s3", "xtensa-esp32s3-elf-g++.exe")
        if cpp is None:
            self.skipTest("ESP32-S3 C++ compiler unavailable")
        for flags, fan in (([], -1), (["-DPGL_GLD_BOARD_PROFILE_GLD3=0"], -1),
                           (["-DPGL_GLD_BOARD_PROFILE_GLD3=1"], 7)):
            with self.subTest(definitions=flags):
                source = (
                    '#include "BoardPins.h"\n'
                    f'static_assert(pgl::gld::board::PIN_DC_FAN == {fan}, "fan pin");\n'
                    f'static_assert(pgl::gld::board::HAS_DC_FAN == {str(fan == 7).lower()}, "fan capability");\n'
                    'static_assert(pgl::gld::board::PIN_ALARM_LAMP == 40, "alarm preserved");\n'
                    'static_assert(pgl::gld::board::SENSOR_TO_POWER_EN[1] == 6, "EN mapping");\n'
                    'static_assert(pgl::gld::board::SENSOR_TO_MUX_CH[1] == 6, "TCA mapping");\n'
                )
                result = subprocess.run(
                    [str(cpp), "-std=gnu++17", "-fsyntax-only", "-x", "c++",
                     "-DPGL_GLD_BOARD_PROFILE_GLD2=1", *flags,
                     "-I", str(ROOT / "firmware/gld/include"), "-"],
                    input=source, text=True, capture_output=True,
                )
                self.assertEqual(result.returncode, 0, result.stderr)

    def test_gld1_gld2_runtime_branches_are_unchanged(self) -> None:
        baseline = subprocess.run(
            ["git", "show", f"{BASE}:{RUNTIME_PATH}"], cwd=ROOT,
            text=True, capture_output=True, check=True,
        ).stdout
        current = read(RUNTIME_PATH)
        for profile in (0, 1):
            with self.subTest(gld2=profile):
                flags = [f"-DPGL_GLD_BOARD_PROFILE_GLD2={profile}", "-DPGL_GLD_BOARD_PROFILE_GLD3=0",
                         "-DPGL_GLD_BOARD_PROFILE_WROOM_U1_N16R8=1", "-DARDUINO_ARCH_ESP32=1"]
                self.assertEqual(preprocess(baseline, flags), preprocess(current, flags))

    def test_gld3_version_does_not_bump_other_products(self) -> None:
        versions = read("firmware/shared/include/FirmwareVersion.h")
        self.assertRegex(versions, r'GLD3_FIRMWARE_VERSION\s*=\s*"0\.8\.31"')
        for profile in (0, 1):
            active = preprocess(versions, [f"-DPGL_GLD_BOARD_PROFILE_GLD3={profile}"])
            expected = 'GLD3_FIRMWARE_VERSION' if profile else '"0.8.30"'
            self.assertIn(f"GLD_FIRMWARE_VERSION = {expected};", active)
        self.assertIn('CH_FIRMWARE_VERSION = "0.8.0";', versions)
        self.assertIn('GATEWAY_FIRMWARE_VERSION = "0.2.0";', versions)

    def test_sweep_requires_isolation_readback_and_truthful_aggregate(self) -> None:
        sweep = self.active_gld3_section(
            "void runAdsMcpSweepFromSerialCommand() {", "// LoRa (inference mode)",
        )
        for marker in (
            'blockedReason = "mode_not_inference"',
            'blockedReason = "external_power_required"',
            'blockedReason = "active_session_mcp_override"',
            "pcf8574.readOutputs(originalPcfOutputs)",
            "dac.captureSensorPowerState()",
            "dac.setAutomaticSensorPowerControl(true)",
            "dac.setRestoreSensorPowerAfterWrite(false)",
            "isolation=one_active_rail baselineScope=isolated_power_on",
            "baselineValid[ch] = dac.readDac(ch, baseline[ch])",
            "lowReadback == DIAG_SWEEP_DAC_CODE_LOW",
            "highReadback == DIAG_SWEEP_DAC_CODE_HIGH",
            "restoreReadback == baseline[ch]",
            "const bool dacPass = baselineValid[ch] && lowMatch && highMatch && restoreMatch",
            "const bool channelPass = dacPass && adsPass",
            "allDacPass = allDacPass && dacPass",
            "allAdsPass = allAdsPass && adsPass",
            "finalPcfOutputs == originalPcfOutputs",
            "const bool pass = allDacPass && allAdsPass && restoreMatch && passCount == pgl::gld::board::SENSOR_COUNT",
            'pass ? "pass" : "fail"',
            "analogResponse=not_graded",
            "ADS_MCP_SWEEP_DETAIL ch=%u",
            "ADS_MCP_SWEEP_RESTORE_CHANNEL ch=%u",
            "runtimeMcpReadbackVerified[ch] = false",
            "runtimeMcpVerifiedAtMs[ch] = 0",
            "movingAvg.reset()",
            "latestTelemetryValid = false",
        ):
            with self.subTest(marker=marker):
                self.assertIn(marker, sweep)
        for forbidden in ("writeDacPersistent(", "writeAll(", "saveNullingProfile(", "prefs.put", "status=ok"):
            self.assertNotIn(forbidden, sweep)
        self.assertLess(sweep.index("pcf8574.readOutputs(originalPcfOutputs)"), sweep.index("dac.begin(Wire, &pcf8574)"))
        self.assertLess(sweep.index("runtimeMcpReadbackVerified[ch] = false"), sweep.index("dac.begin(Wire, &pcf8574)"))
        self.assertLess(sweep.index("movingAvg.reset()"), sweep.index("dac.begin(Wire, &pcf8574)"))
        self.assertLess(sweep.index("baselineValid[ch] = dac.readDac"), sweep.index("dac.writeDac(ch, DIAG_SWEEP_DAC_CODE_LOW)"))
        failed_begin = sweep[sweep.index("if (!dacReady)"):sweep.index("pgl::gld::GldNullingProfile profile")]
        self.assertIn("dac.restoreSensorPower()", failed_begin)
        self.assertIn("pcf8574.readOutputs(livePcf)", failed_begin)
        self.assertIn("runtimeVerification=invalidated", failed_begin)

    def test_current_state_observation_does_not_replace_isolated_boot_result(self) -> None:
        observer = self.active_gld3_section(
            "void runCurrentStateCheckFromSerialCommand() {", "void runI2cScanFromSerialCommand() {",
        )
        self.assertIn("RUN_CURRENT_STATE_CHECK_SCOPE=observational", observer)
        self.assertIn("isolatedFunctional=not_tested", observer)
        self.assertIn("probeCurrentStateI2c(false)", observer)
        for forbidden in ("lastBootMcpOkCount =", "lastBootMcpOk[sensor] =", "writeDac(",
                          "writeDacPersistent(", "writeOutputs(", "dac.begin("):
            self.assertNotIn(forbidden, observer)

    def test_boot_control_restores_known_baseline_without_eeprom_writes(self) -> None:
        boot = self.active_gld3_section(
            "BootMcpControlReport testBootMcpControl(bool externalPower) {", "BootDiagnosticsResult runBootHardwareDiagnostics(",
        )
        for marker in ("dac.readDac(sensor, baseline)", "dac.writeDac(sensor, baseline)",
                       "restoreReadback == baseline", "baselineScope=isolated_power_on",
                       "report.writeHigh[sensor] = highOk && highMatch && restoreMatch"):
            self.assertIn(marker, boot)
        self.assertNotIn("writeDacPersistent(", boot)
        apply = self.active_gld3_section("bool applySavedNullingProfileOnly() {", "void printBootSensorSnapshotRow(")
        no_profile = apply[:apply.index("if (!dacReady)")]
        self.assertIn("dacReset=SKIP_UNSAFE_VOLATILE_NO_PERSIST", no_profile)
        for forbidden in ("writeAll(", "writeDac(", "writeDacPersistent(", "saveNullingProfile("):
            self.assertNotIn(forbidden, no_profile)
        self.assertLess(apply.index("allApplied = allApplied && powerRestored"), apply.index("sessionMcpOverrideMask = 0"))

    def test_cpp_diagnostic_log_formats_fit_fixed_buffer(self) -> None:
        """Exercise the production format literals with documented upper bounds.

        DAC readback is 12-bit; status flags are booleans; channels/counts/gain
        and PCF masks are uint8_t. Raw ADC values use full signed-int32 bounds
        (stronger than ADS1256's 24-bit range), elapsed ms full uint32 bounds,
        and voltages/delta +/-10 V (stronger than the +/-5 V ADC input span).
        snprintf's returned size excludes NUL but includes the final newline.
        """
        cpp = compiler("toolchain-gccmingw32", "g++.exe")
        if cpp is None:
            self.skipTest("host C++ compiler unavailable")
        source = read(RUNTIME_PATH)
        logger = source[source.index("void logPrintf("):source.index("void logPrintf(") + 800]
        self.assertRegex(logger, r"char\s+\w+\[256\]")
        active = preprocess(source, ["-DPGL_GLD_BOARD_PROFILE_GLD2=1", "-DPGL_GLD_BOARD_PROFILE_GLD3=1"])
        prefixes = ("ADS_MCP_SWEEP_", "GLD3_BOOT_MCP_CONTROL", "RUN_CURRENT_STATE_CHECK_SCOPE=")
        literal_pattern = r'"(?:\\.|[^"\\])*"'
        formats = []
        for call in re.finditer(rf"logPrintf\(\s*((?:{literal_pattern}\s*)+)", active):
            literal = call.group(1)
            decoded = "".join(ast.literal_eval(item) for item in re.findall(literal_pattern, literal))
            if decoded.startswith(prefixes):
                formats.append((literal, decoded))
        for call in re.finditer(rf"logPrintln\(\s*({literal_pattern})\s*\)", active):
            decoded = ast.literal_eval(call.group(1))
            if decoded.startswith(prefixes + ("BOOT_NULLING_PROFILE_APPLY=SKIP",)):
                self.assertLessEqual(len(decoded.encode("utf-8")) + 2, 256, decoded)  # newline + NUL
        self.assertGreaterEqual(len(formats), 12, "new diagnostic log formats were not discovered")
        boolean_fields = {
            "externalPower", "batteryMode", "pcfReady", "originalPcfRead", "restoreWrite",
            "finalPcfRead", "restoreMatch", "profileLoaded", "ok", "baselineRead", "low",
            "lowRead", "lowMatch", "high", "highRead", "highMatch", "restoreRead", "write0",
            "read0", "match0", "write4000", "read4000", "match4000", "finalRead", "dacPass",
            "adsSamplesValid", "powerRestore",
        }
        byte_fields = {"ch", "ads", "mux", "samples", "gain0", "gain4000", "executionPassCount",
                       "observedMcp", "authoritativeBootMcp"}
        dac_fields = {"baseline", "codeLow", "codeHigh", "code0", "code4000", "readback0",
                      "readback4000", "restoreReadback"}
        strings = {
            "reason": "active_session_mcp_override", "mode": "inference", "sensor": "MQ135",
            "st0": "InvalidChannel", "st4000": "InvalidChannel", "status": "fail",
            "ADS_MCP_SWEEP_ADS_BEGIN": "FAIL", "ADS_MCP_SWEEP_DAC_BEGIN": "FAIL",
        }
        checks = []
        for index, (literal, decoded) in enumerate(formats):
            arguments = []
            for spec in re.finditer(r"%(?:0?\d+)?(?:\.\d+)?[lL]?[usdfX]", decoded):
                prefix = decoded[:spec.start()].split()[-1]
                field = prefix.split("=", 1)[0]
                token = spec.group()
                if token.endswith("s"):
                    self.assertIn(field, strings, f"supply longest string bound for {field}")
                    arguments.append('"' + strings[field] + '"')
                elif token.endswith("X"):
                    arguments.append("255u")
                elif token.endswith("f"):
                    arguments.append("-10.0")
                elif token == "%ld":
                    arguments.append("(-2147483647L - 1L)")
                elif token == "%lu":
                    arguments.append("4294967295UL")
                elif field in boolean_fields:
                    arguments.append("1u")
                elif field in byte_fields:
                    arguments.append("255u")
                elif field in dac_fields:
                    arguments.append("4095u")
                else:
                    self.fail(f"supply numeric bound for {field}: {token}")
            self.assertTrue(decoded.endswith("\n"), decoded)
            checks.append(
                "{ const int needed = std::snprintf(buffer, sizeof(buffer), " + literal +
                (", " + ", ".join(arguments) if arguments else "") + "); "
                'if (needed < 1 || needed >= int(sizeof(buffer)) || buffer[needed - 1] != \'\\n\') { '
                f'std::fprintf(stderr, "format {index} requires %d bytes plus NUL\\n", needed); return {index + 1}; }} }}'
            )
        harness = '#include <cstdio>\nint main() { char buffer[256];\n' + "\n".join(checks) + '\nreturn 0; }\n'
        temp_root = ROOT / "tmp"
        temp_root.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="gld3-log-contract-", dir=temp_root) as directory:
            binary = Path(directory) / "log_formats.exe"
            environment = dict(os.environ)
            environment["PATH"] = str(cpp.parent) + os.pathsep + environment.get("PATH", "")
            result = subprocess.run(
                [str(cpp), "-std=c++14", "-x", "c++", "-", "-o", str(binary)],
                input=harness, env=environment, text=True, capture_output=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            result = subprocess.run([str(binary)], env=environment, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_cpp_average_preserves_any_failed_sample(self) -> None:
        cpp = compiler("toolchain-gccmingw32", "g++.exe")
        if cpp is None:
            self.skipTest("host C++ compiler unavailable")
        source = read(RUNTIME_PATH)
        start = source.index("struct DiagnosticAdsAverage {")
        end = source.index("void runAdsMcpSweepFromSerialCommand()", start)
        snippet = source[start:end]
        # The exact production averaging function runs against deterministic
        # ADS values; inject one failure at every sample position, including
        # a first failure followed by successful final reads.
        harness = r'''
#include <cstdint>
namespace pgl { namespace gld {
enum class GldAds1256Status { NotReady, Ok, Fault };
struct GldAds1256Reading {
    GldAds1256Status status;
    int32_t raw;
    float voltage;
    uint8_t gain;
};
}}
constexpr uint8_t DIAG_SWEEP_SAMPLE_COUNT = 5;
void firmwareServiceTick() {}
struct FakeAds {
    int bad = -1;
    int next = 0;
    pgl::gld::GldAds1256Reading readChannel(uint8_t) {
        const bool fail = next++ == bad;
        return {fail ? pgl::gld::GldAds1256Status::Fault : pgl::gld::GldAds1256Status::Ok, 200, 1.0f, 1};
    }
} ads;
''' + snippet + r'''
int main() {
    for (int bad = -1; bad < DIAG_SWEEP_SAMPLE_COUNT; ++bad) {
        ads.bad = bad;
        ads.next = 0;
        const auto reading = readDiagnosticAverage(0);
        const bool reportedOk = reading.status == pgl::gld::GldAds1256Status::Ok;
        if (reportedOk != (bad == -1)) return bad + 2;
        if (ads.next != DIAG_SWEEP_SAMPLE_COUNT) return 20;
        if (bad == -1 && (reading.raw != 200 || reading.voltage != 1.0f || reading.gain != 1)) return 21;
    }
    return 0;
}
'''
        temp_root = ROOT / "tmp"
        temp_root.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="gld3-host-contract-", dir=temp_root) as directory:
            binary = Path(directory) / "average.exe"
            environment = dict(os.environ)
            environment["PATH"] = str(cpp.parent) + os.pathsep + environment.get("PATH", "")
            result = subprocess.run(
                [str(cpp), "-std=c++14", "-DPGL_GLD_BOARD_PROFILE_GLD3=1", "-x", "c++", "-", "-o", str(binary)],
                input=harness, env=environment, text=True, capture_output=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            result = subprocess.run([str(binary)], env=environment, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, f"average fault case exited {result.returncode}: {result.stderr}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
