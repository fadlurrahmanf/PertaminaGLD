GLD3 v0.8.31 scoped source changes, not a complete repository.
Base commit: dfba98f237b6b1f83c139f49e0e8a1c2e683e5af
Validated worktree: D:/Github/PertaminaGLD-GLD3-Diagnostics
Do not overlay blindly onto the dirty main/GLD1 checkout.
Included paths are the complete changed/new source files over that base.
Build from firmware/: pio run -e gld_v3 -j 1
Windows linker may require TEMP/TMP/TMPDIR set to a local forward-slash path.
See docs/wiring/GLD3-diagnostics-2026-09-17.md in main for verified evidence and limits.
