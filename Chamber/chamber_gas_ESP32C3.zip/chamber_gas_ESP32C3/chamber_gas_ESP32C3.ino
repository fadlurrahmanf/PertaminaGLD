// =====================================================================
//  Chamber Gas - ESP32-C3-WROOM-02-N4  (VERSI TANPA RTC)
//  Board: PCB sendiri (upload lewat CH340, bukan USB native)
// =====================================================================
#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <LittleFS.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BME280.h>

// ================= PIN (sesuai skematik PCB) =================
#define VALVE_PIN       18   // RLY1 -> K1 (solenoid valve) : HIGH = valve terbuka
#define PUMP_PIN         3   // IO3 -> jumper ke input driver RLY2 (K2/pompa) : mode pulsa HIGH
#define BTN_PUMP_PIN     6   // tombol pompa (aktif LOW, pull-up eksternal): ditekan = IO6 LOW
#define BTN_VALVE_PIN    7   // tombol valve (aktif LOW, pull-up eksternal): ditekan = IO7 LOW
#define I2C_SDA          4   // BME280
#define I2C_SCL          5

// ================= Durasi pulsa pompa =================
const unsigned long PUMP_ON_PULSE_MS  = 1000;  // ON  -> HIGH 1 detik
const unsigned long PUMP_OFF_PULSE_MS = 300;   // OFF -> HIGH sesaat

// ================= Access Point =================
const char* ssid     = "Chamber_Uji_01";
const char* password = "";   // kosong = tanpa password

// ================= Objek & status =================
AsyncWebServer server(80);
Adafruit_BME280 bme;         // alamat 0x76 atau 0x77 (dicoba otomatis)

bool bmeok = false;
bool fsok  = false;

bool pumpState  = false;     // status logis pompa (untuk dashboard)
bool valveState = false;

// Pulsa pompa (non-blocking)
volatile bool          pumpPulseActive   = false;
volatile unsigned long pumpPulseStart    = 0;
volatile unsigned long pumpPulseDuration = 0;

// Tombol fisik
bool lastBtnValve = HIGH;
bool lastBtnPump  = HIGH;

// Data sensor
float suhu = 0, tekanan = 0, kelembapan = 0;
unsigned long previousMillis = 0;
const long interval = 1000;  // pembacaan sensor tiap 1 detik

float safe(float v) { return isnan(v) ? 0.0f : v; }

// ================= Aktuator =================
void setValve(bool on) {
  valveState = on;
  digitalWrite(VALVE_PIN, on ? HIGH : LOW);
  Serial.printf("Valve -> %s\n", on ? "TERBUKA (HIGH)" : "TERTUTUP (LOW)");
  delay(100);
}

void startPumpPulse(unsigned long durationMs) {
  pumpPulseStart    = millis();
  pumpPulseDuration = durationMs;
  pumpPulseActive   = true;
  digitalWrite(PUMP_PIN, HIGH);
}

void setPump(bool on) {
  pumpState = on;
  startPumpPulse(on ? PUMP_ON_PULSE_MS : PUMP_OFF_PULSE_MS);
  Serial.printf("Pompa %s -> pulsa HIGH %lu ms\n", on ? "ON" : "OFF",
                on ? PUMP_ON_PULSE_MS : PUMP_OFF_PULSE_MS);
}

void setup() {
  // 1. Aktuator & tombol
  pinMode(VALVE_PIN, OUTPUT);
  digitalWrite(VALVE_PIN, LOW);
  pinMode(PUMP_PIN, OUTPUT);
  digitalWrite(PUMP_PIN, LOW);
  pinMode(BTN_VALVE_PIN, INPUT_PULLUP);
  pinMode(BTN_PUMP_PIN, INPUT_PULLUP);

  Serial.begin(115200);
  delay(500);
  Serial.println("\n=== BOOT OK (tanpa RTC) ===");

  // 2. LittleFS
  fsok = LittleFS.begin(true);
  Serial.println(fsok ? "LittleFS OK" : "PERINGATAN: LittleFS gagal");

  // 3. I2C & BME280
  Wire.begin(I2C_SDA, I2C_SCL, 100000);
  bmeok = bme.begin(0x76, &Wire);
  if (!bmeok) bmeok = bme.begin(0x77, &Wire);
  if (!bmeok) Serial.println("Error: BME280 tidak ditemukan (0x76/0x77)!");

  // 4. WiFi Access Point
  WiFi.mode(WIFI_AP);
  WiFi.softAP(ssid, password);
  Serial.print("Access Point berjalan. IP: ");
  Serial.println(WiFi.softAPIP());

  // 5. Web server
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    if (fsok && LittleFS.exists("/index.html")) {
      request->send(LittleFS, "/index.html", "text/html");
    } else {
      request->send(200, "text/plain",
        "ESP32-C3 aktif, tetapi index.html belum ada di LittleFS.\n"
        "Coba: /data , /pump?state=1 , /valve?state=1");
    }
  });

  // Valve: /valve?state=1 (HIGH) atau 0 (LOW)
  server.on("/valve", HTTP_GET, [](AsyncWebServerRequest *request) {
    if (request->hasParam("state")) {
      setValve(request->getParam("state")->value().toInt() != 0);
      request->send(200, "text/plain", "OK");
    } else {
      request->send(400, "text/plain", "Bad Request");
    }
  });

  // Pompa: /pump?state=1 (HIGH 1 detik) atau 0 (HIGH sesaat)
  server.on("/pump", HTTP_GET, [](AsyncWebServerRequest *request) {
    if (request->hasParam("state")) {
      setPump(request->getParam("state")->value().toInt() != 0);
      request->send(200, "text/plain", "OK");
    } else {
      request->send(400, "text/plain", "Bad Request");
    }
  });

  // Data JSON
  server.on("/data", HTTP_GET, [](AsyncWebServerRequest *request) {
    String json = "{";
    json += "\"s\":"     + String(safe(suhu), 2)       + ",";
    json += "\"t\":"     + String(safe(tekanan), 2)    + ",";
    json += "\"h\":"     + String(safe(kelembapan), 2) + ",";
    json += "\"bme\":"   + String(bmeok ? 1 : 0)       + ",";
    json += "\"pump\":"  + String(pumpState ? 1 : 0)   + ",";
    json += "\"valve\":" + String(valveState ? 1 : 0);
    json += "}";
    request->send(200, "application/json", json);
  });

  server.onNotFound([](AsyncWebServerRequest *request) {
    request->send(404, "text/plain", "Not found");
  });

  server.begin();
  Serial.println("Async Web Server dimulai!");
}

void loop() {
  unsigned long now = millis();

  // --- Tombol fisik: dibaca setiap putaran loop, tanpa interval ---
  // Tombol pompa (IO6): sama seperti tombol dashboard.
  //   saat ditekan & kondisi OFF -> pulsa HIGH 1 detik, status ON
  //   saat ditekan & kondisi ON  -> pulsa HIGH sesaat,  status OFF
  bool bPump = digitalRead(BTN_PUMP_PIN);
  if (lastBtnPump == HIGH && bPump == LOW) setPump(!pumpState);
  lastBtnPump = bPump;

  // Tombol valve (IO7): ditekan -> valve ON, dilepas -> valve OFF
  bool bValve = digitalRead(BTN_VALVE_PIN);
  if (lastBtnValve == HIGH && bValve == LOW) setValve(true);
  if (lastBtnValve == LOW  && bValve == HIGH) setValve(false);
  lastBtnValve = bValve;

  // --- Akhiri pulsa pompa ---
  if (pumpPulseActive && (now - pumpPulseStart >= pumpPulseDuration)) {
    digitalWrite(PUMP_PIN, LOW);
    pumpPulseActive = false;
  }

  // --- Baca sensor tiap 1 detik ---
  if (now - previousMillis >= interval) {
    previousMillis = now;
    if (bmeok) {
      suhu       = bme.readTemperature();
      tekanan    = bme.readPressure();
      kelembapan = bme.readHumidity();
    }
  }
}
